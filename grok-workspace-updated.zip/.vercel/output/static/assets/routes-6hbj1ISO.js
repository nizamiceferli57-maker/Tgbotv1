import{a as e,c as t,i as n,l as r,n as i,o as a,r as o,s,t as c,u as l}from"./index-BwjeN0cC.js";function u(e){if(Array.isArray(e))return e.flatMap(e=>u(e));if(typeof e!=`string`)return[];let t=[],n=0,r,i,a,o,s,c=()=>{for(;n<e.length&&/\s/.test(e.charAt(n));)n+=1;return n<e.length},l=()=>(i=e.charAt(n),i!==`=`&&i!==`;`&&i!==`,`);for(;n<e.length;){for(r=n,s=!1;c();)if(i=e.charAt(n),i===`,`){for(a=n,n+=1,c(),o=n;n<e.length&&l();)n+=1;n<e.length&&e.charAt(n)===`=`?(s=!0,n=o,t.push(e.slice(r,a)),r=n):n=a+1}else n+=1;(!s||n>=e.length)&&t.push(e.slice(r))}return t}function d(e){return e instanceof Headers?e:Array.isArray(e)||typeof e==`object`?new Headers(e):null}function f(...e){return e.reduce((e,t)=>{let n=d(t);if(!n)return e;for(let[t,r]of n.entries())t===`set-cookie`?u(r).forEach(t=>e.append(`set-cookie`,t)):e.set(t,r);return e},new Headers)}var p=c(`bell`,[[`path`,{d:`M10.268 21a2 2 0 0 0 3.464 0`,key:`vwvbt9`}],[`path`,{d:`M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326`,key:`11g9vi`}]]),m=c(`box`,[[`path`,{d:`M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z`,key:`hh9hay`}],[`path`,{d:`m3.3 7 8.7 5 8.7-5`,key:`g66t2b`}],[`path`,{d:`M12 22V12`,key:`d0xqtd`}]]),h=c(`check`,[[`path`,{d:`M20 6 9 17l-5-5`,key:`1gmf2c`}]]),g=c(`code-xml`,[[`path`,{d:`m18 16 4-4-4-4`,key:`1inbqp`}],[`path`,{d:`m6 8-4 4 4 4`,key:`15zrgr`}],[`path`,{d:`m14.5 4-5 16`,key:`e7oirm`}]]),_=c(`copy`,[[`rect`,{width:`14`,height:`14`,x:`8`,y:`8`,rx:`2`,ry:`2`,key:`17jyea`}],[`path`,{d:`M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2`,key:`zix9uf`}]]),v=c(`download`,[[`path`,{d:`M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4`,key:`ih7n3h`}],[`polyline`,{points:`7 10 12 15 17 10`,key:`2ggqvy`}],[`line`,{x1:`12`,x2:`12`,y1:`15`,y2:`3`,key:`1vk2je`}]]),y=c(`eye`,[[`path`,{d:`M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0`,key:`1nclc0`}],[`circle`,{cx:`12`,cy:`12`,r:`3`,key:`1v7zrd`}]]),b=c(`pause`,[[`rect`,{x:`14`,y:`4`,width:`4`,height:`16`,rx:`1`,key:`zuxfzm`}],[`rect`,{x:`6`,y:`4`,width:`4`,height:`16`,rx:`1`,key:`1okwgv`}]]),x=c(`play`,[[`polygon`,{points:`6 3 20 12 6 21 6 3`,key:`1oa8hb`}]]),S=c(`radio`,[[`path`,{d:`M4.9 19.1C1 15.2 1 8.8 4.9 4.9`,key:`1vaf9d`}],[`path`,{d:`M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5`,key:`u1ii0m`}],[`circle`,{cx:`12`,cy:`12`,r:`2`,key:`1c9p78`}],[`path`,{d:`M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5`,key:`1j5fej`}],[`path`,{d:`M19.1 4.9C23 8.8 23 15.1 19.1 19`,key:`10b0cb`}]]),C=c(`search`,[[`path`,{d:`m21 21-4.34-4.34`,key:`14j7rj`}],[`circle`,{cx:`11`,cy:`11`,r:`8`,key:`4ej97u`}]]),w=c(`send`,[[`path`,{d:`M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z`,key:`1ffxy3`}],[`path`,{d:`m21.854 2.147-10.94 10.939`,key:`12cjpa`}]]),T=c(`settings`,[[`path`,{d:`M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z`,key:`1qme2f`}],[`circle`,{cx:`12`,cy:`12`,r:`3`,key:`1v7zrd`}]]),E=c(`shield`,[[`path`,{d:`M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z`,key:`oel41y`}]]),ee=c(`upload`,[[`path`,{d:`M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4`,key:`ih7n3h`}],[`polyline`,{points:`17 8 12 3 7 8`,key:`t8dd8p`}],[`line`,{x1:`12`,x2:`12`,y1:`3`,y2:`15`,key:`widbto`}]]),te=c(`users`,[[`path`,{d:`M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2`,key:`1yyitq`}],[`path`,{d:`M16 3.128a4 4 0 0 1 0 7.744`,key:`16gr8j`}],[`path`,{d:`M22 21v-2a4 4 0 0 0-3-3.87`,key:`kshegd`}],[`circle`,{cx:`9`,cy:`7`,r:`4`,key:`nufk8`}]]),D=c(`zap`,[[`path`,{d:`M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z`,key:`1xq2db`}]]),O=l(r(),1),k=l(t(),1);function A(e){if(!e||typeof document>`u`)return;let t=document.head||document.getElementsByTagName(`head`)[0],n=document.createElement(`style`);n.type=`text/css`,t.appendChild(n),n.styleSheet?n.styleSheet.cssText=e:n.appendChild(document.createTextNode(e))}var ne=e=>{switch(e){case`success`:return j;case`info`:return M;case`warning`:return ae;case`error`:return oe;default:return null}},re=Array(12).fill(0),ie=({visible:e,className:t})=>O.createElement(`div`,{className:[`sonner-loading-wrapper`,t].filter(Boolean).join(` `),"data-visible":e},O.createElement(`div`,{className:`sonner-spinner`},re.map((e,t)=>O.createElement(`div`,{className:`sonner-loading-bar`,key:`spinner-bar-${t}`})))),j=O.createElement(`svg`,{xmlns:`http://www.w3.org/2000/svg`,viewBox:`0 0 20 20`,fill:`currentColor`,height:`20`,width:`20`,"aria-hidden":`true`},O.createElement(`path`,{fillRule:`evenodd`,d:`M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z`,clipRule:`evenodd`})),ae=O.createElement(`svg`,{xmlns:`http://www.w3.org/2000/svg`,viewBox:`0 0 24 24`,fill:`currentColor`,height:`20`,width:`20`,"aria-hidden":`true`},O.createElement(`path`,{fillRule:`evenodd`,d:`M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z`,clipRule:`evenodd`})),M=O.createElement(`svg`,{xmlns:`http://www.w3.org/2000/svg`,viewBox:`0 0 20 20`,fill:`currentColor`,height:`20`,width:`20`,"aria-hidden":`true`},O.createElement(`path`,{fillRule:`evenodd`,d:`M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z`,clipRule:`evenodd`})),oe=O.createElement(`svg`,{xmlns:`http://www.w3.org/2000/svg`,viewBox:`0 0 20 20`,fill:`currentColor`,height:`20`,width:`20`,"aria-hidden":`true`},O.createElement(`path`,{fillRule:`evenodd`,d:`M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-5a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0110 5zm0 10a1 1 0 100-2 1 1 0 000 2z`,clipRule:`evenodd`})),se=O.createElement(`svg`,{xmlns:`http://www.w3.org/2000/svg`,width:`12`,height:`12`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":`true`},O.createElement(`line`,{x1:`18`,y1:`6`,x2:`6`,y2:`18`}),O.createElement(`line`,{x1:`6`,y1:`6`,x2:`18`,y2:`18`})),N=()=>{let[e,t]=O.useState(document.hidden);return O.useEffect(()=>{let e=()=>{t(document.hidden)};return document.addEventListener(`visibilitychange`,e),()=>document.removeEventListener(`visibilitychange`,e)},[]),e},P=1,ce=100,le=e=>typeof e?.id==`number`||e?.id?.length>0?e.id:P++,F=new class{constructor(){this.subscribe=e=>(this.subscribers.push(e),this.getActiveToasts().forEach(t=>e(t)),()=>{let t=this.subscribers.indexOf(e);this.subscribers.splice(t,1)}),this.publish=e=>{this.subscribers.forEach(t=>t(e))},this.addToast=e=>{this.publish(e),this.toasts=[...this.toasts,e],this.trimHistory()},this.trimHistory=()=>{let e=this.toasts.length-ce;e<=0||(this.toasts=this.toasts.filter(t=>e>0&&this.dismissedToasts.has(t.id)?(this.dismissedToasts.delete(t.id),e--,!1):!0))},this.create=e=>{let{message:t,...n}=e,r=le(e),i=this.pendingDismissals.get(r);i!==void 0&&(cancelAnimationFrame(i),this.pendingDismissals.delete(r),this.dismissedToasts.delete(r));let a=this.dismissedToasts.has(r),o=e.dismissible===void 0||e.dismissible;return a&&(this.dismissedToasts.delete(r),this.toasts=this.toasts.filter(e=>e.id!==r)),!a&&this.toasts.find(e=>e.id===r)?this.toasts=this.toasts.map(n=>n.id===r?(this.publish({...n,...e,id:r,title:t}),{...n,...e,id:r,dismissible:o,title:t}):n):this.addToast({title:t,...n,dismissible:o,id:r}),r},this.dismiss=e=>{if(e==null)return this.getActiveToasts().forEach(e=>{this.dismissedToasts.add(e.id),this.subscribers.forEach(t=>t({id:e.id,dismiss:!0}))}),e;this.dismissedToasts.add(e);let t=this.pendingDismissals.get(e);return t!==void 0&&cancelAnimationFrame(t),this.pendingDismissals.set(e,requestAnimationFrame(()=>{this.pendingDismissals.delete(e),this.subscribers.forEach(t=>t({id:e,dismiss:!0}))})),e},this.message=(e,t)=>this.create({...t,message:e,type:void 0}),this.error=(e,t)=>this.create({...t,message:e,type:`error`}),this.success=(e,t)=>this.create({...t,type:`success`,message:e}),this.info=(e,t)=>this.create({...t,type:`info`,message:e}),this.warning=(e,t)=>this.create({...t,type:`warning`,message:e}),this.loading=(e,t)=>this.create({...t,type:`loading`,message:e}),this.promise=(e,t)=>{if(!t)return;let n;t.loading!==void 0&&(n=this.create({...t,promise:e,type:`loading`,message:t.loading,description:typeof t.description==`function`?void 0:t.description}));let r=Promise.resolve(e instanceof Function?e():e),i=n!==void 0,a,o=r.then(async e=>{if(a=[`resolve`,e],O.isValidElement(e))i=!1,this.create({id:n,type:`default`,message:e});else if(de(e)&&!e.ok){i=!1;let r=typeof t.error==`function`?await t.error(`HTTP error! status: ${e.status}`):t.error,a=typeof t.description==`function`?await t.description(`HTTP error! status: ${e.status}`):t.description,o=typeof r==`object`&&!O.isValidElement(r)?r:{message:r};this.create({id:n,type:`error`,description:a,...o})}else if(e instanceof Error){i=!1;let r=typeof t.error==`function`?await t.error(e):t.error,a=typeof t.description==`function`?await t.description(e):t.description,o=typeof r==`object`&&!O.isValidElement(r)?r:{message:r};this.create({id:n,type:`error`,description:a,...o})}else if(t.success!==void 0){i=!1;let r=typeof t.success==`function`?await t.success(e):t.success,a=typeof t.description==`function`?await t.description(e):t.description,o=typeof r==`object`&&!O.isValidElement(r)?r:{message:r};this.create({id:n,type:`success`,description:a,...o})}}).catch(async e=>{if(a=[`reject`,e],t.error!==void 0){i=!1;let r=typeof t.error==`function`?await t.error(e):t.error,a=typeof t.description==`function`?await t.description(e):t.description,o=typeof r==`object`&&!O.isValidElement(r)?r:{message:r};this.create({id:n,type:`error`,description:a,...o})}}).finally(()=>{i&&(this.dismiss(n),n=void 0),t.finally==null||t.finally.call(t)}),s=()=>new Promise((e,t)=>o.then(()=>a[0]===`reject`?t(a[1]):e(a[1])).catch(t));return typeof n!=`string`&&typeof n!=`number`?{unwrap:s}:Object.assign(n,{unwrap:s})},this.custom=(e,t)=>{let n=le(t);return this.create({...t,jsx:e(n),id:n,type:void 0}),n},this.getActiveToasts=()=>this.toasts.filter(e=>!this.dismissedToasts.has(e.id)),this.subscribers=[],this.toasts=[],this.dismissedToasts=new Set,this.pendingDismissals=new Map}},ue=(e,t)=>F.message(e,t),de=e=>e&&typeof e==`object`&&`ok`in e&&typeof e.ok==`boolean`&&`status`in e&&typeof e.status==`number`,I=Object.assign(ue,{success:F.success,info:F.info,warning:F.warning,error:F.error,custom:F.custom,message:F.message,promise:F.promise,dismiss:F.dismiss,loading:F.loading},{getHistory:()=>F.toasts,getToasts:()=>F.getActiveToasts()});A(`[data-sonner-toaster][dir=ltr],html[dir=ltr]{--toast-icon-margin-start:-3px;--toast-icon-margin-end:4px;--toast-svg-margin-start:-1px;--toast-svg-margin-end:0px;--toast-button-margin-start:auto;--toast-button-margin-end:0;--toast-close-button-start:0;--toast-close-button-end:unset;--toast-close-button-transform:translate(-35%, -35%)}[data-sonner-toaster][dir=rtl],html[dir=rtl]{--toast-icon-margin-start:4px;--toast-icon-margin-end:-3px;--toast-svg-margin-start:0px;--toast-svg-margin-end:-1px;--toast-button-margin-start:0;--toast-button-margin-end:auto;--toast-close-button-start:unset;--toast-close-button-end:0;--toast-close-button-transform:translate(35%, -35%)}[data-sonner-toaster]{position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1:hsl(0, 0%, 99%);--gray2:hsl(0, 0%, 97.3%);--gray3:hsl(0, 0%, 95.1%);--gray4:hsl(0, 0%, 93%);--gray5:hsl(0, 0%, 90.9%);--gray6:hsl(0, 0%, 88.7%);--gray7:hsl(0, 0%, 85.8%);--gray8:hsl(0, 0%, 78%);--gray9:hsl(0, 0%, 56.1%);--gray10:hsl(0, 0%, 52.3%);--gray11:hsl(0, 0%, 43.5%);--gray12:hsl(0, 0%, 9%);--border-radius:8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:0;z-index:999999999;transition:transform .4s ease}@media (hover:none) and (pointer:coarse){[data-sonner-toaster][data-lifted=true]{transform:none}}[data-sonner-toaster][data-x-position=right]{right:var(--offset-right)}[data-sonner-toaster][data-x-position=left]{left:var(--offset-left)}[data-sonner-toaster][data-x-position=center]{left:50%;transform:translateX(-50%)}[data-sonner-toaster][data-y-position=top]{top:var(--offset-top)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--offset-bottom)}[data-sonner-toast]{--y:translateY(100%);--lift-amount:calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:0;overflow-wrap:anywhere}[data-sonner-toast][data-styled=true]{padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px rgba(0,0,0,.1);width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}[data-sonner-toast]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-y-position=top]{top:0;--y:translateY(-100%);--lift:1;--lift-amount:calc(1 * var(--gap))}[data-sonner-toast][data-y-position=bottom]{bottom:0;--y:translateY(100%);--lift:-1;--lift-amount:calc(var(--lift) * var(--gap))}[data-sonner-toast][data-styled=true] [data-description]{font-weight:400;line-height:1.4;color:#3f3f3f}[data-rich-colors=true][data-sonner-toast][data-styled=true] [data-description]{color:inherit}[data-sonner-toaster][data-sonner-theme=dark] [data-description]{color:#e8e8e8}[data-sonner-toast][data-styled=true] [data-title]{font-weight:500;line-height:1.5;color:inherit}[data-sonner-toast][data-styled=true] [data-icon]{display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}[data-sonner-toast][data-promise=true] [data-icon]>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}[data-sonner-toast][data-styled=true] [data-icon]>*{flex-shrink:0}[data-sonner-toast][data-styled=true] [data-icon] svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}[data-sonner-toast][data-styled=true] [data-content]{display:flex;flex-direction:column;gap:2px;flex:1;min-width:0}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;font-weight:500;cursor:pointer;outline:0;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}[data-sonner-toast][data-styled=true] [data-button]:focus-visible{box-shadow:0 0 0 2px rgba(0,0,0,.4)}[data-sonner-toast][data-styled=true] [data-button]:first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}[data-sonner-toast][data-styled=true] [data-cancel]{color:var(--normal-text);background:rgba(0,0,0,.08)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-styled=true] [data-cancel]{background:rgba(255,255,255,.3)}[data-sonner-toast][data-styled=true] [data-close-button]{position:absolute;left:var(--toast-close-button-start);right:var(--toast-close-button-end);top:0;height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;color:var(--normal-text);background:var(--normal-bg);border:1px solid var(--normal-border);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}[data-sonner-toast][data-styled=true] [data-close-button]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-styled=true] [data-disabled=true]{cursor:not-allowed}[data-sonner-toast][data-styled=true]:hover [data-close-button]:hover{background:var(--gray2);border-color:var(--gray5)}[data-sonner-toast][data-swiping=true]::before{content:'';position:absolute;left:-100%;right:-100%;height:100%;z-index:-1}[data-sonner-toast][data-y-position=top][data-swiping=true]::before{bottom:50%;transform:scaleY(3) translateY(50%)}[data-sonner-toast][data-y-position=bottom][data-swiping=true]::before{top:50%;transform:scaleY(3) translateY(-50%)}[data-sonner-toast][data-swiping=false][data-removed=true]::before{content:'';position:absolute;inset:0;transform:scaleY(2)}[data-sonner-toast][data-expanded=true]::after{content:'';position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}[data-sonner-toast][data-mounted=true]{--y:translateY(0);opacity:1}[data-sonner-toast][data-expanded=false][data-front=false]{--scale:var(--toasts-before) * 0.05 + 1;--y:translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--scale)));height:var(--front-toast-height)}[data-sonner-toast]>*{transition:opacity .4s}[data-sonner-toast][data-x-position=right]{right:0}[data-sonner-toast][data-x-position=left]{left:0}[data-sonner-toast][data-expanded=false][data-front=false][data-styled=true]>*{opacity:0}[data-sonner-toast][data-visible=false]{opacity:0;pointer-events:none}[data-sonner-toast][data-mounted=true][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}[data-sonner-toast][data-removed=true][data-front=true][data-swipe-out=false]{--y:translateY(calc(var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=false]{--y:translateY(40%);opacity:0;transition:transform .5s,opacity .2s}[data-sonner-toast][data-removed=true][data-front=false]::before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount-y,0)) translateX(var(--swipe-amount-x,0));transition:none}[data-sonner-toast][data-swiped=true]{-webkit-user-select:none;user-select:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation-duration:.2s;animation-timing-function:ease-out;animation-fill-mode:forwards}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=left]{animation-name:swipe-out-left}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=right]{animation-name:swipe-out-right}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=up]{animation-name:swipe-out-up}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=down]{animation-name:swipe-out-down}@keyframes swipe-out-left{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) - 100%));opacity:0}}@keyframes swipe-out-right{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) + 100%));opacity:0}}@keyframes swipe-out-up{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) - 100%));opacity:0}}@keyframes swipe-out-down{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) + 100%));opacity:0}}@media (max-width:600px){[data-sonner-toaster]{position:fixed;right:var(--mobile-offset-right);left:var(--mobile-offset-left);width:100%}[data-sonner-toaster][dir=rtl]{left:calc(var(--mobile-offset-left) * -1)}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset-left) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset-left)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--mobile-offset-bottom)}[data-sonner-toaster][data-y-position=top]{top:var(--mobile-offset-top)}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset-left);right:var(--mobile-offset-right);transform:none}}[data-sonner-toaster][data-sonner-theme=light]{--normal-bg:#fff;--normal-border:var(--gray4);--normal-text:var(--gray12);--success-bg:hsl(143, 85%, 96%);--success-border:hsl(145, 92%, 87%);--success-text:hsl(140, 100%, 27%);--info-bg:hsl(208, 100%, 97%);--info-border:hsl(221, 91%, 93%);--info-text:hsl(210, 92%, 45%);--warning-bg:hsl(49, 100%, 97%);--warning-border:hsl(49, 91%, 84%);--warning-text:hsl(31, 92%, 45%);--error-bg:hsl(359, 100%, 97%);--error-border:hsl(359, 100%, 94%);--error-text:hsl(360, 100%, 45%)}[data-sonner-toaster][data-sonner-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg:#000;--normal-border:hsl(0, 0%, 20%);--normal-text:var(--gray1)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg:#fff;--normal-border:var(--gray3);--normal-text:var(--gray12)}[data-sonner-toaster][data-sonner-theme=dark]{--normal-bg:#000;--normal-bg-hover:hsl(0, 0%, 12%);--normal-border:hsl(0, 0%, 20%);--normal-border-hover:hsl(0, 0%, 25%);--normal-text:var(--gray1);--success-bg:hsl(150, 100%, 6%);--success-border:hsl(147, 100%, 12%);--success-text:hsl(150, 86%, 65%);--info-bg:hsl(215, 100%, 6%);--info-border:hsl(223, 43%, 17%);--info-text:hsl(216, 87%, 65%);--warning-bg:hsl(64, 100%, 6%);--warning-border:hsl(60, 100%, 9%);--warning-text:hsl(46, 87%, 65%);--error-bg:hsl(358, 76%, 10%);--error-border:hsl(357, 89%, 16%);--error-text:hsl(358, 100%, 81%)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]{background:var(--normal-bg);border-color:var(--normal-border);color:var(--normal-text)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]:hover{background:var(--normal-bg-hover);border-color:var(--normal-border-hover)}[data-rich-colors=true][data-sonner-toast][data-type=success]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size:16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:first-child{animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}100%{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}100%{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}100%{opacity:.15}}@media (prefers-reduced-motion){.sonner-loading-bar,[data-sonner-toast],[data-sonner-toast]>*{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}`);function fe(e){return e.label!==void 0}var pe=3,me=`24px`,L=`16px`,he=4e3,ge=356,_e=14,ve=45,ye=200;function R(...e){return e.filter(Boolean).join(` `)}function be(e){let[t,n]=e.split(`-`),r=[];return t&&r.push(t),n&&r.push(n),r}var z=e=>{let{invert:t,toast:n,unstyled:r,interacting:i,setHeights:a,visibleToasts:o,heights:s,index:c,toasts:l,expanded:u,removeToast:d,defaultRichColors:f,closeButton:p,style:m,cancelButtonStyle:h,actionButtonStyle:g,className:_=``,descriptionClassName:v=``,duration:y,position:b,gap:x,expandByDefault:S,classNames:C,icons:w,closeButtonAriaLabel:T=`Close toast`}=e,[E,ee]=O.useState(null),[te,D]=O.useState(null),[k,A]=O.useState(!1),[re,j]=O.useState(!1),[ae,M]=O.useState(!1),[oe,P]=O.useState(!1),[ce,le]=O.useState(!1),[F,ue]=O.useState(0),[de,I]=O.useState(0),pe=O.useRef(n.duration||y||he),me=O.useRef(null),L=O.useRef(null),ge=c===0,_e=c+1<=o,z=n.type,xe=z??`default`,Se=n.dismissible!==!1,Ce=n.className||``,we=n.descriptionClassName||``,Te=O.useMemo(()=>s.findIndex(e=>e.toastId===n.id)||0,[s,n.id]),Ee=O.useMemo(()=>n.closeButton??p,[n.closeButton,p]),De=O.useMemo(()=>n.duration||y||he,[n.duration,y]),Oe=O.useRef(0),ke=O.useRef(0),Ae=O.useRef(0),je=O.useRef(null),[Me,Ne]=b.split(`-`),Pe=O.useMemo(()=>s.reduce((e,t,n)=>n>=Te?e:e+t.height,0),[s,Te]),Fe=N(),B=O.useMemo(()=>e.swipeDirections??be(b),[e.swipeDirections,b]),Ie=n.invert||t,Le=z===`loading`;ke.current=O.useMemo(()=>Te*x+Pe,[Te,Pe]),O.useEffect(()=>{pe.current=De},[De]),O.useEffect(()=>{A(!0)},[]),O.useEffect(()=>{let e=L.current;if(e){let t=e.getBoundingClientRect().height;return I(t),a(e=>[{toastId:n.id,height:t,position:n.position},...e]),()=>a(e=>e.filter(e=>e.toastId!==n.id))}},[a,n.id]),O.useLayoutEffect(()=>{if(!k)return;let e=L.current,t=e.style.height;e.style.height=`auto`;let r=e.getBoundingClientRect().height;e.style.height=t,I(r),a(e=>e.find(e=>e.toastId===n.id)?e.map(e=>e.toastId===n.id?{...e,height:r}:e):[{toastId:n.id,height:r,position:n.position},...e])},[k,n.title,n.description,a,n.id,n.jsx,n.action,n.cancel]);let Re=O.useCallback(()=>{j(!0),ue(ke.current),a(e=>e.filter(e=>e.toastId!==n.id)),setTimeout(()=>{d(n)},ye)},[n,d,a,ke]);O.useEffect(()=>{if(n.promise&&z===`loading`||n.duration===1/0||n.type===`loading`)return;let e;return u||i||Fe?(()=>{if(Ae.current<Oe.current){let e=new Date().getTime()-Oe.current;pe.current-=e}Ae.current=new Date().getTime()})():pe.current!==1/0&&(Oe.current=new Date().getTime(),e=setTimeout(()=>{n.onAutoClose==null||n.onAutoClose.call(n,n),Re()},pe.current)),()=>clearTimeout(e)},[u,i,n,z,Fe,Re]),O.useEffect(()=>{n.delete&&(Re(),n.onDismiss==null||n.onDismiss.call(n,n))},[Re,n.delete]);function ze(){return w?.loading?O.createElement(`div`,{className:R(C?.loader,n?.classNames?.loader,`sonner-loader`),"data-visible":z===`loading`},w.loading):O.createElement(ie,{className:R(C?.loader,n?.classNames?.loader),visible:z===`loading`})}let Be=n.icon||w?.[z]||ne(z);return O.createElement(`li`,{tabIndex:0,ref:L,className:R(_,Ce,C?.toast,n?.classNames?.toast,C?.[xe],n?.classNames?.[xe]),"data-sonner-toast":``,"data-rich-colors":n.richColors??f,"data-styled":!(n.jsx||n.unstyled||r),"data-mounted":k,"data-promise":!!n.promise,"data-swiped":ce,"data-removed":re,"data-visible":_e,"data-y-position":Me,"data-x-position":Ne,"data-index":c,"data-front":ge,"data-swiping":ae,"data-dismissible":Se,"data-type":z,"data-invert":Ie,"data-swipe-out":oe,"data-swipe-direction":te,"data-expanded":!!(u||S&&k),"data-testid":n.testId,style:{"--index":c,"--toasts-before":c,"--z-index":l.length-c,"--offset":`${re?F:ke.current}px`,"--initial-height":S?`auto`:`${de}px`,...m,...n.style},onDragEnd:()=>{M(!1),ee(null),je.current=null},onPointerDown:e=>{e.button!==2&&!Le&&Se&&(me.current=new Date,ue(ke.current),e.target.setPointerCapture(e.pointerId),e.target.tagName!==`BUTTON`&&(M(!0),je.current={x:e.clientX,y:e.clientY}))},onPointerUp:()=>{if(oe||!Se)return;je.current=null;let e=Number(L.current?.style.getPropertyValue(`--swipe-amount-x`).replace(`px`,``)||0),t=Number(L.current?.style.getPropertyValue(`--swipe-amount-y`).replace(`px`,``)||0),r=new Date().getTime()-me.current?.getTime(),i=E===`x`?e:t,a=Math.abs(i)/r;if((E===`x`?B.includes(e>0?`right`:`left`):B.includes(t>0?`bottom`:`top`))&&(Math.abs(i)>=ve||a>.11)){ue(ke.current),n.onDismiss==null||n.onDismiss.call(n,n),D(E===`x`?e>0?`right`:`left`:t>0?`down`:`up`),Re(),P(!0);return}var o,s;(o=L.current)==null||o.style.setProperty(`--swipe-amount-x`,`0px`),(s=L.current)==null||s.style.setProperty(`--swipe-amount-y`,`0px`),le(!1),M(!1),ee(null)},onPointerMove:e=>{var t,n;if(!je.current||!Se||window.getSelection()?.toString().length>0)return;let r=e.clientY-je.current.y,i=e.clientX-je.current.x;!E&&(Math.abs(i)>1||Math.abs(r)>1)&&ee(Math.abs(i)>Math.abs(r)?`x`:`y`);let a={x:0,y:0},o=e=>1/(1.5+Math.abs(e)/20);if(E===`y`){if(B.includes(`top`)||B.includes(`bottom`)){if(B.includes(`top`)&&r<0||B.includes(`bottom`)&&r>0)a.y=r;else{let e=r*o(r);a.y=Math.abs(e)<Math.abs(r)?e:r}}}else if(E===`x`&&(B.includes(`left`)||B.includes(`right`))){if(B.includes(`left`)&&i<0||B.includes(`right`)&&i>0)a.x=i;else{let e=i*o(i);a.x=Math.abs(e)<Math.abs(i)?e:i}}(Math.abs(a.x)>0||Math.abs(a.y)>0)&&le(!0),(t=L.current)==null||t.style.setProperty(`--swipe-amount-x`,`${a.x}px`),(n=L.current)==null||n.style.setProperty(`--swipe-amount-y`,`${a.y}px`)}},Ee&&!n.jsx&&z!==`loading`?O.createElement(`button`,{"aria-label":T,"data-disabled":Le,"data-close-button":!0,onClick:Le||!Se?()=>{}:()=>{Re(),n.onDismiss==null||n.onDismiss.call(n,n)},className:R(C?.closeButton,n?.classNames?.closeButton)},w?.close??se):null,(z||n.icon||n.promise)&&n.icon!==null&&(w?.[z]!==null||n.icon)?O.createElement(`div`,{"data-icon":``,className:R(C?.icon,n?.classNames?.icon)},z===`loading`?n.icon||ze():n.promise?ze():null,z===`loading`?null:Be):null,O.createElement(`div`,{"data-content":``,className:R(C?.content,n?.classNames?.content)},O.createElement(`div`,{"data-title":``,className:R(C?.title,n?.classNames?.title)},n.jsx?n.jsx:typeof n.title==`function`?n.title():n.title),n.description?O.createElement(`div`,{"data-description":``,className:R(v,we,C?.description,n?.classNames?.description)},typeof n.description==`function`?n.description():n.description):null),O.isValidElement(n.cancel)?n.cancel:n.cancel&&fe(n.cancel)?O.createElement(`button`,{"data-button":!0,"data-cancel":!0,style:n.cancelButtonStyle||h,onClick:e=>{fe(n.cancel)&&Se&&(n.cancel.onClick==null||n.cancel.onClick.call(n.cancel,e),Re())},className:R(C?.cancelButton,n?.classNames?.cancelButton)},n.cancel.label):null,O.isValidElement(n.action)?n.action:n.action&&fe(n.action)?O.createElement(`button`,{"data-button":!0,"data-action":!0,style:n.actionButtonStyle||g,onClick:e=>{fe(n.action)&&(n.action.onClick==null||n.action.onClick.call(n.action,e),!e.defaultPrevented&&Re())},className:R(C?.actionButton,n?.classNames?.actionButton)},n.action.label):null)};function xe(){if(typeof window>`u`||typeof document>`u`)return`ltr`;let e=document.documentElement.getAttribute(`dir`);return e===`auto`||!e?window.getComputedStyle(document.documentElement).direction:e}function Se(e,t){let n={};return[e,t].forEach((e,t)=>{let r=t===1,i=r?`--mobile-offset`:`--offset`,a=r?L:me;function o(e){[`top`,`right`,`bottom`,`left`].forEach(t=>{n[`${i}-${t}`]=typeof e==`number`?`${e}px`:e})}typeof e==`number`||typeof e==`string`?o(e):typeof e==`object`?[`top`,`right`,`bottom`,`left`].forEach(t=>{e[t]===void 0?n[`${i}-${t}`]=a:n[`${i}-${t}`]=typeof e[t]==`number`?`${e[t]}px`:e[t]}):o(a)}),n}var Ce=O.forwardRef(function(e,t){let{id:n,invert:r,position:i=`bottom-right`,hotkey:a=[`altKey`,`KeyT`],expand:o,closeButton:s,className:c,offset:l,mobileOffset:u,theme:d=`light`,richColors:f,duration:p,style:m,visibleToasts:h=pe,toastOptions:g,dir:_=xe(),gap:v=_e,icons:y,customAriaLabel:b,containerAriaLabel:x=`Notifications`}=e,[S,C]=O.useState([]),w=O.useMemo(()=>n?S.filter(e=>e.toasterId===n):S.filter(e=>!e.toasterId),[S,n]),T=O.useMemo(()=>Array.from(new Set([i].concat(w.filter(e=>e.position).map(e=>e.position)))),[w,i]),[E,ee]=O.useState([]),[te,D]=O.useState(!1),[A,ne]=O.useState(!1),[re,ie]=O.useState(d===`system`?typeof window<`u`&&window.matchMedia&&window.matchMedia(`(prefers-color-scheme: dark)`).matches?`dark`:`light`:d),j=O.useRef(null),ae=a.join(`+`).replace(/Key/g,``).replace(/Digit/g,``),M=O.useRef(null),oe=O.useRef(!1),se=O.useCallback(e=>{C(t=>(t.find(t=>t.id===e.id)?.delete||F.dismiss(e.id),t.filter(({id:t})=>t!==e.id)))},[]);return O.useEffect(()=>F.subscribe(e=>{if(e.dismiss){requestAnimationFrame(()=>{C(t=>t.map(t=>t.id===e.id?{...t,delete:!0}:t))});return}setTimeout(()=>{k.flushSync(()=>{C(t=>{let n=t.findIndex(t=>t.id===e.id);return n===-1?[e,...t]:[...t.slice(0,n),{...t[n],...e},...t.slice(n+1)]})})})}),[]),O.useEffect(()=>{if(d!==`system`){ie(d);return}if(d===`system`&&(window.matchMedia&&window.matchMedia(`(prefers-color-scheme: dark)`).matches?ie(`dark`):ie(`light`)),typeof window>`u`)return;let e=window.matchMedia(`(prefers-color-scheme: dark)`);try{e.addEventListener(`change`,({matches:e})=>{ie(e?`dark`:`light`)})}catch{e.addListener(({matches:e})=>{try{ie(e?`dark`:`light`)}catch(e){console.error(e)}})}},[d]),O.useEffect(()=>{S.length<=1&&D(!1)},[S]),O.useEffect(()=>{let e=e=>{if(a.length>0&&a.every(t=>e[t]||e.code===t)){var t;D(!0),(t=j.current)==null||t.focus()}e.code===`Escape`&&(document.activeElement===j.current||j.current?.contains(document.activeElement))&&D(!1)};return document.addEventListener(`keydown`,e),()=>document.removeEventListener(`keydown`,e)},[a]),O.useEffect(()=>{if(j.current)return()=>{M.current&&(M.current.focus({preventScroll:!0}),M.current=null,oe.current=!1)}},[j.current]),O.createElement(`section`,{ref:t,"aria-label":b??`${x} ${ae}`,tabIndex:-1,"aria-live":`polite`,"aria-relevant":`additions text`,"aria-atomic":`false`,suppressHydrationWarning:!0,"data-react-aria-top-layer":!0},T.map((t,n)=>{let[i,a]=t.split(`-`);return w.length?O.createElement(`ol`,{key:t,dir:_===`auto`?xe():_,tabIndex:-1,ref:j,className:c,"data-sonner-toaster":!0,"data-sonner-theme":re,"data-y-position":i,"data-x-position":a,style:{"--front-toast-height":`${E[0]?.height||0}px`,"--width":`${ge}px`,"--gap":`${v}px`,...m,...Se(l,u)},onBlur:e=>{oe.current&&!e.currentTarget.contains(e.relatedTarget)&&(oe.current=!1,M.current&&=(M.current.focus({preventScroll:!0}),null))},onFocus:e=>{e.target instanceof HTMLElement&&e.target.dataset.dismissible===`false`||oe.current||(oe.current=!0,M.current=e.relatedTarget)},onMouseEnter:()=>D(!0),onMouseMove:()=>D(!0),onMouseLeave:()=>{A||D(!1)},onDragEnd:()=>D(!1),onPointerDown:e=>{e.target instanceof HTMLElement&&e.target.dataset.dismissible===`false`||ne(!0)},onPointerUp:()=>ne(!1)},w.filter(e=>!e.position&&n===0||e.position===t).map((n,i)=>O.createElement(z,{key:n.id,icons:y,index:i,toast:n,defaultRichColors:f,duration:g?.duration??p,className:g?.className,descriptionClassName:g?.descriptionClassName,invert:r,visibleToasts:h,closeButton:g?.closeButton??s,interacting:A,position:t,style:g?.style,unstyled:g?.unstyled,classNames:g?.classNames,cancelButtonStyle:g?.cancelButtonStyle,actionButtonStyle:g?.actionButtonStyle,closeButtonAriaLabel:g?.closeButtonAriaLabel,removeToast:se,toasts:w.filter(e=>e.position==n.position),heights:E.filter(e=>e.position==n.position),setHeights:ee,expandByDefault:o,gap:v,expanded:te,swipeDirections:e.swipeDirections}))):null}))});function we(e){return e!==`__proto__`&&e!==`constructor`&&e!==`prototype`}function Te(e,t){let n=Object.create(null);if(e)for(let t of Object.keys(e))we(t)&&(n[t]=e[t]);if(t&&typeof t==`object`)for(let e of Object.keys(t))we(e)&&(n[e]=t[e]);return n}function Ee(e){if(!e)return Object.create(null);let t=Object.create(null);for(let n of Object.keys(e))we(n)&&(t[n]=e[n]);return t}var De=()=>{throw Error(`createServerOnlyFn() functions can only be called on the server!`)},Oe=(t,n)=>{let r=n||t||{};r.method===void 0&&(r.method=`GET`);let i=e=>Oe(void 0,{...r,validator:e,inputValidator:e});return Object.assign(e=>Oe(void 0,{...r,...e}),{options:r,middleware:e=>{let t=[...r.middleware||[]];e.forEach(e=>{s in e?e.options.middleware&&t.push(...e.options.middleware):t.push(e)});let n=Oe(void 0,{...r,middleware:t});return n[s]=!0,n},validator:i,inputValidator:i,handler:(...t)=>{let[n,i]=t,a={...r,extractedFn:n,serverFn:i},o=[...a.middleware||[],Me(a)];return n.method=r.method,Object.assign(async t=>{let r=await ke(o,`client`,{...n,...a,data:t?.data,headers:t?.headers,signal:t?.signal,fetch:t?.fetch,context:Ee()}),i=e(r.error);if(i)throw i;if(r.error)throw r.error;return r.result},{...n,method:r.method,__executeServer:async e=>{let t=De(),i=t.contextAfterGlobalMiddlewares;return await ke(o,`server`,{...n,data:e.data,method:e.method??r.method,serverFnMeta:n.serverFnMeta,context:Te(e.context,i),request:t.request}).then(e=>({result:e.result,error:e.error,context:e.sendContext}))}})}})};async function ke(e,t,r){let i=Ae([...a()?.functionMiddleware||[],...e]);if(t===`server`){let e=De({throwIfNotFound:!1});e?.executedRequestMiddlewares&&(i=i.filter(t=>!e.executedRequestMiddlewares.has(t)))}let o=async e=>{let r=i.shift();if(!r)return e;try{let i=`validator`in r.options?r.options.validator:void 0;!i&&`inputValidator`in r.options&&(i=r.options.inputValidator),i&&t===`server`&&(e.data=await je(i,e.data));let a;if(t===`client`?`client`in r.options&&(a=r.options.client):`server`in r.options&&(a=r.options.server),a){let t=async(t={})=>{let n=await o({...e,...t,context:Te(e.context,t.context),sendContext:Te(e.sendContext,t.sendContext),headers:f(e.headers,t.headers),_callSiteFetch:e._callSiteFetch,fetch:e._callSiteFetch??t.fetch??e.fetch,result:t.result===void 0?t instanceof Response?t:e.result:t.result,error:t.error??e.error});if(n.error)throw n.error;return n},r=await a({...e,next:t});if(n(r))return{...e,error:r};if(r instanceof Response)return{...e,result:r};if(!r)throw Error(`User middleware returned undefined. You must call next() or return a result in your middlewares.`);return r}return o(e)}catch(t){return{...e,error:t}}};return o({...r,headers:r.headers||{},sendContext:r.sendContext||{},context:r.context||Ee(),_callSiteFetch:r.fetch})}function Ae(e,t=100){let n=new Set,r=[],i=(e,a)=>{if(a>t)throw Error(`Middleware nesting depth exceeded maximum of ${t}. Check for circular references.`);e.forEach(e=>{e.options.middleware&&i(e.options.middleware,a+1),n.has(e)||(n.add(e),r.push(e))})};return i(e,0),r}async function je(e,t){if(e==null)return{};if(`~standard`in e){let n=await e[`~standard`].validate(t);if(n.issues)throw Error(JSON.stringify(n.issues,void 0,2));return n.value}if(`parse`in e)return e.parse(t);if(typeof e==`function`)return e(t);throw Error(`Invalid validator type!`)}function Me(e){return{"~types":void 0,options:{inputValidator:e.validator??e.inputValidator,client:async({next:t,sendContext:n,fetch:r,...i})=>{let a={...i,context:n,fetch:r};return t(await e.extractedFn?.(a))},server:async({next:t,...n})=>{let r=await e.serverFn?.(n);return t({...n,result:r})}}}}var Ne=Oe({method:`POST`}).handler(o(`bf41790866200090c2e98d8635870116685a89794264040ae816b9d8460360f2`));function Pe(){if(typeof window<`u`)try{let e=new(window.AudioContext||window.webkitAudioContext),t=e.currentTime,n=(t,n,r)=>{let i=e.createOscillator(),a=e.createGain();i.type=`sine`,i.frequency.value=t,a.gain.setValueAtTime(1e-4,n),a.gain.exponentialRampToValueAtTime(.07,n+.02),a.gain.exponentialRampToValueAtTime(1e-4,n+r),i.connect(a),a.connect(e.destination),i.start(n),i.stop(n+r+.02)};n(880,t,.12),n(1174,t+.14,.16),window.setTimeout(()=>void e.close(),600)}catch{}}async function Fe(){return typeof window>`u`||!(`Notification`in window)?!1:Notification.permission===`granted`||Notification.permission!==`denied`&&await Notification.requestPermission()===`granted`}function B(e){if(typeof window<`u`&&`Notification`in window&&Notification.permission===`granted`)try{new Notification(`SandıqRadar`,{body:e,tag:`sandiqradar-box`})}catch{}}var Ie=[{id:`kind`,title:`Dəqiq növ`,detail:`Sandıq, hədiyyə çantası, zərf, portal və şans qutusu business_type + ad siqnalları ilə ayrılır.`},{id:`viewers`,title:`Canlıda nəfər`,detail:`Cari otaq sayı (user_count). Enter_count ümumi girişdir, baxış kimi götürülmür.`},{id:`joined`,title:`Sandığa qoşulan`,detail:`Qoşulan / yer sayı (joined/slots) progress bar ilə.`},{id:`rate`,title:`Rate`,detail:`Jeton ÷ yer. Minimum rate filtrinə düşməyənlər Telegram-a getmir.`},{id:`remain`,title:`Qalan vaxt`,detail:`unpack_at və remain_time-dan gerisayım.`},{id:`dup`,title:`Duplicate qoruma`,detail:`Eyni box_id bir dəfə xəbərdarlıq edir, bitəndə açar silinir.`},{id:`id`,title:`Dəqiq unique_id`,detail:`ramiz_real1 ramiz_real sayılmır. Durğu işarəsi dəqiq eyni olmalıdır.`},{id:`status`,title:`Yalnız status=2`,detail:`status=4 offline-dur, səhvən canlı göstərilmir.`},{id:`stealth`,title:`Stealth rejim`,detail:`Aşağı paralel, jitter, insan tempi — TikTok WAF-ı az oyadır.`},{id:`cookie`,title:`Cookie warmup`,detail:`ttwid/msToken sessiyası tiktok.com-dan götürülür və sorğulara yapışdırılır.`},{id:`ua`,title:`UA rotasiyası`,detail:`Chrome/Safari/Firefox + uyğun sec-ch-ua Client Hints.`},{id:`device`,title:`Cihaz izi`,detail:`Hər sessiyada təsadüfi device_id, ekran və dil parametrləri.`},{id:`backoff`,title:`Backoff`,detail:`403/429/503-də eksponensial yavaşlama və circuit breaker.`},{id:`multi`,title:`Multi-endpoint`,detail:`api-live, webcast, m.tiktok, HTML hydration ehtiyatı.`},{id:`boxapi`,title:`Sandıq API-ləri`,detail:`room/info, envelope/list, room/enter eyni otaqda növü dəqiqləşdirir.`},{id:`priority`,title:`Prioritet kanallar`,detail:`Seçilmiş adlar hər dövrdə birinci yoxlanır.`},{id:`filters`,title:`Filtrlər`,detail:`Min baxış, min jeton, min rate, canlı/sandıq/offline.`},{id:`sound`,title:`Səs siqnalı`,detail:`Sandıq tapılanda qısa ton.`},{id:`notify`,title:`Brauzer bildirişi`,detail:`Növ + nəfər sayı bildiriş mətnində.`},{id:`export`,title:`İxrac`,detail:`Xəbərdarlıqları JSON və CSV kimi endir.`},{id:`sort`,title:`Sıralama`,detail:`Baxış, rate və vaxta görə.`},{id:`stats`,title:`Statistika`,detail:`Uğur, blok faizi, yoxlama/saniyə, peak baxış.`},{id:`tg`,title:`Telegram`,detail:`Növ, canlıdakı nəfər, qoşulan, rate, qalan vaxt — dublikatsız.`},{id:`probe`,title:`Dərin yoxlama`,detail:`Tək ad üçün növ + nəfər + etibar faizi.`},{id:`peak`,title:`Peak baxış`,detail:`Yayım ərzində ən yüksək nəfər sayı saxlanır.`},{id:`title`,title:`Yayım başlığı`,detail:`Otaq title-ı kartda və Telegram-da.`},{id:`sender`,title:`Göndərən`,detail:`Sandığı atan unique_id (varsa).`},{id:`conf`,title:`Etibar faizi`,detail:`Növ təsnifatının nə qədər əmin olduğu.`},{id:`autopause`,title:`Avto-pauza`,detail:`Blok dalğasında tarama özü yavaşlayır, sonra davam edir.`},{id:`proxy`,title:`Proxy (Python)`,detail:`VPS-də residential proxy + per-proxy cookie. Datacenter IP bloklanır.`},{id:`watch`,title:`Canlı izləmə`,detail:`Tapılan otaq sandıq üçün sıx poll edilir, offline olanda dayanır.`},{id:`list`,title:`Siyahı idxal`,detail:`500+ dəqiq unique_id, oxşar ad yoxdur.`}],Le=e=>{let t,n=new Set,r=(e,r)=>{let i=typeof e==`function`?e(t):e;if(!Object.is(i,t)){let e=t;t=r??(typeof i!=`object`||!i)?i:Object.assign({},t,i),n.forEach(n=>n(t,e))}},i=()=>t,a={setState:r,getState:i,getInitialState:()=>o,subscribe:e=>(n.add(e),()=>n.delete(e))},o=t=e(r,i,a);return a},Re=(e=>e?Le(e):Le),ze=e=>e;function Be(e,t=ze){let n=O.useSyncExternalStore(e.subscribe,O.useCallback(()=>t(e.getState()),[e,t]),O.useCallback(()=>t(e.getInitialState()),[e,t]));return O.useDebugValue(n),n}var Ve=e=>{let t=Re(e),n=e=>Be(t,e);return Object.assign(n,t),n},He=(e=>e?Ve(e):Ve);function Ue(e,t){let n;try{n=e()}catch{return}return{getItem:e=>{let r=e=>e===null?null:JSON.parse(e,t?.reviver),i=n.getItem(e)??null;return i instanceof Promise?i.then(r):r(i)},setItem:(e,r)=>n.setItem(e,JSON.stringify(r,t?.replacer)),removeItem:e=>n.removeItem(e)}}var We=e=>t=>{try{let n=e(t);return n instanceof Promise?n:{then(e){return We(e)(n)},catch(e){return this}}}catch(e){return{then(e){return this},catch(t){return We(t)(e)}}}},Ge=(e,t)=>(n,r,i)=>{let a={storage:Ue(()=>window.localStorage),partialize:e=>e,version:0,merge:(e,t)=>({...t,...e}),...t},o=!1,s=0,c=new Set,l=new Set,u=a.storage;if(!u)return e((...e)=>{console.warn(`[zustand persist middleware] Unable to update item '${a.name}', the given storage is currently unavailable.`),n(...e)},r,i);let d=()=>{let e=a.partialize({...r()});return u.setItem(a.name,{state:e,version:a.version})},f=i.setState;i.setState=(e,t)=>(f(e,t),d());let p=e((...e)=>(n(...e),d()),r,i);i.getInitialState=()=>p;let m,h=()=>{if(!u)return;let e=++s;o=!1,c.forEach(e=>e(r()??p));let t=a.onRehydrateStorage?.call(a,r()??p)||void 0;return We(u.getItem.bind(u))(a.name).then(e=>{if(e){if(typeof e.version==`number`&&e.version!==a.version){if(a.migrate){let t=a.migrate(e.state,e.version);return t instanceof Promise?t.then(e=>[!0,e]):[!0,t]}console.error(`State loaded from storage couldn't be migrated since no migrate function was provided`)}else return[!1,e.state]}return[!1,void 0]}).then(t=>{if(e!==s)return;let[i,o]=t;if(m=a.merge(o,r()??p),n(m,!0),i)return d()}).then(()=>{e===s&&(t?.(r(),void 0),m=r(),o=!0,l.forEach(e=>e(m)))}).catch(n=>{e===s&&t?.(void 0,n)})};return i.persist={setOptions:e=>{a={...a,...e},e.storage&&(u=e.storage)},clearStorage:()=>{++s,u?.removeItem(a.name)},getOptions:()=>a,rehydrate:()=>h(),hasHydrated:()=>o,onHydrate:e=>(c.add(e),()=>{c.delete(e)}),onFinishHydration:e=>(l.add(e),()=>{l.delete(e)})},a.skipHydration||h(),m||p},Ke=Oe({method:`POST`}).handler(o(`cf4e33755709492a11bb9481d4c66b8242f1f8cb7a69ec3202f23e3efab32844`)),qe=Oe({method:`POST`}).handler(o(`546d6aaf7a0a06d24e79f90b87080c080c75d7b7dbb2f0a3bcfbe355bff243a5`));function V(e){return Math.round(e).toLocaleString(`az-AZ`)}function Je(e){return Number.isFinite(e)?e===Math.trunc(e)?String(e):e.toFixed(2):`0`}function Ye(e){return e.replace(/\\/g,`\\\\`).replace(/_/g,`\\_`).replace(/\*/g,`\\*`).replace(/`/g,"\\`").replace(/\[/g,`\\[`)}function Xe(e){let t=e.remainSec&&e.remainSec>0?`\n⏱ **Qalan vaxt:** ${e.remainSec} san`:``,n=e.title?`\n📺 **Yayım:** ${Ye(e.title)}`:``,r=e.sender?`\n✍️ **Göndərən:** @${Ye(e.sender)}`:``,i=e.confidence?`\n🎯 **Növ etibarı:** ${Math.round(e.confidence)}%`:``,a=e.peakViewers&&e.peakViewers>e.viewers?` (peak ${V(e.peakViewers)})`:``;return[`🚨 **CANLI VƏ QUTU TAPILDI!** 🚨`,``,`👤 **İstifadəçi:** @${Ye(e.username)}`,`🎁 **Növ:** ${Ye(e.giftType)}`,`👀 **Canlıda nəfər:** ${V(e.viewers)}${a}`,`📊 **Bölgü:** ${e.totalCoins}/${e.totalSlots} jeton/yer`,`💎 **Rate:** ${Je(e.rate)} jeton/nəfər`,`👥 **Qutuya qoşulan:** ${V(e.participants)} / ${V(e.totalSlots)} nəfər${n}${r}${t}${i}`,`🔗 **Canlı yayım:** [Yayıma Keç](${e.liveUrl})`].join(`
`)}function Ze(e){return`@${e.username} · ${e.giftType} · canlıda ${V(e.viewers)} nəfər · ${e.totalCoins}/${e.totalSlots} · rate ${Je(e.rate)}`}var Qe=`w777789,incirteroristiayan,jungminjaeda,versace76_,aldim_ve_getdim,shunshun1130,lun_shao,algorithmtechschool,zevs_show,youssef.iioq0,tyt_mixa_tyta,andreaprisco.22,keremuner,elsevervusal,sawyerthomson0,tjr_tradez,itslucasgracia,ddine_sz,tn_20606,mrsfazlieva,claudiasonson5,berdeavto100yedek,mulletmafia747,tekiso0929,rehim163,cindysiclaudia,adda88a,dragonduu124,tasbsjsk2,user4532882334,fantasy4lifemain,ksummm888,berdosik5757,oz.92k,2tthang,eugeniaup,blue_blue2911,aras_0791gmail,petch_itthi,araki_muscle,tumz0202,bahri813,35___54,chinami118,ninaketaren,ponpokorin311,kazutan1116,luz.deyling.flores,ipelex1,almor3eba,skorpik3456899,leoalcy,chaaithuong,baiibaifernfern,inuinuinuvu,rodrigo_ganem,aot_suta,sion..0502,188168yy,aylie505,quianna.nana,sakura37.m,useryurino_0111,momiji..ll,yusqa.97,y_w_o_o,l_ibra85,prannn,shnookie_x,sapa.caryyew1,rupia_zard,meronchan19,miiiiiin06,thinasuke,laudyismail888,kizunatti111,azizulhelm1,junt120,nazym_sw_,ceys.34,90d9g,colestytan,actor_2kang,runrun652,mandiecane_,banadokunma96,myunx_o0,taryel9.9.9,kay7xisking,ogdvbhf,user3413536268610,dygw2p6cm831,nanashiki_ry1,vitormagalh_,fegermadid32j4zo,user1396166918477,stayblessmusic,allahqorusun099,weare.vixen_,ya096i1,rinrinrin03040,lsywa1,mummaof6girls2boys,dyih0wd8ibmh,zen___j,saikonausagichan,kuro_969698,linxi1114888,iam.kath0,vvchamavv,aunny_anchali,edoss580,yujiho7778,taroutoki701,s_gg019,d819697,sena344646,dachanuda,dothanhbinh2512,h.dieu_ancut,davidnachtham,misa__3311,dydnlmk1vlr4,duy.c3620,nhatkhang12341,foreverloveyourself4,xin_nhe_cai_top36,luctrungquan4,luonghung.04,hind.x1992,ateliedalolaibitinga,jaoaornurse,dong__gi,in26222595,danielhunt88,mopkil,i3rara,o5__yya,beppu_chan,ashleyp890,hono.1225,horuslives,marinka14023,ninikang2,userdaidaidaidayo,hongyeu371,thin1211s,88_gayush_88,sasha13.1,obirmardinli_47_,anhtiktokdepzaittacckhoe,tqd305,shisha44free,xinyu_316,liliana.591,sparkie.boy04,v.hxy_0227,batea84,hazuki.sumile,chywv5,javidd26,popeye_5268,1__7__m,u.uura,marumaru6710,investidor_007,k7__7,armine.dawtyan,tduongg1908,mayu_129_manapanda,takutok25,ya.02,n.a.r.e22.22,itzarhneetar,faynyy.pan,dek7miopd,jiiko03270,froggysparklesmain1,budbudsabong797,doss_251,youngju2,zhizhi0117,user2323563367,liveeveryday.np,boz_qurt37,fan.fan378,username1114556,acimasiz02636229,hrrem.sultan3151,7nihadd,geldim.vurdum.01,yap10_geri_qayitdi,shtormichik,vaqodu_0001,ahhmantapp_crott,redbullaz,zver_on,ekberows_her_yerde1,ramiz_real,fmva9,posta.com.tr,heyvan_dunyasi12,skuter_samokat,nizami1022,01anaf01,wolt_azerbaijan,e6srider,n1toys0,mehhmetdragos,amchefdemisto,jooe907,danielstefu10,nm_livepro,queenmalik829,mr.barberuslan,officialmoustafamansour,global1joe,thom_babyy,anul__01,lomii733,tonystark060489,eltorquee,longxucxich.tuongot,h_kyung_176,lady.546,abusaif7070,aziz1990m1,edelinmathernature,rlkjota717,crvglopes98,madz_l24,maa.0510,geycikhaleesi,caiquizadaa,luizx7,zezev99,nuriiyev11,theusjosee,viniproducoesmusicais,hugorodelomusica,daa_on,bubbles0042,ricopin828,calm_lake223,jjangbbae,arin_960520,n..n789,azzamusicofficial,aisha.10tn,tannarll,bb_bbb_ultimate,adrianilies606,music_journey_01,sasticateaud,finc.mafia,mcjehda6_,ricxrdo.04,iishaaa_______,vit.r___,sokun0703,harbisari,neno..2727,mrsaitamavk2,joowon2103,richtzu888,ludere_deorum,ozune_hormet_qoy,gaarlic0921,kitty.na2,ryuji5_9,leoopostal,phil102545,ice3330120,itsme.chads,aussieveteran90,brunasaltorio,yuki_vrcats,kai_da75,supermum8_tt,donald_duck.1934.6.9,maurogmerican,qamarl07,iulianamatei86,tanesiinci,tullo.ostilio.82,chrixxxferr,bee9191,marvin_parcutilovibes,theodoresikiri,jussyercarvalho,skgotcha,minhhieudepzaicogisai,qaraqiz_1111,ahmed_optimist,m.martinez0417,osmantu079,hoanthien2608,cakaufa_magelang,ahmadsan33,almajhool201,al1000l00,raflesia074,cristina.23677,alessia_nare,dana_mvp,marochinoomochi,chronos_luka,bismillahkunfayakun23,dilaracimss,asem.dwairi,ksiyytw,starim.0,goktugkaynarr,k965h,nixon.3a21,anukunwar6,marino1220,vi_ew55,heyyimvv,belimeatimieludepasti,animal.hisaashii,al9saqr,bastichillma_official,hasank55,camilacorsinooo,luccas.valentine,microp_,mrdubaitop1,sevgimsen111_,midaswellquit,ilovetoptop93,aainn_621,mu_mu_mumumu,starbuc37,kaurato3,89shota89,maaami124,klauslove,shotaccc,.qara_010,zerosei_06,machiko.sensei,dr.account.xxx,soltan.usa,lookoutsnipe,cihan.ahnas4,nermanov_313,5mooii,ml212,dunghelthy8,hardcorrider01,viroza_1,nosinger487,litoriacaerulea,user377945497,star_universe_ever,ormankrallarii,courtneyfok,nodypc,daniel_wiwatwong,mijoo_lovely,bordobrli47,katsudonchan1,thachkieu10.02,user_edit6660,toshi_0042,emi_ocagi,mostfamahmod11,nasa_nebunilor,henz_construction,ninelli09,dekdiyah1,gabbycarina,hurdaci01.34,therebel937,dianamihali0,danielkrusee,zusminero,abbasalbloushivip,925ayar,brutall_2.0,mialily.jp,neoesram,chipomiru,zegkhv2030,indry_yuhuuu,vuong36au_2,aure_lian22222,erenn8690,userodukh76aec,cristinacristina664,user_13.alb_pe_negru,elnur___071,memmedova_roya_,raskon..m,user79014385,mehmetcengizank1,zorilaionpaul,agalokbatanlimahnilar,muhammed_glmsr34,brunetykaa,..ddelviago,ahmed_ali1_4,1dazel,maskelihatun49,candanote4142,gal_x77,w65m,alia_btp19,krieim34,endjulia_,son33.4,loaysokker,chinho.tm,a.e..001,eliyev0555,omarelnawawy96,ay_nuray_045,emilaghyv,ferahimkarimxanli,elen.111_,by_kamran_,m7md.tv,ko..056,hadi.hr1,devrim_47,mrmoldovan,psiholog.antonia,lafrandjaxerie,rzayevbehruz048,karadayi78,bomiiibomiii1,hangi_ferit,malak1a62,bodaaa5atar,pablokiss24,viroza_00,andorre01,atakishiev_97,sngabo6,ayxangeldi.44,hab.123h.3,memmedov8273,mr_lequar_aldima,ddo__xi1,kotobuki.twk,closednaw,natan0326nn210,muammerabrahams74,soli_moli888,jhonnathanmerchan,lelinho255,silasoil,lachocolatebiencuidada,mhamedahmdd,kemo___313,annefloor10,cj7.502,vankhanhkdzz,marrenta973,boopbianx,jandersonluis07,mizberesford007,jayvionthefront,nwa_milk05,soyelmicko,thescyyx,gaucho.do.tik.tok,rosariopsq,wwa5.23,morningstar_rj,nurllahy,a.zanza0,anadodo884,nehir_3434nn,papipopu____,alshaahin03,p.pimmo236,sadecekubos,hiatus.duluu,welorax._,ellaaeyo,samicadenaa,dragon_king_1989,3amo.samy.king0fgame,am_an206,dselinkose,.szandika,djandik8,yayinciogretmen1,live.streaming.se,goodybagtreasurebox,sultanofcoin,tambahfollowers.live,coinkrewe,takipyayini0000,tangkapfollowers.live,supportfollowerslive,growup.followers,coin.10.0004,coin10.0001,upfollowersaffiliatefyp,tangkap.mining.followers,romantik.haydut,italia__10,ahmadbakr7354,wepstore_567,theking_moha,vv9i,.yeraz_111,.mm...56,farid444,topdanoyuncaq.absheron,728.m,ikrxllw,lika_lik123,niko__654,boss_30,obeliks___,rusiya0117,aha.budefe.apardim_1,oanhkieule818,qaqas_5551,agacanbakii,rick_grimes66,shatoburian_sato`.split(`,`);Qe.length;var $e=/^@+/;function et(e){return e.trim().replace($e,``).replace(/\s+/g,``).toLowerCase()}function tt(e){let t=new Set,n=[];for(let r of e.split(/[\n,;]+/)){let e=r.trim().replace($e,``).split(/\s+/)[0]??``;if(!e||e.startsWith(`#`))continue;let i=et(e);i&&!t.has(i)&&(t.add(i),n.push(e))}return n}function nt(e,t){let n=et(t);if(!n)return e.map(e=>({name:e,match:`contains`}));let r=[],i=[],a=[];for(let t of e){let e=et(t);e===n?r.push({name:t,match:`exact`}):e.startsWith(n)?i.push({name:t,match:`prefix`}):e.includes(n)&&a.push({name:t,match:`contains`})}return[...r,...i,...a]}function rt(){return[...Qe]}var it={telegramToken:``,telegramChatId:``,autoTelegram:!1,concurrency:12,intervalMs:8e3,minRate:1,minViewers:0,minCoins:0,proxiesText:``,stealthMode:!0,soundAlerts:!0,browserNotify:!1,autoPauseOnBlock:!0,priorityText:``},at={checks:0,checksPerSec:0,live:0,boxes:0,alerts:0,telegramOk:0,startedAt:null,scanned:0,cycle:0,blocked:0,mismatches:0,okHits:0,peakLiveViewers:0},ot=new Map,st=new Set,ct=0,lt=0,ut=0,dt=0;function ft(e){let t=new Map(ot);ot.clear();for(let n of e){let e=t.get(n);ot.set(n,e??{username:n,status:`offline`,viewers:0,lastChecked:0,exactMatch:!0})}}function pt(e,t){let n=tt(e),r=new Set(t.map(e=>e.toLowerCase()));return n.filter(e=>r.has(e.toLowerCase()))}var H=He()(Ge((e,t)=>({view:`radar`,setView:t=>e({view:t}),usernames:rt(),setUsernames:t=>{let n=t.length>0?t:rt();ft(n),ct=0,e({usernames:n,live:[]})},restoreWatchlist:()=>{let t=rt();ft(t),ct=0,e({usernames:t,live:[]})},settings:it,patchSettings:t=>e(e=>({settings:{...e.settings,...t}})),running:!1,stats:at,live:[],ticker:[],alerts:[],workersBusy:0,health:`unknown`,healthNote:``,listFilter:`all`,setListFilter:t=>e({listFilter:t}),sortKey:`viewers`,setSortKey:t=>e({sortKey:t}),start:()=>{if(t().running)return;let n=t().usernames;ft(n),lt+=1;let r=lt;ut=0,dt=performance.now(),e({running:!0,health:`unknown`,healthNote:``,stats:{...at,startedAt:Date.now()}}),ht(r,t,e)},stop:()=>{lt+=1,e({running:!1,workersBusy:0,stats:{...t().stats,checksPerSec:0}})},sendAlert:async n=>{let{settings:r}=t();if(!r.telegramToken||!r.telegramChatId){e(e=>({alerts:e.alerts.map(e=>e.id===n.id?{...e,telegramError:`Token və ya chat ID yoxdur`}:e)}));return}try{let t=await Ne({data:{token:r.telegramToken,chatId:r.telegramChatId,text:Xe(n)}});e(e=>({alerts:e.alerts.map(e=>e.id===n.id?{...e,telegramSent:t.ok,telegramError:t.ok?void 0:t.error}:e),stats:t.ok?{...e.stats,telegramOk:e.stats.telegramOk+1}:e.stats}))}catch(t){e(e=>({alerts:e.alerts.map(e=>e.id===n.id?{...e,telegramError:t instanceof Error?t.message:`Göndərmə xətası`}:e)}))}},injectSample:(n=`chest`)=>{let r=n===`gift_bag`;yt({id:`sample-${n}-${Date.now()}`,username:r?`zevs_show`:`ramiz_real`,viewers:r?840:1250,peakViewers:r?910:1400,giftType:r?`Hədiyyə çantası`:`Sandıq`,kind:r?`gift_bag`:`chest`,confidence:r?92:96,totalCoins:r?30:50,totalSlots:10,rate:r?3:5,participants:r?6:8,liveUrl:r?`https://www.tiktok.com/@zevs_show/live`:`https://www.tiktok.com/@ramiz_real/live`,ts:Date.now(),telegramSent:!1,exactMatch:!0,remainSec:40,title:r?`gecə yayımı`:`live`,sender:r?`fan_01`:`boz_qurt37`,signals:r?[`business_type=2`]:[`business_type=1`]},t,e)},clearAlerts:()=>{st.clear(),e({alerts:[],stats:{...t().stats,alerts:0,boxes:0}})}}),{name:`sandiqradar-v3`,partialize:e=>({usernames:e.usernames,settings:e.settings}),onRehydrateStorage:()=>e=>{if(!e)return;let t=e.usernames[0];(e.usernames.length<80||t===`leyla_live`||t===`leyla_tv`)&&(e.usernames=rt()),e.settings={...it,...e.settings},ft(e.usernames)}}));function mt(e){return new Promise(t=>window.setTimeout(t,e))}async function ht(e,t,n){for(;lt===e;){let{usernames:e,settings:r,health:i}=t();if(e.length===0){await mt(800);continue}(i===`cooling`||i===`blocked`&&r.autoPauseOnBlock)&&await mt(r.stealthMode?12e3:9e3);let a=r.stealthMode,o=i===`blocked`||i===`cooling`?1:a?Math.min(3,Math.max(1,Math.round(r.concurrency/8))):Math.min(5,Math.max(2,Math.round(r.concurrency/10))),s=[],c=pt(r.priorityText,e);for(let e of c){if(s.length>=Math.min(1,o))break;s.push(e)}for(let t=0;t<o;t+=1){let t=e[ct%e.length];ct+=1,t&&!s.includes(t)&&s.push(t)}for(let e of s){let t=ot.get(e);ot.set(e,{username:e,status:`checking`,viewers:t?.viewers??0,peakViewers:t?.peakViewers,lastChecked:Date.now(),uniqueId:t?.uniqueId,exactMatch:t?.exactMatch,roomId:t?.roomId,title:t?.title,liveSince:t?.liveSince})}n({ticker:s,workersBusy:s.length});try{let e=await Ke({data:{usernames:s}});_t(e.hits,t,n,!!e.cooling)}catch(e){gt(s,e,t,n)}await mt(a?t().health===`blocked`||t().health===`cooling`?11e3:Math.max(1400,Math.round(r.intervalMs/Math.max(2,o))):t().health===`blocked`?9e3:Math.max(400,Math.round(r.intervalMs/Math.max(6,o))))}}function gt(e,t,n,r){let i=t instanceof Error?t.message:`şəbəkə xətası`;for(let t of e)ot.set(t,{username:t,status:`error`,viewers:0,lastChecked:Date.now(),error:i});vt(n,r,{checks:e.length,blockedDelta:0,mismatchDelta:0,okDelta:0,health:`blocked`,note:`Tarama sorğusu uğursuz oldu. Python botunu öz VPS + proxy ilə işə salın — stealth rejim açıq saxlayın.`})}function _t(e,t,n,r){let i=0,a=0,o=0,{settings:s}=t();for(let r of e){r.blocked?i+=1:o+=1,r.exactMatch||(a+=1);let e=ot.get(r.username),c=Math.max(e?.peakViewers??0,r.viewers),l=r.live?e?.liveSince??Date.now():void 0,u=r.box&&r.live?`box`:r.live?`live`:r.blocked?`error`:`offline`;if(ot.set(r.username,{username:r.username,uniqueId:r.uniqueId,exactMatch:r.exactMatch,status:u,viewers:r.viewers,peakViewers:c,lastChecked:Date.now(),liveSince:l,title:r.title,roomId:r.roomId,error:r.error||void 0,boxKind:r.box?.kind,boxLabel:r.box?.giftType,boxRate:r.box?.rate,boxCoins:r.box?.totalCoins,boxSlots:r.box?.totalSlots,boxJoined:r.box?.participants,remainSec:r.box?.remainSec,boxConfidence:r.box?.confidence,sender:r.box?.sender}),r.live&&r.exactMatch&&r.box){if(r.viewers<s.minViewers||r.box.totalCoins<s.minCoins)continue;let e={id:`${r.uniqueId}-${r.box.boxId||`${r.box.kind}-${r.box.totalCoins}-${r.box.totalSlots}`}-${Math.floor(Date.now()/12e3)}`,username:r.uniqueId||r.username,viewers:r.viewers,peakViewers:c,giftType:r.box.giftType,kind:r.box.kind,confidence:r.box.confidence,totalCoins:r.box.totalCoins,totalSlots:r.box.totalSlots,rate:r.box.rate,participants:r.box.participants,liveUrl:r.liveUrl,ts:Date.now(),telegramSent:!1,exactMatch:!0,remainSec:r.box.remainSec,title:r.title,sender:r.box.sender,signals:r.box.signals},i=`${e.username}:${r.box.boxId||`${e.totalCoins}:${e.totalSlots}:${e.kind}`}`;st.has(i)||yt(e,t,n)}else if(!r.box)for(let e of[...st])e.startsWith(`${r.uniqueId||r.username}:`)&&st.delete(e)}let c=e.length>0?i/e.length:0,l=r?`cooling`:c>=.6?`blocked`:`ok`,u=l===`blocked`?`TikTok bu IP-dən sorğuları kəsir. Stealth açıq saxlayın və ya Python paketini residential proxy ilə VPS-də işə salın.`:l===`cooling`?`Mühərrik yavaşladı — blok siqnalından sonra backoff.`:``;vt(t,n,{checks:e.length,blockedDelta:i,mismatchDelta:a,okDelta:o,health:l,note:u})}function vt(e,t,n){ut+=n.checks;let r=performance.now()-dt,i=e().stats.checksPerSec;r>=800&&(i=Math.round(ut/r*1e3),ut=0,dt=performance.now());let a=[],o=0;for(let e of ot.values())(e.status===`live`||e.status===`box`)&&(a.push(e),o+=e.viewers);let{sortKey:s}=e();a.sort((e,t)=>s===`name`?e.username.localeCompare(t.username):s===`rate`?(t.boxRate??0)-(e.boxRate??0):s===`time`?(t.liveSince??0)-(e.liveSince??0):e.status===t.status?t.viewers-e.viewers:e.status===`box`?-1:1);let c=[...ot.values()].filter(e=>e.lastChecked>0).length,l=e().usernames.length>0?Math.floor(e().stats.checks/e().usernames.length):0;t(e=>({live:a.slice(0,80),workersBusy:n.checks,health:n.health,healthNote:n.note||(n.health===`ok`?``:e.healthNote),stats:{...e.stats,checks:e.stats.checks+n.checks,checksPerSec:i,live:a.length,boxes:a.filter(e=>e.status===`box`).length,scanned:c,cycle:l,blocked:e.stats.blocked+n.blockedDelta,mismatches:e.stats.mismatches+n.mismatchDelta,okHits:e.stats.okHits+n.okDelta,peakLiveViewers:Math.max(e.stats.peakLiveViewers,o)}}))}function yt(e,t,n){let{settings:r,alerts:i}=t();e.rate<r.minRate||e.viewers<r.minViewers||e.totalCoins<r.minCoins||i.some(t=>t.id===e.id)||(st.add(`${e.username}:${e.totalCoins}:${e.totalSlots}:${e.kind}`),n(t=>({alerts:[e,...t.alerts].slice(0,120),stats:{...t.stats,alerts:t.stats.alerts+1,boxes:t.stats.boxes+1}})),I.success(`@${e.username} · ${e.giftType} · ${e.viewers} nəfər`),r.soundAlerts&&Pe(),r.browserNotify&&B(Ze(e)),r.autoTelegram&&r.telegramToken&&r.telegramChatId&&t().sendAlert(e))}var bt=Object.defineProperty,xt=(e,t)=>bt(e,`name`,{value:t,configurable:!0});function St(e,t){if(typeof e==`function`)return e(t);e!=null&&(e.current=t)}xt(St,`setRef`);function Ct(...e){return t=>{let n=!1,r=e.map(e=>{let r=St(e,t);return!n&&typeof r==`function`&&(n=!0),r});if(n)return()=>{for(let t=0;t<r.length;t++){let n=r[t];typeof n==`function`?n():St(e[t],null)}}}}xt(Ct,`composeRefs`);function wt(...e){return O.useCallback(Ct(...e),e)}xt(wt,`useComposedRefs`);var Tt=Object.defineProperty,U=(e,t)=>Tt(e,`name`,{value:t,configurable:!0});function Et(e){let t=O.forwardRef((t,n)=>{let{children:r,...i}=t,a=null,o=!1,s=[];Ft(r)&&typeof zt==`function`&&(r=zt(r._payload)),O.Children.forEach(r,e=>{if(Nt(e)){o=!0;let t=e,n=`child`in t.props?t.props.child:t.props.children;Ft(n)&&typeof zt==`function`&&(n=zt(n._payload)),a=At(t,n),s.push(a?.props?.children)}else s.push(e)}),a?a=O.cloneElement(a,void 0,s):!o&&O.Children.count(r)===1&&O.isValidElement(r)&&(a=r);let c=a?Mt(a):void 0,l=wt(n,c);if(!a){if(r||r===0)throw Error(o?Rt(e):Lt(e));return r}let u=jt(i,a.props??{});return a.type!==O.Fragment&&(u.ref=n?l:c),O.cloneElement(a,u)});return t.displayName=`${e}.Slot`,t}U(Et,`createSlot`);var Dt=Et(`Slot`),Ot=Symbol.for(`radix.slottable`);function kt(e){let t=U(e=>`child`in e?e.children(e.child):e.children,`Slottable`);return t.displayName=`${e}.Slottable`,t.__radixId=Ot,t}U(kt,`createSlottable`);var At=U((e,t)=>{if(`child`in e.props){let t=e.props.child;return O.isValidElement(t)?O.cloneElement(t,void 0,e.props.children(t.props.children)):null}return O.isValidElement(t)?t:null},`getSlottableElementFromSlottable`);function jt(e,t){let n={...t};for(let r in t){let i=e[r],a=t[r];/^on[A-Z]/.test(r)?i&&a?n[r]=(...e)=>{let t=a(...e);return i(...e),t}:i&&(n[r]=i):r===`style`?n[r]={...i,...a}:r===`className`&&(n[r]=[i,a].filter(Boolean).join(` `))}return{...e,...n}}U(jt,`mergeProps`);function Mt(e){let t=Object.getOwnPropertyDescriptor(e.props,`ref`)?.get,n=t&&`isReactWarning`in t&&t.isReactWarning;return n?e.ref:(t=Object.getOwnPropertyDescriptor(e,`ref`)?.get,n=t&&`isReactWarning`in t&&t.isReactWarning,n?e.props.ref:e.props.ref||e.ref)}U(Mt,`getElementRef`);function Nt(e){return O.isValidElement(e)&&typeof e.type==`function`&&`__radixId`in e.type&&e.type.__radixId===Ot}U(Nt,`isSlottable`);var Pt=Symbol.for(`react.lazy`);function Ft(e){return typeof e==`object`&&!!e&&`$$typeof`in e&&e.$$typeof===Pt&&`_payload`in e&&It(e._payload)}U(Ft,`isLazyComponent`);function It(e){return typeof e==`object`&&!!e&&`then`in e}U(It,`isPromiseLike`);var Lt=U(e=>`${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`,`createSlotError`),Rt=U(e=>`${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`,`createSlottableError`),zt=O.use;function Bt(e){var t,n,r=``;if(typeof e==`string`||typeof e==`number`)r+=e;else if(typeof e==`object`){if(Array.isArray(e)){var i=e.length;for(t=0;t<i;t++)e[t]&&(n=Bt(e[t]))&&(r&&(r+=` `),r+=n)}else for(n in e)e[n]&&(r&&(r+=` `),r+=n)}return r}function Vt(){for(var e,t,n=0,r=``,i=arguments.length;n<i;n++)(e=arguments[n])&&(t=Bt(e))&&(r&&(r+=` `),r+=t);return r}var Ht=e=>typeof e==`boolean`?`${e}`:e===0?`0`:e,Ut=Vt,Wt=(e,t)=>n=>{if(t?.variants==null)return Ut(e,n?.class,n?.className);let{variants:r,defaultVariants:i}=t,a=Object.keys(r).map(e=>{let t=n?.[e],a=i?.[e];if(t===null)return null;let o=Ht(t)||Ht(a);return r[e][o]}),o=n&&Object.entries(n).reduce((e,t)=>{let[n,r]=t;return r===void 0||(e[n]=r),e},{});return Ut(e,a,t?.compoundVariants?.reduce((e,t)=>{let{class:n,className:r,...a}=t;return Object.entries(a).every(e=>{let[t,n]=e;return Array.isArray(n)?n.includes({...i,...o}[t]):{...i,...o}[t]===n})?[...e,n,r]:e},[]),n?.class,n?.className)},Gt=(e,t)=>{let n=Array(e.length+t.length);for(let t=0;t<e.length;t++)n[t]=e[t];for(let r=0;r<t.length;r++)n[e.length+r]=t[r];return n},Kt=(e,t)=>({classGroupId:e,validator:t}),qt=(e=new Map,t=null,n)=>({nextPart:e,validators:t,classGroupId:n}),Jt=`-`,Yt=[],Xt=`arbitrary..`,Zt=e=>{let t=en(e),{conflictingClassGroups:n,conflictingClassGroupModifiers:r}=e;return{getClassGroupId:e=>{if(e.startsWith(`[`)&&e.endsWith(`]`))return $t(e);let n=e.split(Jt);return Qt(n,+(n[0]===``&&n.length>1),t)},getConflictingClassGroupIds:(e,t)=>{if(t){let t=r[e],i=n[e];return t?i?Gt(i,t):t:i||Yt}return n[e]||Yt}}},Qt=(e,t,n)=>{if(e.length-t===0)return n.classGroupId;let r=e[t],i=n.nextPart.get(r);if(i){let n=Qt(e,t+1,i);if(n)return n}let a=n.validators;if(a===null)return;let o=t===0?e.join(Jt):e.slice(t).join(Jt),s=a.length;for(let e=0;e<s;e++){let t=a[e];if(t.validator(o))return t.classGroupId}},$t=e=>e.slice(1,-1).indexOf(`:`)===-1?void 0:(()=>{let t=e.slice(1,-1),n=t.indexOf(`:`),r=t.slice(0,n);return r?Xt+r:void 0})(),en=e=>{let{theme:t,classGroups:n}=e;return tn(n,t)},tn=(e,t)=>{let n=qt();for(let r in e){let i=e[r];nn(i,n,r,t)}return n},nn=(e,t,n,r)=>{let i=e.length;for(let a=0;a<i;a++){let i=e[a];rn(i,t,n,r)}},rn=(e,t,n,r)=>{if(typeof e==`string`){an(e,t,n);return}if(typeof e==`function`){on(e,t,n,r);return}sn(e,t,n,r)},an=(e,t,n)=>{let r=e===``?t:cn(t,e);r.classGroupId=n},on=(e,t,n,r)=>{if(ln(e)){nn(e(r),t,n,r);return}t.validators===null&&(t.validators=[]),t.validators.push(Kt(n,e))},sn=(e,t,n,r)=>{let i=Object.entries(e),a=i.length;for(let e=0;e<a;e++){let[a,o]=i[e];nn(o,cn(t,a),n,r)}},cn=(e,t)=>{let n=e,r=t.split(Jt),i=r.length;for(let e=0;e<i;e++){let t=r[e],i=n.nextPart.get(t);i||(i=qt(),n.nextPart.set(t,i)),n=i}return n},ln=e=>`isThemeGetter`in e&&e.isThemeGetter===!0,un=e=>{if(e<1)return{get:()=>void 0,set:()=>{}};let t=0,n=Object.create(null),r=Object.create(null),i=(i,a)=>{n[i]=a,t++,t>e&&(t=0,r=n,n=Object.create(null))};return{get(e){let t=n[e];if(t!==void 0)return t;if((t=r[e])!==void 0)return i(e,t),t},set(e,t){e in n?n[e]=t:i(e,t)}}},dn=`!`,fn=`:`,pn=[],mn=(e,t,n,r,i)=>({modifiers:e,hasImportantModifier:t,baseClassName:n,maybePostfixModifierPosition:r,isExternal:i}),hn=e=>{let{prefix:t,experimentalParseClassName:n}=e,r=e=>{let t=[],n=0,r=0,i=0,a,o=e.length;for(let s=0;s<o;s++){let o=e[s];if(n===0&&r===0){if(o===fn){t.push(e.slice(i,s)),i=s+1;continue}if(o===`/`){a=s;continue}}o===`[`?n++:o===`]`?n--:o===`(`?r++:o===`)`&&r--}let s=t.length===0?e:e.slice(i),c=s,l=!1;s.endsWith(dn)?(c=s.slice(0,-1),l=!0):s.startsWith(dn)&&(c=s.slice(1),l=!0);let u=a&&a>i?a-i:void 0;return mn(t,l,c,u)};if(t){let e=t+fn,n=r;r=t=>t.startsWith(e)?n(t.slice(e.length)):mn(pn,!1,t,void 0,!0)}if(n){let e=r;r=t=>n({className:t,parseClassName:e})}return r},gn=e=>{let t=new Map;return e.orderSensitiveModifiers.forEach((e,n)=>{t.set(e,1e6+n)}),e=>{let n=[],r=[];for(let i=0;i<e.length;i++){let a=e[i],o=a[0]===`[`,s=t.has(a);o||s?(r.length>0&&(r.sort(),n.push(...r),r=[]),n.push(a)):r.push(a)}return r.length>0&&(r.sort(),n.push(...r)),n}},_n=e=>({cache:un(e.cacheSize),parseClassName:hn(e),sortModifiers:gn(e),postfixLookupClassGroupIds:vn(e),...Zt(e)}),vn=e=>{let t=Object.create(null),n=e.postfixLookupClassGroups;if(n)for(let e=0;e<n.length;e++)t[n[e]]=!0;return t},yn=/\s+/,bn=(e,t)=>{let{parseClassName:n,getClassGroupId:r,getConflictingClassGroupIds:i,sortModifiers:a,postfixLookupClassGroupIds:o}=t,s=[],c=e.trim().split(yn),l=``;for(let e=c.length-1;e>=0;--e){let t=c[e],{isExternal:u,modifiers:d,hasImportantModifier:f,baseClassName:p,maybePostfixModifierPosition:m}=n(t);if(u){l=t+(l.length>0?` `+l:l);continue}let h=!!m,g;if(h){g=r(p.substring(0,m));let e=g&&o[g]?r(p):void 0;e&&e!==g&&(g=e,h=!1)}else g=r(p);if(!g){if(!h){l=t+(l.length>0?` `+l:l);continue}if(g=r(p),!g){l=t+(l.length>0?` `+l:l);continue}h=!1}let _=d.length===0?``:d.length===1?d[0]:a(d).join(`:`),v=f?_+dn:_,y=v+g;if(s.indexOf(y)>-1)continue;s.push(y);let b=i(g,h);for(let e=0;e<b.length;++e){let t=b[e];s.push(v+t)}l=t+(l.length>0?` `+l:l)}return l},xn=(...e)=>{let t=0,n,r,i=``;for(;t<e.length;)(n=e[t++])&&(r=Sn(n))&&(i&&(i+=` `),i+=r);return i},Sn=e=>{if(typeof e==`string`)return e;let t,n=``;for(let r=0;r<e.length;r++)e[r]&&(t=Sn(e[r]))&&(n&&(n+=` `),n+=t);return n},Cn=(e,...t)=>{let n,r,i,a,o=o=>(n=_n(t.reduce((e,t)=>t(e),e())),r=n.cache.get,i=n.cache.set,a=s,s(o)),s=e=>{let t=r(e);if(t)return t;let a=bn(e,n);return i(e,a),a};return a=o,(...e)=>a(xn(...e))},wn=[],W=e=>{let t=t=>t[e]||wn;return t.isThemeGetter=!0,t.themeKey=e,t},Tn=/^\[(?:(\w[\w-]*):)?(.+)\]$/i,En=/^\((?:(\w[\w-]*):)?(.+)\)$/i,Dn=/^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,On=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,kn=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,An=/^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix|color|light-dark)\(.+\)$/,jn=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,Mn=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,Nn=e=>Dn.test(e),G=e=>!!e&&!Number.isNaN(Number(e)),Pn=e=>!!e&&Number.isInteger(Number(e)),Fn=e=>e.endsWith(`%`)&&G(e.slice(0,-1)),In=e=>On.test(e),Ln=()=>!0,Rn=e=>kn.test(e)&&!An.test(e),zn=()=>!1,Bn=e=>jn.test(e),Vn=e=>Mn.test(e),Hn=e=>!K(e)&&!q(e),Un=e=>e.startsWith(`@container`)&&(e[10]===`/`&&e[11]!==void 0||e[11]===`s`&&e[16]!==void 0&&e.startsWith(`-size/`,10)||e[11]===`n`&&e[18]!==void 0&&e.startsWith(`-normal/`,10)),Wn=e=>ar(e,lr,zn),K=e=>Tn.test(e),Gn=e=>ar(e,ur,Rn),Kn=e=>ar(e,dr,G),qn=e=>ar(e,pr,Ln),Jn=e=>ar(e,fr,zn),Yn=e=>ar(e,sr,zn),Xn=e=>ar(e,cr,Vn),Zn=e=>ar(e,mr,Bn),q=e=>En.test(e),Qn=e=>or(e,ur),$n=e=>or(e,fr),er=e=>or(e,sr),tr=e=>or(e,lr),nr=e=>or(e,cr),rr=e=>or(e,mr,!0),ir=e=>or(e,pr,!0),ar=(e,t,n)=>{let r=Tn.exec(e);return r?r[1]?t(r[1]):n(r[2]):!1},or=(e,t,n=!1)=>{let r=En.exec(e);return r?r[1]?t(r[1]):n:!1},sr=e=>e===`position`||e===`percentage`,cr=e=>e===`image`||e===`url`,lr=e=>e===`length`||e===`size`||e===`bg-size`,ur=e=>e===`length`,dr=e=>e===`number`,fr=e=>e===`family-name`,pr=e=>e===`number`||e===`weight`,mr=e=>e===`shadow`,hr=Cn(()=>{let e=W(`color`),t=W(`font`),n=W(`text`),r=W(`font-weight`),i=W(`tracking`),a=W(`leading`),o=W(`breakpoint`),s=W(`container`),c=W(`spacing`),l=W(`radius`),u=W(`shadow`),d=W(`inset-shadow`),f=W(`text-shadow`),p=W(`drop-shadow`),m=W(`blur`),h=W(`perspective`),g=W(`aspect`),_=W(`ease`),v=W(`animate`),y=()=>[`auto`,`avoid`,`all`,`avoid-page`,`page`,`left`,`right`,`column`],b=()=>[`center`,`top`,`bottom`,`left`,`right`,`top-left`,`left-top`,`top-right`,`right-top`,`bottom-right`,`right-bottom`,`bottom-left`,`left-bottom`],x=()=>[...b(),q,K],S=()=>[`auto`,`hidden`,`clip`,`visible`,`scroll`],C=()=>[`auto`,`contain`,`none`],w=()=>[q,K,c],T=()=>[Nn,`full`,`auto`,...w()],E=()=>[Pn,`none`,`subgrid`,q,K],ee=()=>[`auto`,{span:[`full`,Pn,q,K]},Pn,q,K],te=()=>[Pn,`auto`,q,K],D=()=>[`auto`,`min`,`max`,`fr`,q,K],O=()=>[`start`,`end`,`center`,`between`,`around`,`evenly`,`stretch`,`baseline`,`center-safe`,`end-safe`],k=()=>[`start`,`end`,`center`,`stretch`,`center-safe`,`end-safe`],A=()=>[`auto`,...w()],ne=()=>[Nn,`auto`,`full`,`dvw`,`dvh`,`lvw`,`lvh`,`svw`,`svh`,`min`,`max`,`fit`,...w()],re=()=>[s,Nn,`screen`,`full`,`dvw`,`lvw`,`svw`,`min`,`max`,`fit`,...w()],ie=()=>[Nn,`screen`,`full`,`lh`,`dvh`,`lvh`,`svh`,`min`,`max`,`fit`,...w()],j=()=>[e,q,K],ae=()=>[...b(),er,Yn,{position:[q,K]}],M=()=>[`no-repeat`,{repeat:[``,`x`,`y`,`space`,`round`]}],oe=()=>[`auto`,`cover`,`contain`,tr,Wn,{size:[q,K]}],se=()=>[Fn,Qn,Gn],N=()=>[``,`none`,`full`,l,q,K],P=()=>[``,G,Qn,Gn],ce=()=>[`solid`,`dashed`,`dotted`,`double`],le=()=>[`normal`,`multiply`,`screen`,`overlay`,`darken`,`lighten`,`color-dodge`,`color-burn`,`hard-light`,`soft-light`,`difference`,`exclusion`,`hue`,`saturation`,`color`,`luminosity`],F=()=>[G,Fn,er,Yn],ue=()=>[``,`none`,m,q,K],de=()=>[`none`,G,q,K],I=()=>[`none`,G,q,K],fe=()=>[G,q,K],pe=()=>[Nn,`full`,...w()];return{cacheSize:500,theme:{animate:[`spin`,`ping`,`pulse`,`bounce`],aspect:[`video`],blur:[In],breakpoint:[In],color:[Ln],container:[In],"drop-shadow":[In],ease:[`in`,`out`,`in-out`],font:[Hn],"font-weight":[`thin`,`extralight`,`light`,`normal`,`medium`,`semibold`,`bold`,`extrabold`,`black`],"inset-shadow":[In],leading:[`none`,`tight`,`snug`,`normal`,`relaxed`,`loose`],perspective:[`dramatic`,`near`,`normal`,`midrange`,`distant`,`none`],radius:[In],shadow:[In],spacing:[`px`,G],text:[In],"text-shadow":[In],tracking:[`tighter`,`tight`,`normal`,`wide`,`wider`,`widest`]},classGroups:{aspect:[{aspect:[`auto`,`square`,Nn,K,q,g]}],container:[`container`],"container-type":[{"@container":[``,`normal`,`size`,q,K]}],"container-named":[Un],columns:[{columns:[G,`auto`,K,q,s]}],"break-after":[{"break-after":y()}],"break-before":[{"break-before":y()}],"break-inside":[{"break-inside":[`auto`,`avoid`,`avoid-page`,`avoid-column`]}],"box-decoration":[{"box-decoration":[`slice`,`clone`]}],box:[{box:[`border`,`content`]}],display:[`block`,`inline-block`,`inline`,`flex`,`inline-flex`,`table`,`inline-table`,`table-caption`,`table-cell`,`table-column`,`table-column-group`,`table-footer-group`,`table-header-group`,`table-row-group`,`table-row`,`flow-root`,`grid`,`inline-grid`,`contents`,`list-item`,`hidden`],sr:[`sr-only`,`not-sr-only`],float:[{float:[`right`,`left`,`none`,`start`,`end`]}],clear:[{clear:[`left`,`right`,`both`,`none`,`start`,`end`]}],isolation:[`isolate`,`isolation-auto`],"object-fit":[{object:[`contain`,`cover`,`fill`,`none`,`scale-down`]}],"object-position":[{object:x()}],overflow:[{overflow:S()}],"overflow-x":[{"overflow-x":S()}],"overflow-y":[{"overflow-y":S()}],overscroll:[{overscroll:C()}],"overscroll-x":[{"overscroll-x":C()}],"overscroll-y":[{"overscroll-y":C()}],position:[`static`,`fixed`,`absolute`,`relative`,`sticky`],inset:[{inset:T()}],"inset-x":[{"inset-x":T()}],"inset-y":[{"inset-y":T()}],start:[{"inset-s":T(),start:T()}],end:[{"inset-e":T(),end:T()}],"inset-bs":[{"inset-bs":T()}],"inset-be":[{"inset-be":T()}],top:[{top:T()}],right:[{right:T()}],bottom:[{bottom:T()}],left:[{left:T()}],visibility:[`visible`,`invisible`,`collapse`],z:[{z:[Pn,`auto`,q,K]}],basis:[{basis:[Nn,`full`,`auto`,s,...w()]}],"flex-direction":[{flex:[`row`,`row-reverse`,`col`,`col-reverse`]}],"flex-wrap":[{flex:[`nowrap`,`wrap`,`wrap-reverse`]}],flex:[{flex:[G,Nn,`auto`,`initial`,`none`,K]}],grow:[{grow:[``,G,q,K]}],shrink:[{shrink:[``,G,q,K]}],order:[{order:[Pn,`first`,`last`,`none`,q,K]}],"grid-cols":[{"grid-cols":E()}],"col-start-end":[{col:ee()}],"col-start":[{"col-start":te()}],"col-end":[{"col-end":te()}],"grid-rows":[{"grid-rows":E()}],"row-start-end":[{row:ee()}],"row-start":[{"row-start":te()}],"row-end":[{"row-end":te()}],"grid-flow":[{"grid-flow":[`row`,`col`,`dense`,`row-dense`,`col-dense`]}],"auto-cols":[{"auto-cols":D()}],"auto-rows":[{"auto-rows":D()}],gap:[{gap:w()}],"gap-x":[{"gap-x":w()}],"gap-y":[{"gap-y":w()}],"justify-content":[{justify:[...O(),`normal`]}],"justify-items":[{"justify-items":[...k(),`normal`]}],"justify-self":[{"justify-self":[`auto`,...k()]}],"align-content":[{content:[`normal`,...O()]}],"align-items":[{items:[...k(),{baseline:[``,`last`]}]}],"align-self":[{self:[`auto`,...k(),{baseline:[``,`last`]}]}],"place-content":[{"place-content":O()}],"place-items":[{"place-items":[...k(),`baseline`]}],"place-self":[{"place-self":[`auto`,...k()]}],p:[{p:w()}],px:[{px:w()}],py:[{py:w()}],ps:[{ps:w()}],pe:[{pe:w()}],pbs:[{pbs:w()}],pbe:[{pbe:w()}],pt:[{pt:w()}],pr:[{pr:w()}],pb:[{pb:w()}],pl:[{pl:w()}],m:[{m:A()}],mx:[{mx:A()}],my:[{my:A()}],ms:[{ms:A()}],me:[{me:A()}],mbs:[{mbs:A()}],mbe:[{mbe:A()}],mt:[{mt:A()}],mr:[{mr:A()}],mb:[{mb:A()}],ml:[{ml:A()}],"space-x":[{"space-x":w()}],"space-x-reverse":[`space-x-reverse`],"space-y":[{"space-y":w()}],"space-y-reverse":[`space-y-reverse`],size:[{size:ne()}],"inline-size":[{inline:[`auto`,...re()]}],"min-inline-size":[{"min-inline":[`auto`,...re()]}],"max-inline-size":[{"max-inline":[`none`,...re()]}],"block-size":[{block:[`auto`,...ie()]}],"min-block-size":[{"min-block":[`auto`,...ie()]}],"max-block-size":[{"max-block":[`none`,...ie()]}],w:[{w:[s,`screen`,...ne()]}],"min-w":[{"min-w":[s,`screen`,`none`,...ne()]}],"max-w":[{"max-w":[s,`screen`,`none`,`prose`,{screen:[o]},...ne()]}],h:[{h:[`screen`,`lh`,...ne()]}],"min-h":[{"min-h":[`screen`,`lh`,`none`,...ne()]}],"max-h":[{"max-h":[`screen`,`lh`,`none`,...ne()]}],"font-size":[{text:[`base`,n,Qn,Gn]}],"font-smoothing":[`antialiased`,`subpixel-antialiased`],"font-style":[`italic`,`not-italic`],"font-weight":[{font:[r,ir,qn]}],"font-stretch":[{"font-stretch":[`ultra-condensed`,`extra-condensed`,`condensed`,`semi-condensed`,`normal`,`semi-expanded`,`expanded`,`extra-expanded`,`ultra-expanded`,Fn,K]}],"font-family":[{font:[$n,Jn,t]}],"font-features":[{"font-features":[K]}],"fvn-normal":[`normal-nums`],"fvn-ordinal":[`ordinal`],"fvn-slashed-zero":[`slashed-zero`],"fvn-figure":[`lining-nums`,`oldstyle-nums`],"fvn-spacing":[`proportional-nums`,`tabular-nums`],"fvn-fraction":[`diagonal-fractions`,`stacked-fractions`],tracking:[{tracking:[i,q,K]}],"line-clamp":[{"line-clamp":[G,`none`,q,Kn]}],leading:[{leading:[`none`,a,...w()]}],"list-image":[{"list-image":[`none`,q,K]}],"list-style-position":[{list:[`inside`,`outside`]}],"list-style-type":[{list:[`disc`,`decimal`,`none`,q,K]}],"text-alignment":[{text:[`left`,`center`,`right`,`justify`,`start`,`end`]}],"placeholder-color":[{placeholder:j()}],"text-color":[{text:j()}],"text-decoration":[`underline`,`overline`,`line-through`,`no-underline`],"text-decoration-style":[{decoration:[...ce(),`wavy`]}],"text-decoration-thickness":[{decoration:[G,`from-font`,`auto`,q,Gn]}],"text-decoration-color":[{decoration:j()}],"underline-offset":[{"underline-offset":[G,`auto`,q,K]}],"text-transform":[`uppercase`,`lowercase`,`capitalize`,`normal-case`],"text-overflow":[`truncate`,`text-ellipsis`,`text-clip`],"text-wrap":[{text:[`wrap`,`nowrap`,`balance`,`pretty`]}],indent:[{indent:w()}],"tab-size":[{tab:[Pn,q,K]}],"vertical-align":[{align:[`baseline`,`top`,`middle`,`bottom`,`text-top`,`text-bottom`,`sub`,`super`,q,K]}],whitespace:[{whitespace:[`normal`,`nowrap`,`pre`,`pre-line`,`pre-wrap`,`break-spaces`]}],break:[{break:[`normal`,`words`,`all`,`keep`]}],wrap:[{wrap:[`break-word`,`anywhere`,`normal`]}],hyphens:[{hyphens:[`none`,`manual`,`auto`]}],content:[{content:[`none`,q,K]}],"bg-attachment":[{bg:[`fixed`,`local`,`scroll`]}],"bg-clip":[{"bg-clip":[`border`,`padding`,`content`,`text`]}],"bg-origin":[{"bg-origin":[`border`,`padding`,`content`]}],"bg-position":[{bg:ae()}],"bg-repeat":[{bg:M()}],"bg-size":[{bg:oe()}],"bg-image":[{bg:[`none`,{linear:[{to:[`t`,`tr`,`r`,`br`,`b`,`bl`,`l`,`tl`]},Pn,q,K],radial:[``,q,K],conic:[``,Pn,q,K]},nr,Xn]}],"bg-color":[{bg:j()}],"gradient-from-pos":[{from:se()}],"gradient-via-pos":[{via:se()}],"gradient-to-pos":[{to:se()}],"gradient-from":[{from:j()}],"gradient-via":[{via:j()}],"gradient-to":[{to:j()}],rounded:[{rounded:N()}],"rounded-s":[{"rounded-s":N()}],"rounded-e":[{"rounded-e":N()}],"rounded-t":[{"rounded-t":N()}],"rounded-r":[{"rounded-r":N()}],"rounded-b":[{"rounded-b":N()}],"rounded-l":[{"rounded-l":N()}],"rounded-ss":[{"rounded-ss":N()}],"rounded-se":[{"rounded-se":N()}],"rounded-ee":[{"rounded-ee":N()}],"rounded-es":[{"rounded-es":N()}],"rounded-tl":[{"rounded-tl":N()}],"rounded-tr":[{"rounded-tr":N()}],"rounded-br":[{"rounded-br":N()}],"rounded-bl":[{"rounded-bl":N()}],"border-w":[{border:P()}],"border-w-x":[{"border-x":P()}],"border-w-y":[{"border-y":P()}],"border-w-s":[{"border-s":P()}],"border-w-e":[{"border-e":P()}],"border-w-bs":[{"border-bs":P()}],"border-w-be":[{"border-be":P()}],"border-w-t":[{"border-t":P()}],"border-w-r":[{"border-r":P()}],"border-w-b":[{"border-b":P()}],"border-w-l":[{"border-l":P()}],"divide-x":[{"divide-x":P()}],"divide-x-reverse":[`divide-x-reverse`],"divide-y":[{"divide-y":P()}],"divide-y-reverse":[`divide-y-reverse`],"border-style":[{border:[...ce(),`hidden`,`none`]}],"divide-style":[{divide:[...ce(),`hidden`,`none`]}],"border-color":[{border:j()}],"border-color-x":[{"border-x":j()}],"border-color-y":[{"border-y":j()}],"border-color-s":[{"border-s":j()}],"border-color-e":[{"border-e":j()}],"border-color-bs":[{"border-bs":j()}],"border-color-be":[{"border-be":j()}],"border-color-t":[{"border-t":j()}],"border-color-r":[{"border-r":j()}],"border-color-b":[{"border-b":j()}],"border-color-l":[{"border-l":j()}],"divide-color":[{divide:j()}],"outline-style":[{outline:[...ce(),`none`,`hidden`]}],"outline-offset":[{"outline-offset":[G,q,K]}],"outline-w":[{outline:[``,G,Qn,Gn]}],"outline-color":[{outline:j()}],shadow:[{shadow:[``,`inner`,`none`,u,rr,Zn]}],"shadow-color":[{shadow:j()}],"inset-shadow":[{"inset-shadow":[`none`,d,rr,Zn]}],"inset-shadow-color":[{"inset-shadow":j()}],"ring-w":[{ring:P()}],"ring-w-inset":[`ring-inset`],"ring-color":[{ring:j()}],"ring-offset-w":[{"ring-offset":[G,Gn]}],"ring-offset-color":[{"ring-offset":j()}],"inset-ring-w":[{"inset-ring":P()}],"inset-ring-color":[{"inset-ring":j()}],"text-shadow":[{"text-shadow":[`none`,f,rr,Zn]}],"text-shadow-color":[{"text-shadow":j()}],opacity:[{opacity:[G,q,K]}],"mix-blend":[{"mix-blend":[...le(),`plus-darker`,`plus-lighter`]}],"bg-blend":[{"bg-blend":le()}],"mask-clip":[{"mask-clip":[`border`,`padding`,`content`,`fill`,`stroke`,`view`]},`mask-no-clip`],"mask-composite":[{mask:[`add`,`subtract`,`intersect`,`exclude`]}],"mask-image-linear-pos":[{"mask-linear":[G]}],"mask-image-linear-from-pos":[{"mask-linear-from":F()}],"mask-image-linear-to-pos":[{"mask-linear-to":F()}],"mask-image-linear-from-color":[{"mask-linear-from":j()}],"mask-image-linear-to-color":[{"mask-linear-to":j()}],"mask-image-t-from-pos":[{"mask-t-from":F()}],"mask-image-t-to-pos":[{"mask-t-to":F()}],"mask-image-t-from-color":[{"mask-t-from":j()}],"mask-image-t-to-color":[{"mask-t-to":j()}],"mask-image-r-from-pos":[{"mask-r-from":F()}],"mask-image-r-to-pos":[{"mask-r-to":F()}],"mask-image-r-from-color":[{"mask-r-from":j()}],"mask-image-r-to-color":[{"mask-r-to":j()}],"mask-image-b-from-pos":[{"mask-b-from":F()}],"mask-image-b-to-pos":[{"mask-b-to":F()}],"mask-image-b-from-color":[{"mask-b-from":j()}],"mask-image-b-to-color":[{"mask-b-to":j()}],"mask-image-l-from-pos":[{"mask-l-from":F()}],"mask-image-l-to-pos":[{"mask-l-to":F()}],"mask-image-l-from-color":[{"mask-l-from":j()}],"mask-image-l-to-color":[{"mask-l-to":j()}],"mask-image-x-from-pos":[{"mask-x-from":F()}],"mask-image-x-to-pos":[{"mask-x-to":F()}],"mask-image-x-from-color":[{"mask-x-from":j()}],"mask-image-x-to-color":[{"mask-x-to":j()}],"mask-image-y-from-pos":[{"mask-y-from":F()}],"mask-image-y-to-pos":[{"mask-y-to":F()}],"mask-image-y-from-color":[{"mask-y-from":j()}],"mask-image-y-to-color":[{"mask-y-to":j()}],"mask-image-radial":[{"mask-radial":[q,K]}],"mask-image-radial-from-pos":[{"mask-radial-from":F()}],"mask-image-radial-to-pos":[{"mask-radial-to":F()}],"mask-image-radial-from-color":[{"mask-radial-from":j()}],"mask-image-radial-to-color":[{"mask-radial-to":j()}],"mask-image-radial-shape":[{"mask-radial":[`circle`,`ellipse`]}],"mask-image-radial-size":[{"mask-radial":[{closest:[`side`,`corner`],farthest:[`side`,`corner`]}]}],"mask-image-radial-pos":[{"mask-radial-at":b()}],"mask-image-conic-pos":[{"mask-conic":[G]}],"mask-image-conic-from-pos":[{"mask-conic-from":F()}],"mask-image-conic-to-pos":[{"mask-conic-to":F()}],"mask-image-conic-from-color":[{"mask-conic-from":j()}],"mask-image-conic-to-color":[{"mask-conic-to":j()}],"mask-mode":[{mask:[`alpha`,`luminance`,`match`]}],"mask-origin":[{"mask-origin":[`border`,`padding`,`content`,`fill`,`stroke`,`view`]}],"mask-position":[{mask:ae()}],"mask-repeat":[{mask:M()}],"mask-size":[{mask:oe()}],"mask-type":[{"mask-type":[`alpha`,`luminance`]}],"mask-image":[{mask:[`none`,q,K]}],filter:[{filter:[``,`none`,q,K]}],blur:[{blur:ue()}],brightness:[{brightness:[G,q,K]}],contrast:[{contrast:[G,q,K]}],"drop-shadow":[{"drop-shadow":[``,`none`,p,rr,Zn]}],"drop-shadow-color":[{"drop-shadow":j()}],grayscale:[{grayscale:[``,G,q,K]}],"hue-rotate":[{"hue-rotate":[G,q,K]}],invert:[{invert:[``,G,q,K]}],saturate:[{saturate:[G,q,K]}],sepia:[{sepia:[``,G,q,K]}],"backdrop-filter":[{"backdrop-filter":[``,`none`,q,K]}],"backdrop-blur":[{"backdrop-blur":ue()}],"backdrop-brightness":[{"backdrop-brightness":[G,q,K]}],"backdrop-contrast":[{"backdrop-contrast":[G,q,K]}],"backdrop-grayscale":[{"backdrop-grayscale":[``,G,q,K]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[G,q,K]}],"backdrop-invert":[{"backdrop-invert":[``,G,q,K]}],"backdrop-opacity":[{"backdrop-opacity":[G,q,K]}],"backdrop-saturate":[{"backdrop-saturate":[G,q,K]}],"backdrop-sepia":[{"backdrop-sepia":[``,G,q,K]}],"border-collapse":[{border:[`collapse`,`separate`]}],"border-spacing":[{"border-spacing":w()}],"border-spacing-x":[{"border-spacing-x":w()}],"border-spacing-y":[{"border-spacing-y":w()}],"table-layout":[{table:[`auto`,`fixed`]}],caption:[{caption:[`top`,`bottom`]}],transition:[{transition:[``,`all`,`colors`,`opacity`,`shadow`,`transform`,`none`,q,K]}],"transition-behavior":[{transition:[`normal`,`discrete`]}],duration:[{duration:[G,`initial`,q,K]}],ease:[{ease:[`linear`,`initial`,_,q,K]}],delay:[{delay:[G,q,K]}],animate:[{animate:[`none`,v,q,K]}],backface:[{backface:[`hidden`,`visible`]}],perspective:[{perspective:[h,q,K]}],"perspective-origin":[{"perspective-origin":x()}],rotate:[{rotate:de()}],"rotate-x":[{"rotate-x":de()}],"rotate-y":[{"rotate-y":de()}],"rotate-z":[{"rotate-z":de()}],scale:[{scale:I()}],"scale-x":[{"scale-x":I()}],"scale-y":[{"scale-y":I()}],"scale-z":[{"scale-z":I()}],"scale-3d":[`scale-3d`],skew:[{skew:fe()}],"skew-x":[{"skew-x":fe()}],"skew-y":[{"skew-y":fe()}],transform:[{transform:[q,K,``,`none`,`gpu`,`cpu`]}],"transform-origin":[{origin:x()}],"transform-style":[{transform:[`3d`,`flat`]}],translate:[{translate:pe()}],"translate-x":[{"translate-x":pe()}],"translate-y":[{"translate-y":pe()}],"translate-z":[{"translate-z":pe()}],"translate-none":[`translate-none`],zoom:[{zoom:[Pn,q,K]}],accent:[{accent:j()}],appearance:[{appearance:[`none`,`auto`]}],"caret-color":[{caret:j()}],"color-scheme":[{scheme:[`normal`,`dark`,`light`,`light-dark`,`only-dark`,`only-light`]}],cursor:[{cursor:[`auto`,`default`,`pointer`,`wait`,`text`,`move`,`help`,`not-allowed`,`none`,`context-menu`,`progress`,`cell`,`crosshair`,`vertical-text`,`alias`,`copy`,`no-drop`,`grab`,`grabbing`,`all-scroll`,`col-resize`,`row-resize`,`n-resize`,`e-resize`,`s-resize`,`w-resize`,`ne-resize`,`nw-resize`,`se-resize`,`sw-resize`,`ew-resize`,`ns-resize`,`nesw-resize`,`nwse-resize`,`zoom-in`,`zoom-out`,q,K]}],"field-sizing":[{"field-sizing":[`fixed`,`content`]}],"pointer-events":[{"pointer-events":[`auto`,`none`]}],resize:[{resize:[`none`,``,`y`,`x`]}],"scroll-behavior":[{scroll:[`auto`,`smooth`]}],"scrollbar-thumb-color":[{"scrollbar-thumb":j()}],"scrollbar-track-color":[{"scrollbar-track":j()}],"scrollbar-gutter":[{"scrollbar-gutter":[`auto`,`stable`,`both`]}],"scrollbar-w":[{scrollbar:[`auto`,`thin`,`none`]}],"scroll-m":[{"scroll-m":w()}],"scroll-mx":[{"scroll-mx":w()}],"scroll-my":[{"scroll-my":w()}],"scroll-ms":[{"scroll-ms":w()}],"scroll-me":[{"scroll-me":w()}],"scroll-mbs":[{"scroll-mbs":w()}],"scroll-mbe":[{"scroll-mbe":w()}],"scroll-mt":[{"scroll-mt":w()}],"scroll-mr":[{"scroll-mr":w()}],"scroll-mb":[{"scroll-mb":w()}],"scroll-ml":[{"scroll-ml":w()}],"scroll-p":[{"scroll-p":w()}],"scroll-px":[{"scroll-px":w()}],"scroll-py":[{"scroll-py":w()}],"scroll-ps":[{"scroll-ps":w()}],"scroll-pe":[{"scroll-pe":w()}],"scroll-pbs":[{"scroll-pbs":w()}],"scroll-pbe":[{"scroll-pbe":w()}],"scroll-pt":[{"scroll-pt":w()}],"scroll-pr":[{"scroll-pr":w()}],"scroll-pb":[{"scroll-pb":w()}],"scroll-pl":[{"scroll-pl":w()}],"snap-align":[{snap:[`start`,`end`,`center`,`align-none`]}],"snap-stop":[{snap:[`normal`,`always`]}],"snap-type":[{snap:[`none`,`x`,`y`,`both`]}],"snap-strictness":[{snap:[`mandatory`,`proximity`]}],touch:[{touch:[`auto`,`none`,`manipulation`]}],"touch-x":[{"touch-pan":[`x`,`left`,`right`]}],"touch-y":[{"touch-pan":[`y`,`up`,`down`]}],"touch-pz":[`touch-pinch-zoom`],select:[{select:[`none`,`text`,`all`,`auto`]}],"will-change":[{"will-change":[`auto`,`scroll`,`contents`,`transform`,q,K]}],fill:[{fill:[`none`,...j()]}],"stroke-w":[{stroke:[G,Qn,Gn,Kn]}],stroke:[{stroke:[`none`,...j()]}],"forced-color-adjust":[{"forced-color-adjust":[`auto`,`none`]}]},conflictingClassGroups:{"container-named":[`container-type`],overflow:[`overflow-x`,`overflow-y`],overscroll:[`overscroll-x`,`overscroll-y`],inset:[`inset-x`,`inset-y`,`inset-bs`,`inset-be`,`start`,`end`,`top`,`right`,`bottom`,`left`],"inset-x":[`start`,`end`,`right`,`left`],"inset-y":[`inset-bs`,`inset-be`,`top`,`bottom`],flex:[`basis`,`grow`,`shrink`],gap:[`gap-x`,`gap-y`],p:[`px`,`py`,`ps`,`pe`,`pbs`,`pbe`,`pt`,`pr`,`pb`,`pl`],px:[`ps`,`pe`,`pr`,`pl`],py:[`pbs`,`pbe`,`pt`,`pb`],m:[`mx`,`my`,`ms`,`me`,`mbs`,`mbe`,`mt`,`mr`,`mb`,`ml`],mx:[`ms`,`me`,`mr`,`ml`],my:[`mbs`,`mbe`,`mt`,`mb`],size:[`w`,`h`],"font-size":[`leading`],"fvn-normal":[`fvn-ordinal`,`fvn-slashed-zero`,`fvn-figure`,`fvn-spacing`,`fvn-fraction`],"fvn-ordinal":[`fvn-normal`],"fvn-slashed-zero":[`fvn-normal`],"fvn-figure":[`fvn-normal`],"fvn-spacing":[`fvn-normal`],"fvn-fraction":[`fvn-normal`],"line-clamp":[`display`,`overflow`],rounded:[`rounded-s`,`rounded-e`,`rounded-t`,`rounded-r`,`rounded-b`,`rounded-l`,`rounded-ss`,`rounded-se`,`rounded-ee`,`rounded-es`,`rounded-tl`,`rounded-tr`,`rounded-br`,`rounded-bl`],"rounded-s":[`rounded-ss`,`rounded-es`],"rounded-e":[`rounded-se`,`rounded-ee`],"rounded-t":[`rounded-tl`,`rounded-tr`],"rounded-r":[`rounded-tr`,`rounded-br`],"rounded-b":[`rounded-br`,`rounded-bl`],"rounded-l":[`rounded-tl`,`rounded-bl`],"border-spacing":[`border-spacing-x`,`border-spacing-y`],"border-w":[`border-w-x`,`border-w-y`,`border-w-s`,`border-w-e`,`border-w-bs`,`border-w-be`,`border-w-t`,`border-w-r`,`border-w-b`,`border-w-l`],"border-w-x":[`border-w-s`,`border-w-e`,`border-w-r`,`border-w-l`],"border-w-y":[`border-w-bs`,`border-w-be`,`border-w-t`,`border-w-b`],"border-color":[`border-color-x`,`border-color-y`,`border-color-s`,`border-color-e`,`border-color-bs`,`border-color-be`,`border-color-t`,`border-color-r`,`border-color-b`,`border-color-l`],"border-color-x":[`border-color-s`,`border-color-e`,`border-color-r`,`border-color-l`],"border-color-y":[`border-color-bs`,`border-color-be`,`border-color-t`,`border-color-b`],translate:[`translate-x`,`translate-y`,`translate-none`],"translate-none":[`translate`,`translate-x`,`translate-y`,`translate-z`],"scroll-m":[`scroll-mx`,`scroll-my`,`scroll-ms`,`scroll-me`,`scroll-mbs`,`scroll-mbe`,`scroll-mt`,`scroll-mr`,`scroll-mb`,`scroll-ml`],"scroll-mx":[`scroll-ms`,`scroll-me`,`scroll-mr`,`scroll-ml`],"scroll-my":[`scroll-mbs`,`scroll-mbe`,`scroll-mt`,`scroll-mb`],"scroll-p":[`scroll-px`,`scroll-py`,`scroll-ps`,`scroll-pe`,`scroll-pbs`,`scroll-pbe`,`scroll-pt`,`scroll-pr`,`scroll-pb`,`scroll-pl`],"scroll-px":[`scroll-ps`,`scroll-pe`,`scroll-pr`,`scroll-pl`],"scroll-py":[`scroll-pbs`,`scroll-pbe`,`scroll-pt`,`scroll-pb`],touch:[`touch-x`,`touch-y`,`touch-pz`],"touch-x":[`touch`],"touch-y":[`touch`],"touch-pz":[`touch`]},conflictingClassGroupModifiers:{"font-size":[`leading`]},postfixLookupClassGroups:[`container-type`],orderSensitiveModifiers:[`*`,`**`,`after`,`backdrop`,`before`,`details-content`,`file`,`first-letter`,`first-line`,`marker`,`placeholder`,`selection`]}});function J(...e){return hr(Vt(e))}var Y=i(),gr=Wt(`inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0`,{variants:{variant:{default:`bg-accent text-accent-fg hover:opacity-90`,secondary:`bg-raised text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]`,ghost:`text-muted hover:bg-raised hover:text-fg`,danger:`bg-danger text-fg hover:opacity-90`},size:{default:`h-11 px-4`,sm:`h-9 px-3 text-xs`,lg:`h-12 px-5`,icon:`size-11`}},defaultVariants:{variant:`default`,size:`default`}});function X({className:e,variant:t,size:n,asChild:r,...i}){return(0,Y.jsx)(r?Dt:`button`,{className:J(gr({variant:t,size:n,className:e})),...i})}function _r({className:e,...t}){return(0,Y.jsx)(`input`,{className:J(`flex h-11 w-full rounded-md bg-raised px-3 text-sm text-fg shadow-[var(--shadow-border)]`,`placeholder:text-faint focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50`,`disabled:opacity-40`,e),...t})}function vr({className:e,...t}){return(0,Y.jsx)(`label`,{className:J(`text-xs font-medium text-muted`,e),...t})}var yr=Object.defineProperty,br=(e,t)=>yr(e,`name`,{value:t,configurable:!0}),xr=!!(typeof window<`u`&&window.document&&window.document.createElement);function Sr(e,t,{checkForDefaultPrevented:n=!0}={}){return br(function(r){if(e?.(r),n===!1||!r||!r.defaultPrevented)return t?.(r)},`handleEvent`)}br(Sr,`composeEventHandlers`);function Cr(e){if(!xr)throw Error(`Cannot access window outside of the DOM`);return e?.ownerDocument?.defaultView??window}br(Cr,`getOwnerWindow`);function wr(e){if(!xr)throw Error(`Cannot access document outside of the DOM`);return e?.ownerDocument??document}br(wr,`getOwnerDocument`);function Tr(e,t=!1){let{activeElement:n}=wr(e);if(!n?.nodeName)return null;if(Er(n)&&n.contentDocument)return Tr(n.contentDocument.body,t);if(t){let e=n.getAttribute(`aria-activedescendant`);if(e){let t=wr(n).getElementById(e);if(t)return t}}return n}br(Tr,`getActiveElement`);function Er(e){return e.tagName===`IFRAME`}br(Er,`isFrame`);var Dr=Object.defineProperty,Z=(e,t)=>Dr(e,`name`,{value:t,configurable:!0});function Or(e,t){let n=O.createContext(t);n.displayName=e+`Context`;let r=Z(e=>{let{children:t,...r}=e,i=O.useMemo(()=>r,Object.values(r));return(0,Y.jsx)(n.Provider,{value:i,children:t})},`Provider`);r.displayName=e+`Provider`;function i(r,i={}){let{optional:a=!1}=i,o=O.useContext(n);if(o)return o;if(t!==void 0)return t;if(!a)throw Error(`\`${r}\` must be used within \`${e}\``)}return Z(i,`useContext`),[r,i]}Z(Or,`createContext`);function kr(e,t=[]){let n=[];function r(t,r){let i=O.createContext(r);i.displayName=t+`Context`;let a=n.length;n=[...n,r];let o=Z(t=>{let{scope:n,children:r,...o}=t,s=n?.[e]?.[a]||i,c=O.useMemo(()=>o,Object.values(o));return(0,Y.jsx)(s.Provider,{value:c,children:r})},`Provider`);o.displayName=t+`Provider`;function s(n,o,s={}){let{optional:c=!1}=s,l=o?.[e]?.[a]||i,u=O.useContext(l);if(u)return u;if(r!==void 0)return r;if(!c)throw Error(`\`${n}\` must be used within \`${t}\``)}return Z(s,`useContext`),[o,s]}Z(r,`createContext`);let i=Z(()=>{let t=n.map(e=>O.createContext(e));return Z(function(n){let r=n?.[e]||t;return O.useMemo(()=>({[`__scope${e}`]:{...n,[e]:r}}),[n,r])},`useScope`)},`createScope`);return i.scopeName=e,[r,Ar(i,...t)]}Z(kr,`createContextScope`);function Ar(...e){let t=e[0];if(e.length===1)return t;let n=Z(()=>{let n=e.map(e=>({useScope:e(),scopeName:e.scopeName}));return Z(function(e){let r=n.reduce((t,{useScope:n,scopeName:r})=>{let i=n(e)[`__scope${r}`];return{...t,...i}},{});return O.useMemo(()=>({[`__scope${t.scopeName}`]:r}),[r])},`useComposedScopes`)},`createScope`);return n.scopeName=t.scopeName,n}Z(Ar,`composeContextScopes`);var jr=globalThis?.document?O.useLayoutEffect:()=>{},Mr=Object.defineProperty,Nr=(e,t)=>Mr(e,`name`,{value:t,configurable:!0}),Pr=O.useEffectEvent,Fr=O.useInsertionEffect;function Ir(e){if(typeof Pr==`function`)return Pr(e);let t=O.useRef(()=>{throw Error(`Cannot call an event handler while rendering.`)});return typeof Fr==`function`?Fr(()=>{t.current=e}):jr(()=>{t.current=e}),O.useMemo(()=>((...e)=>t.current?.(...e)),[])}Nr(Ir,`useEffectEvent`);var Lr=Object.defineProperty,Rr=(e,t)=>Lr(e,`name`,{value:t,configurable:!0}),zr=O.useInsertionEffect||jr;function Br({prop:e,defaultProp:t,onChange:n=Rr(()=>{},`onChange`),caller:r}){let[i,a,o]=Vr({defaultProp:t,onChange:n}),s=e!==void 0;return[s?e:i,O.useCallback(t=>{if(s){let n=Hr(t)?t(e):t;n!==e&&o.current?.(n)}else a(t)},[s,e,a,o])]}Rr(Br,`useControllableState`);function Vr({defaultProp:e,onChange:t}){let[n,r]=O.useState(e),i=O.useRef(n),a=O.useRef(t);return zr(()=>{a.current=t},[t]),O.useEffect(()=>{i.current!==n&&(a.current?.(n),i.current=n)},[n,i]),[n,r,a]}Rr(Vr,`useUncontrolledState`);function Hr(e){return typeof e==`function`}Rr(Hr,`isFunction`);var Ur=Symbol(`RADIX:SYNC_STATE`);function Wr(e,t,n,r){let{prop:i,defaultProp:a,onChange:o,caller:s}=t,c=i!==void 0,l=Ir(o),u=[{...n,state:a}];r&&u.push(r);let[d,f]=O.useReducer((t,n)=>{if(n.type===Ur)return{...t,state:n.state};let r=e(t,n);return c&&!Object.is(r.state,t.state)&&l(r.state),r},...u),p=d.state,m=O.useRef(p);O.useEffect(()=>{m.current!==p&&(m.current=p,c||l(p))},[p,m,c]);let h=O.useMemo(()=>i===void 0?d:{...d,state:i},[d,i]);return O.useEffect(()=>{c&&!Object.is(i,d.state)&&f({type:Ur,state:i})},[i,d.state,c]),[h,f]}Rr(Wr,`useControllableStateReducer`);var Gr=Object.defineProperty,Kr=(e,t)=>Gr(e,`name`,{value:t,configurable:!0});function qr(e){let[t,n]=O.useState(void 0);return jr(()=>{if(e){n({width:e.offsetWidth,height:e.offsetHeight});let t=new ResizeObserver(t=>{if(!Array.isArray(t)||!t.length)return;let r=t[0],i,a;if(`borderBoxSize`in r){let e=r.borderBoxSize,t=Array.isArray(e)?e[0]:e;i=t.inlineSize,a=t.blockSize}else i=e.offsetWidth,a=e.offsetHeight;n({width:i,height:a})});return t.observe(e,{box:`border-box`}),()=>t.unobserve(e)}n(void 0)},[e]),t}Kr(qr,`useSize`);var Jr=Object.defineProperty,Yr=(e,t)=>Jr(e,`name`,{value:t,configurable:!0}),Xr=[`a`,`button`,`div`,`form`,`h2`,`h3`,`img`,`input`,`label`,`li`,`nav`,`ol`,`p`,`select`,`span`,`svg`,`ul`].reduce((e,t)=>{let n=Et(`Primitive.${t}`),r=O.forwardRef((e,r)=>{let{asChild:i,...a}=e,o=i?n:t;return typeof window<`u`&&(window[Symbol.for(`radix-ui`)]=!0),(0,Y.jsx)(o,{...a,ref:r})});return r.displayName=`Primitive.${t}`,{...e,[t]:r}},{});function Zr(e,t){e&&k.flushSync(()=>e.dispatchEvent(t))}Yr(Zr,`dispatchDiscreteCustomEvent`);var Qr=Object.defineProperty,$r=(e,t)=>Qr(e,`name`,{value:t,configurable:!0}),ei=`Switch`,[ti,ni]=kr(ei),[ri,ii]=ti(ei);function ai(e){let{__scopeSwitch:t,checked:n,children:r,defaultChecked:i,disabled:a,form:o,name:s,onCheckedChange:c,required:l,value:u=`on`,internal_do_not_use_render:d}=e,[f,p]=Br({prop:n,defaultProp:i??!1,onChange:c,caller:ei}),[m,h]=O.useState(null),[g,_]=O.useState(null),v=O.useRef(!1),[y,b]=O.useReducer(e=>e+1,0),x={checked:f,setChecked:p,disabled:a,control:m,setControl:h,name:s,form:o,value:u,hasConsumerStoppedPropagationRef:v,userInteractionCount:y,onUserInteraction:b,required:l,defaultChecked:i,isFormControl:!m||!!o||!!m.closest(`form`),bubbleInput:g,setBubbleInput:_};return(0,Y.jsx)(ri,{scope:t,...x,children:pi(d)?d(x):r})}$r(ai,`SwitchProvider`);var oi=`SwitchTrigger`,si=O.forwardRef($r(function({__scopeSwitch:e,onClick:t,...n},r){let{control:i,form:a,value:o,disabled:s,checked:c,required:l,setControl:u,setChecked:d,hasConsumerStoppedPropagationRef:f,onUserInteraction:p,isFormControl:m,bubbleInput:h}=ii(oi,e),g=wt(r,u),_=O.useRef(c);return O.useEffect(()=>{let e=a?i?.ownerDocument.getElementById(a):i?.form;if(e instanceof HTMLFormElement){let t=$r(()=>d(_.current),`reset`);return e.addEventListener(`reset`,t),()=>e.removeEventListener(`reset`,t)}},[i,a,d]),(0,Y.jsx)(Xr.button,{type:`button`,role:`switch`,"aria-checked":c,"aria-required":l,"data-state":mi(c),"data-disabled":s?``:void 0,disabled:s,value:o,...n,ref:g,onClick:Sr(t,e=>{p(),d(e=>!e),h&&m&&(f.current=e.isPropagationStopped(),f.current||e.stopPropagation())})})},`SwitchTrigger`)),ci=O.forwardRef($r(function(e,t){let{__scopeSwitch:n,name:r,checked:i,defaultChecked:a,required:o,disabled:s,value:c,onCheckedChange:l,form:u,...d}=e;return(0,Y.jsx)(ai,{__scopeSwitch:n,checked:i,defaultChecked:a,disabled:s,required:o,onCheckedChange:l,name:r,form:u,value:c,internal_do_not_use_render:({isFormControl:e})=>(0,Y.jsxs)(Y.Fragment,{children:[(0,Y.jsx)(si,{...d,ref:t,__scopeSwitch:n}),e&&(0,Y.jsx)(fi,{__scopeSwitch:n})]})})},`Switch`)),li=`SwitchThumb`,ui=O.forwardRef($r(function(e,t){let{__scopeSwitch:n,...r}=e,i=ii(li,n);return(0,Y.jsx)(Xr.span,{"data-state":mi(i.checked),"data-disabled":i.disabled?``:void 0,...r,ref:t})},`SwitchThumb`)),di=`SwitchBubbleInput`,fi=O.forwardRef($r(function({__scopeSwitch:e,onClick:t,...n},r){let{control:i,hasConsumerStoppedPropagationRef:a,userInteractionCount:o,checked:s,defaultChecked:c,required:l,disabled:u,name:d,value:f,form:p,bubbleInput:m,setBubbleInput:h}=ii(di,e),g=wt(r,h),_=qr(i),v=O.useRef(!1),y=O.useRef(s),b=O.useRef(o);O.useEffect(()=>{let e=m;if(!e)return;let t=window.HTMLInputElement.prototype,n=Object.getOwnPropertyDescriptor(t,`checked`).set,r=o!==b.current;b.current=o;let i=y.current!==s;y.current=s;let c=!(r&&a.current);if(i&&n){v.current=!r;let t=new Event(`click`,{bubbles:c});n.call(e,s),e.dispatchEvent(t),v.current=!1}},[m,s,a,o]);let x=O.useRef(s);return(0,Y.jsx)(Xr.input,{type:`checkbox`,"aria-hidden":!0,defaultChecked:c??x.current,required:l,disabled:u,name:d,value:f,form:p,...n,tabIndex:-1,ref:g,onClick:Sr(t,e=>{v.current&&e.stopPropagation()}),style:{...n.style,..._,position:`absolute`,pointerEvents:`none`,opacity:0,margin:0,transform:`translateX(-100%)`}})},`SwitchBubbleInput`));function pi(e){return typeof e==`function`}$r(pi,`isFunction`);function mi(e){return e?`checked`:`unchecked`}$r(mi,`getState`);function hi({className:e,...t}){return(0,Y.jsx)(ci,{className:J(`peer inline-flex h-7 w-12 shrink-0 items-center rounded-full bg-raised shadow-[var(--shadow-border)]`,`transition-colors duration-150 data-[state=checked]:bg-accent`,`focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50`,e),...t,children:(0,Y.jsx)(ui,{className:J(`pointer-events-none block size-5 translate-x-1 rounded-full bg-fg transition-transform duration-150`,`data-[state=checked]:translate-x-6 data-[state=checked]:bg-accent-fg`)})})}function gi({className:e,...t}){return(0,Y.jsx)(`textarea`,{className:J(`flex min-h-32 w-full rounded-lg bg-raised px-3 py-3 text-sm text-fg shadow-[var(--shadow-border)]`,`placeholder:text-faint focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50`,e),...t})}var _i=[{id:`stealth`,label:`Stealth`},{id:`telegram`,label:`Telegram`},{id:`filter`,label:`Filtr`},{id:`features`,label:`32 xüsusiyyət`}];function vi(){let e=H(e=>e.settings),t=H(e=>e.patchSettings),n=H(e=>e.stats),r=H(e=>e.health),[i,a]=(0,O.useState)(`stealth`),o=n.checks>0?Math.round(n.okHits/n.checks*100):0;async function s(){if(!e.telegramToken||!e.telegramChatId){I.error(`Token və chat ID doldurun`);return}try{let t=await Ne({data:{token:e.telegramToken,chatId:e.telegramChatId,text:`SandıqRadar test. Növ + nəfər sayı işləkdir.`}});t.ok?I.success(`Test mesajı göndərildi`):I.error(t.error)}catch(e){I.error(e instanceof Error?e.message:`Göndərmə xətası`)}}return(0,Y.jsxs)(`div`,{className:`mx-auto flex w-full max-w-3xl flex-col gap-5`,children:[(0,Y.jsxs)(`header`,{children:[(0,Y.jsx)(`p`,{className:`text-xs font-medium tracking-wide text-muted uppercase`,children:`Mühərrik və xəbərdarlıq`}),(0,Y.jsx)(`h2`,{className:`mt-1 text-xl font-semibold`,children:`Ayarlar`}),(0,Y.jsx)(`p`,{className:`mt-2 text-sm text-muted`,children:`Stealth rejim cookie warmup, UA rotasiyası və backoff ilə TikTok-un blokunu azaldır. Datacenter IP yenə kəsilə bilər — Python paketini residential proxy ilə VPS-də işə salın.`})]}),(0,Y.jsxs)(`div`,{className:`grid grid-cols-2 gap-3 sm:grid-cols-4`,children:[(0,Y.jsx)(yi,{label:`Uğur`,value:`${o}%`}),(0,Y.jsx)(yi,{label:`Blok`,value:V(n.blocked)}),(0,Y.jsx)(yi,{label:`Peak nəfər`,value:V(n.peakLiveViewers)}),(0,Y.jsx)(yi,{label:`Sağlamlıq`,value:r===`ok`?`OK`:r===`cooling`?`Backoff`:r===`blocked`?`Blok`:`—`})]}),(0,Y.jsx)(`div`,{className:`flex flex-wrap gap-1.5`,children:_i.map(e=>(0,Y.jsx)(`button`,{type:`button`,onClick:()=>a(e.id),className:`h-10 rounded-md px-3 text-sm font-medium transition-colors duration-150 ${i===e.id?`bg-raised text-fg`:`text-muted hover:text-fg`}`,children:e.label},e.id))}),i===`stealth`?(0,Y.jsxs)(`section`,{className:`rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5`,children:[(0,Y.jsx)(`h3`,{className:`text-sm font-medium`,children:`Anti-blok`}),(0,Y.jsxs)(`div`,{className:`mt-4 flex flex-col gap-3`,children:[(0,Y.jsx)(xi,{label:`Stealth rejim`,hint:`Kiçik batch, jitter, cookie sessiyası, UA + Client Hints rotasiyası`,checked:e.stealthMode,onChange:e=>t({stealthMode:e})}),(0,Y.jsx)(xi,{label:`Blokda avto-yavaşla`,hint:`403/429 dalğasında mühərrik özü backoff edir`,checked:e.autoPauseOnBlock,onChange:e=>t({autoPauseOnBlock:e})}),(0,Y.jsx)(xi,{label:`Səs siqnalı`,hint:`Qutu tapılanda qısa ton`,checked:e.soundAlerts,onChange:e=>t({soundAlerts:e})}),(0,Y.jsx)(xi,{label:`Brauzer bildirişi`,hint:`Növ və nəfər sayı bildiriş mətnində`,checked:e.browserNotify,onChange:e=>{t({browserNotify:e}),e&&Fe().then(e=>{e||I.error(`Bildiriş icazəsi verilmədi`)})}})]}),(0,Y.jsxs)(`div`,{className:`mt-4 grid gap-4 sm:grid-cols-2`,children:[(0,Y.jsx)(bi,{id:`conc`,label:`Paralel worker (Python)`,children:(0,Y.jsx)(_r,{id:`conc`,type:`number`,min:4,max:80,value:e.concurrency,onChange:e=>t({concurrency:Si(Number(e.target.value)||12,4,80)})})}),(0,Y.jsx)(bi,{id:`intv`,label:`Dövrə (ms)`,children:(0,Y.jsx)(_r,{id:`intv`,type:`number`,min:2e3,max:3e4,value:e.intervalMs,onChange:e=>t({intervalMs:Si(Number(e.target.value)||8e3,2e3,3e4)})})})]}),(0,Y.jsxs)(`div`,{className:`mt-4 flex flex-col gap-1.5`,children:[(0,Y.jsx)(vr,{htmlFor:`proxies`,children:`Proxy siyahısı (Python)`}),(0,Y.jsx)(gi,{id:`proxies`,value:e.proxiesText,onChange:e=>t({proxiesText:e.target.value}),placeholder:`http://user:pass@host:port
socks5://host:1080`,className:`min-h-24`}),(0,Y.jsx)(`p`,{className:`text-xs text-muted`,children:`Web tarayıcı sizin brauzer IP-sindən gedir; proxy yalnız Python paketində işləyir.`})]})]}):null,i===`telegram`?(0,Y.jsxs)(`section`,{className:`rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5`,children:[(0,Y.jsx)(`h3`,{className:`text-sm font-medium`,children:`Telegram`}),(0,Y.jsxs)(`div`,{className:`mt-4 flex flex-col gap-4`,children:[(0,Y.jsx)(bi,{id:`token`,label:`Bot tokeni`,children:(0,Y.jsx)(_r,{id:`token`,type:`password`,autoComplete:`off`,value:e.telegramToken,onChange:e=>t({telegramToken:e.target.value.trim()}),placeholder:`123456:AA…`})}),(0,Y.jsx)(bi,{id:`chat`,label:`Chat ID`,children:(0,Y.jsx)(_r,{id:`chat`,value:e.telegramChatId,onChange:e=>t({telegramChatId:e.target.value.trim()}),placeholder:`-100…`})}),(0,Y.jsx)(xi,{label:`Avtomatik göndər`,hint:`Sandıq və ya hədiyyə çantası tapılanda dərhal`,checked:e.autoTelegram,onChange:e=>t({autoTelegram:e})}),(0,Y.jsx)(X,{variant:`secondary`,onClick:()=>void s(),children:`Test mesajı göndər`}),(0,Y.jsxs)(`p`,{className:`text-xs text-muted`,children:[`Uğurlu göndəriş: `,n.telegramOk]})]})]}):null,i===`filter`?(0,Y.jsxs)(`section`,{className:`rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5`,children:[(0,Y.jsx)(`h3`,{className:`text-sm font-medium`,children:`Xəbərdarlıq filtri`}),(0,Y.jsxs)(`div`,{className:`mt-4 grid gap-4 sm:grid-cols-3`,children:[(0,Y.jsx)(bi,{id:`rate`,label:`Min rate`,children:(0,Y.jsx)(_r,{id:`rate`,type:`number`,min:0,step:.5,value:e.minRate,onChange:e=>t({minRate:Math.max(0,Number(e.target.value)||0)})})}),(0,Y.jsx)(bi,{id:`view`,label:`Min nəfər`,children:(0,Y.jsx)(_r,{id:`view`,type:`number`,min:0,value:e.minViewers,onChange:e=>t({minViewers:Math.max(0,Number(e.target.value)||0)})})}),(0,Y.jsx)(bi,{id:`coins`,label:`Min jeton`,children:(0,Y.jsx)(_r,{id:`coins`,type:`number`,min:0,value:e.minCoins,onChange:e=>t({minCoins:Math.max(0,Number(e.target.value)||0)})})})]}),(0,Y.jsxs)(`div`,{className:`mt-4 flex flex-col gap-1.5`,children:[(0,Y.jsx)(vr,{htmlFor:`prio`,children:`Prioritet unique_id`}),(0,Y.jsx)(gi,{id:`prio`,value:e.priorityText,onChange:e=>t({priorityText:e.target.value}),placeholder:`ramiz_real
zevs_show`,className:`min-h-24`}),(0,Y.jsx)(`p`,{className:`text-xs text-muted`,children:`Bu adlar hər dövrdə birinci yoxlanır.`})]})]}):null,i===`features`?(0,Y.jsxs)(`section`,{className:`rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5`,children:[(0,Y.jsxs)(`h3`,{className:`text-sm font-medium`,children:[Ie.length,` xüsusiyyət`]}),(0,Y.jsx)(`ul`,{className:`mt-4 grid gap-2 sm:grid-cols-2`,children:Ie.map((e,t)=>(0,Y.jsxs)(`li`,{className:`rounded-lg bg-raised px-3 py-3`,children:[(0,Y.jsx)(`p`,{className:`text-xs text-faint tabular-nums`,children:String(t+1).padStart(2,`0`)}),(0,Y.jsx)(`p`,{className:`mt-1 text-sm font-medium`,children:e.title}),(0,Y.jsx)(`p`,{className:`mt-1 text-xs leading-relaxed text-muted`,children:e.detail})]},e.id))})]}):null]})}function yi({label:e,value:t}){return(0,Y.jsxs)(`div`,{className:`rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]`,children:[(0,Y.jsx)(`p`,{className:`text-xs text-muted`,children:e}),(0,Y.jsx)(`p`,{className:`mt-1 font-mono text-lg tabular-nums`,children:t})]})}function bi({id:e,label:t,children:n}){return(0,Y.jsxs)(`div`,{className:`flex flex-col gap-1.5`,children:[(0,Y.jsx)(vr,{htmlFor:e,children:t}),n]})}function xi({label:e,hint:t,checked:n,onChange:r}){return(0,Y.jsxs)(`div`,{className:`flex items-center justify-between gap-3 rounded-lg bg-raised px-3 py-3`,children:[(0,Y.jsxs)(`div`,{children:[(0,Y.jsx)(`p`,{className:`text-sm font-medium`,children:e}),(0,Y.jsx)(`p`,{className:`text-xs text-muted`,children:t})]}),(0,Y.jsx)(hi,{checked:n,onCheckedChange:r,"aria-label":e})]})}function Si(e,t,n){return Math.min(n,Math.max(t,e))}var Ci=[{name:`config.py`,zipPath:`sandiqradar-bot/config.py`,content:`"""SandıqRadar konfiqurasiyası."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")


def _int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    return int(raw)


def _float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    return float(raw)


def _bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True, slots=True)
class Config:
    telegram_bot_token: str
    telegram_chat_id: str
    usernames_file: Path
    proxies_file: Path
    check_interval: float
    chest_poll_interval: float
    max_concurrent: int
    max_ws_listeners: int
    request_timeout: float
    min_rate: float
    min_viewers: int
    min_coins: int
    jitter_sec: float
    user_agent_rotate: bool
    dry_run: bool
    strict_identity: bool
    reload_every: int
    warmup_cookies: bool
    stealth: bool

    @classmethod
    def load(cls) -> "Config":
        token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
        chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
        if not token or not chat_id:
            raise RuntimeError("TELEGRAM_BOT_TOKEN və TELEGRAM_CHAT_ID .env faylında mütləqdir.")
        stealth = _bool("STEALTH", True)
        default_conc = 8 if stealth else 24
        return cls(
            telegram_bot_token=token,
            telegram_chat_id=chat_id,
            usernames_file=Path(os.getenv("USERNAMES_FILE", str(ROOT / "usernames.txt"))),
            proxies_file=Path(os.getenv("PROXIES_FILE", str(ROOT / "proxies.txt"))),
            check_interval=_float("CHECK_INTERVAL", 8.0 if stealth else 6.0),
            chest_poll_interval=_float("CHEST_POLL_INTERVAL", 2.5),
            max_concurrent=_int("MAX_CONCURRENT", default_conc),
            max_ws_listeners=_int("MAX_WS_LISTENERS", 16),
            request_timeout=_float("REQUEST_TIMEOUT", 10.0),
            min_rate=_float("MIN_RATE", 1.0),
            min_viewers=_int("MIN_VIEWERS", 0),
            min_coins=_int("MIN_COINS", 0),
            jitter_sec=_float("JITTER_SEC", 1.8 if stealth else 1.2),
            user_agent_rotate=_bool("USER_AGENT_ROTATE", True),
            dry_run=_bool("DRY_RUN", False),
            strict_identity=_bool("STRICT_IDENTITY", True),
            reload_every=_int("RELOAD_EVERY", 8),
            warmup_cookies=_bool("WARMUP_COOKIES", True),
            stealth=stealth,
        )
`,language:`python`},{name:`stealth.py`,zipPath:`sandiqradar-bot/stealth.py`,content:`"""Brauzer kimliyi, cookie warmup və anti-blok başlıqları."""

from __future__ import annotations

import random
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class BrowserProfile:
    ua: str
    sec_ch_ua: str
    sec_ch_ua_mobile: str
    sec_ch_ua_platform: str
    platform: str
    language: str
    width: str
    height: str


PROFILES: tuple[BrowserProfile, ...] = (
    BrowserProfile(
        ua=(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        ),
        sec_ch_ua='"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        sec_ch_ua_mobile="?0",
        sec_ch_ua_platform='"Windows"',
        platform="Win32",
        language="az-AZ,az;q=0.9,en-US;q=0.8,en;q=0.7",
        width="1920",
        height="1080",
    ),
    BrowserProfile(
        ua=(
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7) AppleWebKit/605.1.15 "
            "(KHTML, like Gecko) Version/18.1 Safari/605.1.15"
        ),
        sec_ch_ua='"Not A(Brand";v="99", "Safari";v="18", "Chromium";v="130"',
        sec_ch_ua_mobile="?0",
        sec_ch_ua_platform='"macOS"',
        platform="MacIntel",
        language="az-AZ,az;q=0.9,en;q=0.7",
        width="1680",
        height="1050",
    ),
    BrowserProfile(
        ua=(
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
        ),
        sec_ch_ua='"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
        sec_ch_ua_mobile="?0",
        sec_ch_ua_platform='"Linux"',
        platform="Linux x86_64",
        language="en-US,en;q=0.9,az;q=0.6",
        width="1920",
        height="1200",
    ),
    BrowserProfile(
        ua=(
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        ),
        sec_ch_ua='"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        sec_ch_ua_mobile="?1",
        sec_ch_ua_platform='"Android"',
        platform="Linux armv8l",
        language="az-AZ,az;q=0.9,en-US;q=0.8",
        width="412",
        height="915",
    ),
    BrowserProfile(
        ua="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0",
        sec_ch_ua='"Not.A/Brand";v="8", "Chromium";v="131"',
        sec_ch_ua_mobile="?0",
        sec_ch_ua_platform='"Windows"',
        platform="Win32",
        language="az,en-US;q=0.8,en;q=0.6",
        width="1536",
        height="864",
    ),
)


def pick_profile() -> BrowserProfile:
    return random.choice(PROFILES)


def random_device_id() -> str:
    digits = [str(random.randint(1, 9))] + [str(random.randint(0, 9)) for _ in range(18)]
    return "".join(digits)


def request_headers(username: str, profile: BrowserProfile, html: bool = False) -> dict[str, str]:
    if html:
        accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
        dest, mode = "document", "navigate"
    else:
        accept = "application/json, text/html;q=0.9, */*;q=0.8"
        dest, mode = "empty", "cors"
    return {
        "User-Agent": profile.ua,
        "Accept": accept,
        "Accept-Language": profile.language,
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Referer": f"https://www.tiktok.com/@{username}/live" if username != "tiktok" else "https://www.tiktok.com/",
        "sec-ch-ua": profile.sec_ch_ua,
        "sec-ch-ua-mobile": profile.sec_ch_ua_mobile,
        "sec-ch-ua-platform": profile.sec_ch_ua_platform,
        "sec-fetch-dest": dest,
        "sec-fetch-mode": mode,
        "sec-fetch-site": "same-origin",
    }


def web_params(profile: BrowserProfile, extra: dict[str, str]) -> dict[str, str]:
    params = {
        "aid": "1988",
        "app_name": "tiktok_web",
        "device_platform": "web",
        "cookie_enabled": "true",
        "screen_width": profile.width,
        "screen_height": profile.height,
        "browser_language": profile.language.split(",")[0],
        "browser_platform": profile.platform,
        "browser_name": "Mozilla",
        "browser_online": "true",
        "timezone_name": "Asia/Baku",
        "webcast_language": "az",
        "app_language": "az",
    }
    params.update(extra)
    return params
`,language:`python`},{name:`identity.py`,zipPath:`sandiqradar-bot/identity.py`,content:`"""
Dəqiq istifadəçi kimliyi.

TikTok unique_id böyük/kiçik hərfə həssas deyil, amma durğu (nöqtə, alt xətt)
eyni olmalıdır. Oxşar adlar (ramiz_real1) qəbul edilmir.
"""

from __future__ import annotations

import re
from typing import Any

_AT = re.compile(r"^@+")
_WS = re.compile(r"\\s+")


def normalize_username(value: Any) -> str:
    if value is None:
        return ""
    text = _WS.sub("", str(value).strip())
    text = _AT.sub("", text)
    return text.lower()


def usernames_match(requested: str, found: Any) -> bool:
    a = normalize_username(requested)
    b = normalize_username(found)
    return bool(a) and a == b


def extract_unique_ids(payload: Any) -> list[str]:
    """Cavab JSON-undan bütün mümkün unique_id / display_id dəyərlərini çıxarır."""
    found: list[str] = []
    seen: set[str] = set()

    def add(val: Any) -> None:
        name = str(val).strip() if val is not None else ""
        if not name:
            return
        key = normalize_username(name)
        if not key or key in seen:
            return
        seen.add(key)
        found.append(name)

    def walk(node: Any, depth: int = 0) -> None:
        if depth > 8 or node is None:
            return
        if isinstance(node, dict):
            for key, val in node.items():
                lk = str(key).lower()
                if lk in {
                    "uniqueid",
                    "unique_id",
                    "display_id",
                    "displayid",
                    "uniqueidstr",
                }:
                    add(val)
                elif lk in {"user", "owner", "anchor", "ownerinfo", "userinfo"}:
                    walk(val, depth + 1)
                elif isinstance(val, (dict, list)) and depth < 5:
                    walk(val, depth + 1)
        elif isinstance(node, list):
            for item in node[:40]:
                walk(item, depth + 1)

    walk(payload)
    return found


def identity_matches(requested: str, payload: Any) -> bool:
    """
    Cavabda heç unique_id yoxdursa, endpoint username query-si ilə işləyir —
    o zaman uyğunluq qəbul edilir. Əgər unique_id varsa, dəqiq uyğunluq şərtdir.
    """
    ids = extract_unique_ids(payload)
    if not ids:
        return True
    return any(usernames_match(requested, item) for item in ids)
`,language:`python`},{name:`parser.py`,zipPath:`sandiqradar-bot/parser.py`,content:`"""TikTok canlı otaq və sandıq/hədiyyə çantası parseri."""

from __future__ import annotations

import json
import re
import time
from typing import Any
from collections.abc import Iterable

from identity import extract_unique_ids, usernames_match
from models import BOX_KIND_LABEL, LiveRoom, TreasureBox

LIVE_STATUS = {2}

_BOX_HINTS = frozenset(
    {
        "treasure_box",
        "treasurebox",
        "gift_box",
        "giftbox",
        "gift_bag",
        "giftbag",
        "lucky_box",
        "luckybox",
        "box_info",
        "boxinfo",
        "chest",
        "chest_info",
        "sandiq",
        "activity_box",
        "portal_box",
        "envelope_info",
        "envelop_info",
        "envelope",
        "envelop",
        "lucky_money",
        "red_packet",
        "redpacket",
        "box_list",
        "envelope_list",
        "portal",
        "anchor_gift_box",
        "anchorgiftbox",
        "bag_info",
        "lottery_box",
        "split_box",
        "coin_box",
    }
)
_COIN_KEYS = (
    "diamond_count",
    "diamondcount",
    "total_coins",
    "totalcoins",
    "reward_coins",
    "coins",
    "coin_count",
    "coins_count",
    "diamond_count_value",
    "total_diamond",
    "diamond",
    "reward_diamond",
)
_SLOT_KEYS = (
    "people_count",
    "peoplecount",
    "total_slots",
    "totalslots",
    "max_user",
    "max_users",
    "user_limit",
    "join_limit",
    "unpack_user_count",
    "capacity",
    "slots",
    "max_count",
    "target_user_count",
    "max_people",
    "people_num",
    "total_people",
)
_PART_KEYS = (
    "joined_count",
    "join_count",
    "current_user",
    "participants",
    "joined",
    "participate_count",
    "unpack_count",
    "open_count",
    "current_people",
    "joined_user_count",
    "now_count",
)
_ID_KEYS = (
    "envelope_id",
    "envelop_id",
    "box_id",
    "activity_id",
    "treasure_id",
    "id_str",
    "id",
)
_TYPE_KEYS = ("name", "title", "type", "gift_name", "box_name", "desc", "business_type", "display_text")
_REMAIN_KEYS = (
    "remain_time",
    "left_time",
    "remain_seconds",
    "countdown",
    "unpack_at",
    "end_time",
    "expire_at",
)
_SENDER_KEYS = ("send_user_name", "send_username", "sender_name", "from_user")
_VIEWER_KEYS = (
    "userCount",
    "user_count",
    "viewer_count",
    "viewerCount",
    "audienceCount",
    "audience_count",
    "current_user_count",
    "online_user_count",
    "watching_count",
    "display_long",
    "display_value",
)

_HYDRATION = (
    r'<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.+?)<\/script>',
    r"window\\['SIGI_STATE'\\]\\s*=\\s*(\\{.+?\\});",
    r'window\\["SIGI_STATE"\\]\\s*=\\s*(\\{.+?\\});',
    r'<script id="SIGI_STATE"[^>]*>(.+?)<\/script>',
    r'<script id="__NEXT_DATA__"[^>]*>(.+?)<\/script>',
)

_CHEST_WORDS = re.compile(
    r"(sand[ıi]q|chest|treasure|mystery\\s*box|x[əe]zin[əe]|sunduk|hazine|сундук|treasure_box|treasurebox)",
    re.I,
)
_BAG_WORDS = re.compile(
    r"(çanta|canta|bag|gift\\s*bag|giftbag|lucky\\s*bag|h[əe]diyy[əe]\\s*çantas|hediye\\s*cantasi|gift_box|giftbox)",
    re.I,
)
_ENVELOPE_WORDS = re.compile(r"(z[əe]rf|red\\s*packet|redpacket|lucky\\s*money|hongbao|红包)", re.I)
_LUCKY_WORDS = re.compile(r"([şs]ans|lucky\\s*box|luckybox)", re.I)
_PORTAL_WORDS = re.compile(r"\\bportal\\b", re.I)


def parse_count(value: Any) -> int | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)) and value == value:
        return max(0, int(value))
    text = str(value).strip().replace(" ", "").replace(",", "")
    if not text:
        return None
    match = re.match(r"^([\\d.]+)\\s*([kKmMbB])?$", text)
    if not match:
        try:
            return max(0, int(float(text)))
        except (TypeError, ValueError):
            return None
    n = float(match.group(1))
    unit = (match.group(2) or "").lower()
    if unit == "k":
        n *= 1000
    elif unit == "m":
        n *= 1_000_000
    elif unit == "b":
        n *= 1_000_000_000
    return max(0, int(n))


def classify_box_kind(node: dict[str, Any]) -> tuple[str, str, int, list[str]]:
    score = {"chest": 0, "gift_bag": 0, "envelope": 0, "portal": 0, "lucky": 0}
    signals: list[str] = []
    keys = {str(k).lower() for k in node.keys()}
    lower = {str(k).lower(): v for k, v in node.items()}
    texts = [str(lower.get(k, "")) for k in ("name", "title", "type", "gift_name", "box_name", "desc", "display_text")]
    blob = " ".join(texts + list(keys))

    business = str(lower.get("business_type") or lower.get("businesstype") or lower.get("biz_type") or "").strip().lower()
    if business in {"1", "user_diamond", "userdiamond", "treasure"}:
        score["chest"] += 48
        signals.append("business_type=1 (sandıq)")
    elif business in {"2", "platform_diamond", "platformdiamond", "gift_bag"}:
        score["gift_bag"] += 48
        signals.append("business_type=2 (hədiyyə çantası)")

    env_type = str(lower.get("envelope_type") or lower.get("envelopetype") or lower.get("box_type") or "").strip().lower()
    if env_type in {"2", "portal"}:
        score["portal"] += 40
        signals.append("envelope_type=portal")

    if any("portal_box" in k or "portalbox" in k for k in keys):
        score["portal"] += 28
        signals.append("portal_box sahəsi")
    if any(tok in k for k in keys for tok in ("treasure_box", "treasurebox", "chest_info", "anchor_gift_box")):
        score["chest"] += 22
        signals.append("treasure/chest sahəsi")
    if any(tok in k for k in keys for tok in ("gift_bag", "giftbag", "bag_info", "gift_box", "giftbox")):
        score["gift_bag"] += 22
        signals.append("gift bag sahəsi")
    if any("lucky_box" in k or "luckybox" in k for k in keys):
        score["lucky"] += 24
        signals.append("lucky_box sahəsi")
    if any(tok in k for k in keys for tok in ("red_packet", "redpacket", "lucky_money")):
        score["envelope"] += 24
        signals.append("red packet sahəsi")

    if _CHEST_WORDS.search(blob):
        score["chest"] += 26
        signals.append("ad: sandıq")
    if _BAG_WORDS.search(blob):
        score["gift_bag"] += 26
        signals.append("ad: hədiyyə çantası")
    if _ENVELOPE_WORDS.search(blob) and "envelope_id" not in blob:
        score["envelope"] += 20
        signals.append("ad: zərf")
    if _LUCKY_WORDS.search(blob) and not _BAG_WORDS.search(blob):
        score["lucky"] += 18
        signals.append("ad: şans")
    if _PORTAL_WORDS.search(blob):
        score["portal"] += 18
        signals.append("ad: portal")

    ranked = sorted(score.items(), key=lambda kv: kv[1], reverse=True)
    best, best_score = ranked[0]
    second = ranked[1][1] if len(ranked) > 1 else 0
    if best_score <= 0:
        if any(k in keys for k in ("envelope_id", "envelop_id", "box_id", "treasure_id")):
            return "chest", BOX_KIND_LABEL["chest"], 58, ["standart bölünən zərf → Sandıq"]
        return "unknown", BOX_KIND_LABEL["unknown"], 30, ["zəif siqnal"]
    conf = min(99, 52 + best_score + min(18, best_score - second))
    return best, BOX_KIND_LABEL[best], conf, signals


def parse_live_room(username: str, data: Any) -> LiveRoom | None:
    if not isinstance(data, dict):
        return None
    nested = data.get("data") if isinstance(data.get("data"), dict) else data
    live_room = _pick_live_room_node(nested if isinstance(nested, dict) else data)
    if live_room is None:
        live_room = nested if isinstance(nested, dict) else {}

    status = _first_int(data, ("status", "liveRoomStatus", "room_status", "live_status"))
    if status is None:
        status = _first_int(live_room, ("status", "live_status", "room_status", "liveRoomStatus"))
    is_live_flag = bool(live_room.get("isLive") or live_room.get("is_live")) if isinstance(live_room, dict) else False

    room_id = _stringify(
        _first(live_room, ("roomID", "room_id", "id_str", "id"))
        or _first(nested if isinstance(nested, dict) else {}, ("roomId", "room_id", "roomID"))
        or _first(data, ("roomId", "room_id"))
    )
    if room_id in {"0", "None", "null"}:
        room_id = ""

    live_by_status = status in LIVE_STATUS
    if (not live_by_status and not is_live_flag) or not room_id:
        return None
    if status in {1, 4}:
        return None

    unique_ids = extract_unique_ids(data)
    unique_id = next((u for u in unique_ids if usernames_match(username, u)), "")
    if unique_ids and not unique_id:
        return None
    if not unique_id:
        unique_id = username

    viewers = _extract_viewers(live_room if isinstance(live_room, dict) else {}, nested if isinstance(nested, dict) else {})
    title = str(_first(live_room, ("title", "room_title", "live_room_title")) or "")
    started = _first_int(live_room, ("start_time", "startTime", "create_time", "createTime")) or 0
    if started > 10_000_000_000:
        started = started // 1000
    return LiveRoom(
        username=username,
        unique_id=unique_id,
        room_id=room_id,
        viewers=max(0, viewers),
        title=title,
        live_url=f"https://www.tiktok.com/@{unique_id or username}/live",
        exact_match=usernames_match(username, unique_id),
        started_at=started,
        peak_viewers=max(0, viewers),
    )


def extract_hydration(html: str) -> Any | None:
    if not html:
        return None
    for pat in _HYDRATION:
        match = re.search(pat, html, re.DOTALL)
        if not match:
            continue
        raw = match.group(1).strip()
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            continue
    return None


def extract_treasure_box(payload: Any, room: LiveRoom) -> TreasureBox | None:
    boxes = extract_treasure_boxes(payload, room)
    if not boxes:
        return None
    return _best_box(boxes)


def extract_treasure_boxes(payload: Any, room: LiveRoom) -> list[TreasureBox]:
    found: list[TreasureBox] = []
    seen: set[str] = set()

    def consider(node: dict[str, Any]) -> None:
        if not is_active_split_box(node):
            return
        box = box_from_node(node, room)
        if box is None:
            return
        key = box.box_id or f"{box.kind}:{box.total_coins}:{box.total_slots}:{box.remain_sec}"
        if key in seen:
            return
        seen.add(key)
        found.append(box)

    def walk(node: Any, depth: int = 0) -> None:
        if node is None or depth > 10:
            return
        if isinstance(node, dict):
            keys = {str(k).lower() for k in node.keys()}
            if keys & _BOX_HINTS:
                for key, val in node.items():
                    if str(key).lower() in _BOX_HINTS:
                        if isinstance(val, dict):
                            consider(val)
                            walk(val, depth + 1)
                        elif isinstance(val, list):
                            for item in val:
                                if isinstance(item, dict):
                                    consider(item)
                                walk(item, depth + 1)
                consider(node)
            elif is_active_split_box(node):
                consider(node)
            for val in node.values():
                walk(val, depth + 1)
        elif isinstance(node, list):
            for item in node[:80]:
                walk(item, depth + 1)

    walk(payload)
    return found


def box_from_node(node: dict[str, Any], room: LiveRoom) -> TreasureBox | None:
    coins = _first_int(node, _COIN_KEYS) or 0
    slots = _first_int(node, _SLOT_KEYS) or 0
    if coins <= 0 or slots <= 0:
        return None
    parts = _first_int(node, _PART_KEYS) or 0
    box_id = str(_first(node, _ID_KEYS) or "")
    kind, label, conf, signals = classify_box_kind(node)
    remain = _remain_sec(node)
    sender = _sender(node)
    return TreasureBox(
        username=room.username,
        room_id=room.room_id,
        gift_type=label,
        kind=kind,
        confidence=conf,
        total_coins=coins,
        total_slots=slots,
        participants_count=min(parts, slots) if parts else parts,
        viewers_count=room.viewers,
        box_id=box_id,
        live_url=room.live_url,
        remain_sec=remain,
        unique_id=room.unique_id,
        sender=sender,
        title=room.title,
        peak_viewers=room.peak_viewers,
        signals=tuple(signals),
    )


def is_active_split_box(node: dict[str, Any]) -> bool:
    if not isinstance(node, dict):
        return False
    if _looks_gift_catalog(node):
        return False
    coins = _first_int(node, _COIN_KEYS)
    slots = _first_int(node, _SLOT_KEYS)
    if not coins or not slots or coins <= 0 or slots <= 0:
        return False
    keys = {str(k).lower() for k in node.keys()}
    has_id = any(k in keys for k in ("envelope_id", "envelop_id", "box_id", "treasure_id", "activity_id"))
    has_join = _first_int(node, _PART_KEYS) is not None
    has_time = any(k in keys for k in _REMAIN_KEYS)
    has_hint = bool(keys & _BOX_HINTS) or any(
        token in " ".join(keys) for token in ("envelope", "envelop", "treasure", "lucky", "chest", "box", "bag", "packet")
    )
    return bool(has_id or has_join or has_time or has_hint)


def _looks_gift_catalog(node: dict[str, Any]) -> bool:
    keys = {str(k).lower() for k in node.keys()}
    giftish = "gift_id" in keys or ("id" in keys and "image" in keys and "name" in keys)
    splitish = any(
        k in keys
        for k in (
            "people_count",
            "total_slots",
            "envelope_id",
            "box_id",
            "join_count",
            "joined_count",
        )
    )
    return giftish and not splitish


def _remain_sec(node: dict[str, Any]) -> int:
    val = _first(node, _REMAIN_KEYS)
    if val is None:
        return 0
    try:
        n = int(val)
    except (TypeError, ValueError):
        return 0
    now = int(time.time())
    if n > now + 5:
        return max(0, n - now)
    if n > 10_000_000_000:
        return max(0, n // 1000 - now)
    return max(0, n)


def _sender(node: dict[str, Any]) -> str:
    val = _first(node, _SENDER_KEYS)
    if isinstance(val, str) and val.strip() and not val.strip().isdigit():
        return val.strip()
    for key in ("send_user", "user", "sender"):
        user = node.get(key)
        if isinstance(user, dict):
            name = _first(user, ("unique_id", "uniqueId", "nickname", "display_id"))
            if isinstance(name, str) and name.strip():
                return name.strip()
    return ""


def _extract_viewers(live_room: dict[str, Any], nested: dict[str, Any]) -> int:
    n = _first_int(live_room, _VIEWER_KEYS)
    if n is not None:
        return n
    stats = live_room.get("liveRoomStats") if isinstance(live_room.get("liveRoomStats"), dict) else None
    if stats is None:
        stats = live_room.get("stats") if isinstance(live_room.get("stats"), dict) else None
    if isinstance(stats, dict):
        n = _first_int(stats, _VIEWER_KEYS)
        if n is not None:
            return n
        # enter_count / enterCount — ümumi giriş, cari nəfər DEYİL
    n = _first_int(nested, _VIEWER_KEYS)
    return n or 0


def _best_box(boxes: list[TreasureBox]) -> TreasureBox:
    def key(b: TreasureBox) -> tuple[int, float, int]:
        return (1 if b.remain_sec > 0 else 0, b.rate, b.total_coins)

    return max(boxes, key=key)


def _pick_live_room_node(nested: Any) -> dict[str, Any] | None:
    if not isinstance(nested, dict):
        return None
    for key in ("liveRoom", "live_room", "room", "liveRoomInfo", "roomInfo", "room_info"):
        val = nested.get(key)
        if isinstance(val, dict):
            return val
    return nested


def _first(node: dict[str, Any], keys: Iterable[str]) -> Any:
    lower = {str(k).lower(): v for k, v in node.items()}
    for key in keys:
        if key.lower() in lower:
            return lower[key.lower()]
    return None


def _first_int(node: Any, keys: Iterable[str]) -> int | None:
    if not isinstance(node, dict):
        return None
    return parse_count(_first(node, keys))


def _stringify(val: Any) -> str:
    if val is None:
        return ""
    return str(val).strip()
`,language:`python`},{name:`models.py`,zipPath:`sandiqradar-bot/models.py`,content:`"""SandıqRadar məlumat modelləri."""

from __future__ import annotations

from dataclasses import dataclass, field


BoxKind = str  # chest | gift_bag | envelope | portal | lucky | unknown


BOX_KIND_LABEL = {
    "chest": "Sandıq",
    "gift_bag": "Hədiyyə çantası",
    "envelope": "Zərf",
    "portal": "Portal sandıq",
    "lucky": "Şans qutusu",
    "unknown": "Bölünən qutu",
}


@dataclass(slots=True)
class LiveRoom:
    username: str
    unique_id: str
    room_id: str
    viewers: int
    title: str = ""
    live_url: str = ""
    exact_match: bool = True
    started_at: int = 0
    peak_viewers: int = 0

    def touch_viewers(self, n: int) -> None:
        self.viewers = max(0, n)
        if n > self.peak_viewers:
            self.peak_viewers = n


@dataclass(slots=True)
class TreasureBox:
    username: str
    room_id: str
    gift_type: str
    kind: str
    confidence: int
    total_coins: int
    total_slots: int
    participants_count: int
    viewers_count: int
    box_id: str = ""
    live_url: str = ""
    remain_sec: int = 0
    unique_id: str = ""
    sender: str = ""
    title: str = ""
    peak_viewers: int = 0
    signals: tuple[str, ...] = ()

    @property
    def rate(self) -> float:
        if self.total_slots <= 0:
            return 0.0
        return self.total_coins / float(self.total_slots)

    @property
    def split_label(self) -> str:
        return f"{self.total_coins}/{self.total_slots}"

    @property
    def dedup_key(self) -> str:
        if self.box_id:
            return f"{self.username}:{self.box_id}"
        return f"{self.username}:{self.kind}:{self.total_coins}:{self.total_slots}:{self.gift_type}"


@dataclass(slots=True)
class EngineStats:
    checks: int = 0
    live: int = 0
    boxes: int = 0
    alerts: int = 0
    mismatches: int = 0
    http_errors: int = 0
    blocked: int = 0
    cycle: int = 0
    last_error: str = ""
    extra: dict[str, int] = field(default_factory=dict)
`,language:`python`},{name:`checker.py`,zipPath:`sandiqradar-bot/checker.py`,content:`"""Yüksək dəqiqlikli asinxron tarama mühərriki + stealth."""

from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from collections.abc import Iterable
from typing import Any
from urllib.parse import urlencode

import aiohttp

from config import Config
from models import EngineStats, LiveRoom, TreasureBox
from parser import extract_hydration, extract_treasure_box, parse_live_room
from stealth import pick_profile, random_device_id, request_headers, web_params
from telegram import TelegramDispatcher

logger = logging.getLogger("sandiqradar.checker")


class ProxyRotator:
    def __init__(self, lines: Iterable[str]) -> None:
        self._proxies = [ln.strip() for ln in lines if ln.strip() and not ln.strip().startswith("#")]
        self._i = 0

    def next(self) -> str | None:
        if not self._proxies:
            return None
        proxy = self._proxies[self._i % len(self._proxies)]
        self._i += 1
        return proxy

    @property
    def count(self) -> int:
        return len(self._proxies)


class DuplicateGuard:
    def __init__(self, ttl_sec: float = 900.0) -> None:
        self._ttl = ttl_sec
        self._seen: dict[str, float] = {}

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        self._purge(now)
        if key in self._seen:
            return False
        self._seen[key] = now
        return True

    def forget_prefix(self, prefix: str) -> None:
        drop = [k for k in self._seen if k.startswith(prefix)]
        for k in drop:
            del self._seen[k]

    def _purge(self, now: float) -> None:
        expired = [k for k, ts in self._seen.items() if now - ts > self._ttl]
        for k in expired:
            del self._seen[k]


class MonitorEngine:
    def __init__(
        self,
        config: Config,
        usernames: list[str],
        telegram: TelegramDispatcher,
        proxies: ProxyRotator,
        session: aiohttp.ClientSession,
        reload_usernames=None,
    ) -> None:
        self.config = config
        self.usernames = usernames
        self.telegram = telegram
        self.proxies = proxies
        self.session = session
        self.reload_usernames = reload_usernames
        self.queue: asyncio.Queue[str] = asyncio.Queue()
        workers = config.max_concurrent
        if config.stealth and self.proxies.count == 0:
            workers = min(workers, 8)
        self.sem = asyncio.Semaphore(workers)
        self.dup = DuplicateGuard()
        self.running = False
        self.stats = EngineStats()
        self._live: dict[str, LiveRoom] = {}
        self._watchers: dict[str, asyncio.Task[None]] = {}
        self._profile = pick_profile()
        self._device_id = random_device_id()
        self._backoff_until = 0.0
        self._block_hits = 0

    def _headers(self, username: str, html: bool = False) -> dict[str, str]:
        if self.config.user_agent_rotate:
            self._profile = pick_profile()
        return request_headers(username, self._profile, html=html)

    async def warmup(self) -> None:
        if not self.config.warmup_cookies:
            return
        try:
            timeout = aiohttp.ClientTimeout(total=self.config.request_timeout)
            async with self.session.get(
                "https://www.tiktok.com/",
                headers=self._headers("tiktok", html=True),
                proxy=self.proxies.next(),
                timeout=timeout,
            ) as resp:
                await resp.read()
                logger.info("Cookie warmup: HTTP %s profile=%s", resp.status, self._profile.platform)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Cookie warmup uğursuz: %s", exc)

    async def run(self) -> None:
        self.running = True
        await self.warmup()
        logger.info(
            "Mühərrik start: %s istifadəçi, %s paralel, %s proxy, stealth=%s, strict=%s",
            len(self.usernames),
            self.config.max_concurrent,
            self.proxies.count,
            self.config.stealth,
            self.config.strict_identity,
        )
        n_workers = self.sem._value  # noqa: SLF001
        workers = [asyncio.create_task(self._worker(f"w{i}")) for i in range(max(1, n_workers))]
        feeder = asyncio.create_task(self._feeder())
        reaper = asyncio.create_task(self._reap_watchers())
        reporter = asyncio.create_task(self._reporter())
        warmer = asyncio.create_task(self._rewarm())
        try:
            await asyncio.gather(feeder, reaper, reporter, warmer, *workers)
        finally:
            self.running = False
            for task in workers + [feeder, reaper, reporter, warmer]:
                task.cancel()
            for task in list(self._watchers.values()):
                task.cancel()

    async def stop(self) -> None:
        self.running = False

    async def _rewarm(self) -> None:
        while self.running:
            await asyncio.sleep(240)
            self._profile = pick_profile()
            self._device_id = random_device_id()
            await self.warmup()

    async def _feeder(self) -> None:
        while self.running:
            if self.stats.cycle > 0 and self.stats.cycle % max(1, self.config.reload_every) == 0:
                if self.reload_usernames:
                    fresh = self.reload_usernames()
                    if fresh:
                        self.usernames = fresh
                        logger.info("Siyahı yeniləndi: %s istifadəçi", len(fresh))
            self.stats.cycle += 1
            for name in list(self.usernames):
                if not self.running:
                    break
                await self.queue.put(name)
            jitter = random.uniform(0.0, self.config.jitter_sec)
            sleep_for = self.config.check_interval + jitter
            if time.monotonic() < self._backoff_until:
                sleep_for = max(sleep_for, self._backoff_until - time.monotonic())
            await asyncio.sleep(sleep_for)

    async def _reporter(self) -> None:
        while self.running:
            await asyncio.sleep(20)
            logger.info(
                "stat: yoxlama=%s canlı=%s qutu=%s xəbərdarlıq=%s uyğunsuz=%s http=%s blok=%s",
                self.stats.checks,
                len(self._live),
                self.stats.boxes,
                self.stats.alerts,
                self.stats.mismatches,
                self.stats.http_errors,
                self.stats.blocked,
            )

    async def _worker(self, label: str) -> None:
        while self.running:
            username = await self.queue.get()
            try:
                async with self.sem:
                    if self.config.stealth:
                        await asyncio.sleep(random.uniform(0.05, 0.35))
                    await self._process(username)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.stats.http_errors += 1
                self.stats.last_error = str(exc)
                logger.debug("[%s] @%s xəta: %s", label, username, exc)
            finally:
                self.queue.task_done()

    async def _process(self, username: str) -> None:
        self.stats.checks += 1
        room = await self._fetch_live(username)
        if room is None:
            self._live.pop(username, None)
            task = self._watchers.pop(username, None)
            if task:
                task.cancel()
            return
        if self.config.strict_identity and not room.exact_match:
            self.stats.mismatches += 1
            logger.info("Dəqiq uyğunluq yoxdur, atılır: istənilən=@%s tapılan=@%s", username, room.unique_id)
            return
        prev = self._live.get(username)
        if prev:
            room.peak_viewers = max(prev.peak_viewers, room.viewers)
        self._live[username] = room
        self.stats.live = len(self._live)
        if username not in self._watchers:
            if len(self._watchers) >= self.config.max_ws_listeners:
                box = await self._inspect_chest(room)
                await self._maybe_alert(box)
                return
            self._watchers[username] = asyncio.create_task(self._watch_room(room))

    async def _watch_room(self, room: LiveRoom) -> None:
        username = room.username
        logger.info(
            "Canlı izləmə: @%s room=%s nəfər=%s başlıq=%s",
            room.unique_id or username,
            room.room_id,
            room.viewers,
            room.title or "-",
        )
        try:
            used_ws = await self._watch_tiktoklive(room)
            if used_ws:
                return
            while self.running and username in self._live:
                current = self._live.get(username, room)
                box = await self._inspect_chest(current)
                await self._maybe_alert(box)
                await asyncio.sleep(self.config.chest_poll_interval)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            logger.debug("@%s izləmə xətası: %s", username, exc)
        finally:
            self._watchers.pop(username, None)
            logger.info("Canlı izləmə bitdi: @%s", username)

    async def _reap_watchers(self) -> None:
        while self.running:
            await asyncio.sleep(5)
            live_names = set(self._live)
            for name, task in list(self._watchers.items()):
                if name not in live_names or task.done():
                    if not task.done():
                        task.cancel()
                    self._watchers.pop(name, None)

    async def _maybe_alert(self, box: TreasureBox | None) -> None:
        if box is None:
            return
        if box.rate < self.config.min_rate:
            return
        if box.viewers_count < self.config.min_viewers:
            return
        if box.total_coins < self.config.min_coins:
            return
        if not self.dup.allow(box.dedup_key):
            return
        self.stats.boxes += 1
        self.stats.alerts += 1
        logger.info(
            "QUTU: @%s növ=%s rate=%.2f nəfər=%s qoşulan=%s/%s id=%s etibar=%s",
            box.unique_id or box.username,
            box.gift_type,
            box.rate,
            box.viewers_count,
            box.participants_count,
            box.total_slots,
            box.box_id or "-",
            box.confidence,
        )
        ok = await self.telegram.send_box(box)
        if not ok:
            logger.warning("Telegram göndərilmədi: @%s", box.username)

    async def _fetch_live(self, username: str) -> LiveRoom | None:
        factories = [self._live_api_room, self._live_webcast_by_user, self._live_mobile]
        random.shuffle(factories)
        factories.append(self._live_html)
        for factory in factories:
            try:
                room = await factory(username)
                if room is not None:
                    return room
            except BlockedError:
                self._note_block()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                logger.debug("@%s %s uğursuz: %s", username, factory.__name__, exc)
        return None

    def _note_block(self) -> None:
        self._block_hits += 1
        self.stats.blocked += 1
        delay = min(90.0, 2.0 * (2 ** min(self._block_hits, 5)))
        self._backoff_until = max(self._backoff_until, time.monotonic() + delay)
        self._profile = pick_profile()
        self._device_id = random_device_id()
        if self._block_hits in {1, 5, 15, 40}:
            logger.warning("TikTok blok/429 — %.0fs yavaşlama (hit=%s)", delay, self._block_hits)

    async def _get_json(self, url: str, username: str) -> Any:
        proxy = self.proxies.next()
        timeout = aiohttp.ClientTimeout(total=self.config.request_timeout)
        async with self.session.get(
            url,
            headers=self._headers(username),
            proxy=proxy,
            timeout=timeout,
            allow_redirects=True,
        ) as resp:
            if resp.status in {403, 429, 503}:
                raise BlockedError(f"HTTP {resp.status}")
            if resp.status >= 400:
                raise RuntimeError(f"HTTP {resp.status}")
            ctype = resp.headers.get("Content-Type", "")
            if "json" in ctype:
                return await resp.json(content_type=None)
            text = await resp.text()
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return {"_html": text}

    async def _live_api_room(self, username: str) -> LiveRoom | None:
        params = web_params(self._profile, {"uniqueId": username, "sourceType": "54"})
        url = "https://www.tiktok.com/api-live/user/room/?" + urlencode(params)
        data = await self._get_json(url, username)
        return parse_live_room(username, data)

    async def _live_webcast_by_user(self, username: str) -> LiveRoom | None:
        url = (
            "https://webcast.tiktok.com/webcast/room/info_by_user/"
            f"?aid=1988&unique_id={username}&device_id={self._device_id}"
        )
        data = await self._get_json(url, username)
        return parse_live_room(username, data)

    async def _live_mobile(self, username: str) -> LiveRoom | None:
        url = f"https://m.tiktok.com/api-live/user/room/?aid=1988&sourceType=54&uniqueId={username}"
        data = await self._get_json(url, username)
        return parse_live_room(username, data)

    async def _live_html(self, username: str) -> LiveRoom | None:
        url = f"https://www.tiktok.com/@{username}/live"
        proxy = self.proxies.next()
        timeout = aiohttp.ClientTimeout(total=self.config.request_timeout)
        async with self.session.get(
            url, headers=self._headers(username, html=True), proxy=proxy, timeout=timeout
        ) as resp:
            if resp.status in {403, 429, 503}:
                raise BlockedError(f"HTTP {resp.status}")
            html = await resp.text()
        blob = extract_hydration(html)
        if blob is None:
            return None
        return parse_live_room(username, blob)

    async def _inspect_chest(self, room: LiveRoom) -> TreasureBox | None:
        urls = [
            f"https://webcast.tiktok.com/webcast/room/info/?aid=1988&room_id={room.room_id}&device_id={self._device_id}",
            f"https://webcast.tiktok.com/webcast/room/enter/?aid=1988&room_id={room.room_id}",
            f"https://webcast.tiktok.com/webcast/envelope/list/?aid=1988&room_id={room.room_id}",
        ]
        for url in urls:
            try:
                data = await self._get_json(url, room.username)
            except BlockedError:
                self._note_block()
                continue
            except Exception as exc:  # noqa: BLE001
                logger.debug("otaq info @%s: %s", room.username, exc)
                continue
            box = extract_treasure_box(data, room)
            if box:
                return box
        return None

    async def _watch_tiktoklive(self, room: LiveRoom) -> bool:
        try:
            from TikTokLive import TikTokLiveClient  # type: ignore
            from TikTokLive.events import DisconnectEvent, GiftEvent, LiveEndEvent  # type: ignore
        except Exception:
            return False

        envelope_cls = None
        try:
            from TikTokLive.events import EnvelopeEvent  # type: ignore

            envelope_cls = EnvelopeEvent
        except Exception:
            envelope_cls = None

        client = TikTokLiveClient(unique_id=room.unique_id or room.username)
        done = asyncio.Event()

        @client.on(GiftEvent)
        async def _on_gift(event: Any) -> None:  # noqa: ANN401
            gift = getattr(event, "gift", None)
            name = str(getattr(gift, "name", "") or "")
            lowered = name.lower()
            if not any(
                k in lowered
                for k in ("box", "chest", "treasure", "bag", "sandıq", "sandiq", "çanta", "envelope", "lucky")
            ):
                return
            http_box = await self._inspect_chest(self._live.get(room.username, room))
            if http_box:
                await self._maybe_alert(http_box)

        if envelope_cls is not None:

            @client.on(envelope_cls)
            async def _on_env(event: Any) -> None:  # noqa: ANN401
                info = (
                    getattr(event, "envelope_info", None)
                    or getattr(event, "info", None)
                    or getattr(event, "envelop_info", None)
                    or {}
                )
                node = info if isinstance(info, dict) else _obj_to_dict(info)
                http_box = await self._inspect_chest(self._live.get(room.username, room))
                if http_box:
                    await self._maybe_alert(http_box)
                    return
                if not isinstance(node, dict):
                    return
                box = extract_treasure_box({"envelope_info": node}, self._live.get(room.username, room))
                await self._maybe_alert(box)

        @client.on(DisconnectEvent)
        async def _on_disc(_: Any) -> None:  # noqa: ANN401
            done.set()

        @client.on(LiveEndEvent)
        async def _on_end(_: Any) -> None:  # noqa: ANN401
            done.set()

        try:
            await client.start()
            while self.running and room.username in self._live and not done.is_set():
                http_box = await self._inspect_chest(self._live.get(room.username, room))
                await self._maybe_alert(http_box)
                try:
                    await asyncio.wait_for(done.wait(), timeout=self.config.chest_poll_interval)
                except asyncio.TimeoutError:
                    pass
        finally:
            try:
                await client.disconnect()
            except Exception:
                pass
        return True


class BlockedError(RuntimeError):
    pass


def _obj_to_dict(obj: Any) -> dict[str, Any]:
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    data: dict[str, Any] = {}
    for key in dir(obj):
        if key.startswith("_"):
            continue
        try:
            val = getattr(obj, key)
        except Exception:
            continue
        if callable(val):
            continue
        data[key] = val
    return data
`,language:`python`},{name:`telegram.py`,zipPath:`sandiqradar-bot/telegram.py`,content:`"""Asinxron Telegram xəbərdarlıq göndəricisi."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import aiohttp

from config import Config
from models import TreasureBox

logger = logging.getLogger("sandiqradar.telegram")

TELEGRAM_API = "https://api.telegram.org"


def _md(text: str) -> str:
    return (
        str(text)
        .replace("\\\\", "\\\\\\\\")
        .replace("_", "\\\\_")
        .replace("*", "\\\\*")
        .replace("\`", "\\\\\`")
        .replace("[", "\\\\[")
    )


def _fmt_num(n: int) -> str:
    return f"{int(n):,}".replace(",", " ")


def format_alert(box: TreasureBox) -> str:
    rate = box.rate
    rate_label = str(int(rate)) if rate == int(rate) else f"{rate:.2f}"
    handle = box.unique_id or box.username
    url = box.live_url or f"https://www.tiktok.com/@{handle}/live"
    remain = f"\\n⏱ **Qalan vaxt:** {box.remain_sec} san" if box.remain_sec > 0 else ""
    title = f"\\n📺 **Yayım:** {_md(box.title)}" if box.title else ""
    sender = f"\\n✍️ **Göndərən:** @{_md(box.sender)}" if box.sender else ""
    conf = f"\\n🎯 **Növ etibarı:** {box.confidence}%" if box.confidence else ""
    peak = ""
    if box.peak_viewers and box.peak_viewers > box.viewers_count:
        peak = f" (peak {_fmt_num(box.peak_viewers)})"
    return (
        "🚨 **CANLI VƏ QUTU TAPILDI!** 🚨\\n"
        "\\n"
        f"👤 **İstifadəçi:** @{_md(handle)}\\n"
        f"🎁 **Növ:** {_md(box.gift_type)}\\n"
        f"👀 **Canlıda nəfər:** {_fmt_num(box.viewers_count)}{peak}\\n"
        f"📊 **Bölgü:** {box.total_coins}/{box.total_slots} jeton/yer\\n"
        f"💎 **Rate:** {rate_label} jeton/nəfər\\n"
        f"👥 **Qutuya qoşulan:** {_fmt_num(box.participants_count)} / {_fmt_num(box.total_slots)} nəfər"
        f"{title}{sender}{remain}{conf}\\n"
        f"🔗 **Canlı yayım:** [Yayıma Keç]({url})"
    )


class TelegramDispatcher:
    def __init__(self, config: Config, session: aiohttp.ClientSession) -> None:
        self._config = config
        self._session = session
        self._lock = asyncio.Lock()

    async def test_connection(self) -> bool:
        url = f"{TELEGRAM_API}/bot{self._config.telegram_bot_token}/getMe"
        try:
            async with self._session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                payload: dict[str, Any] = await resp.json(content_type=None)
                if payload.get("ok"):
                    username = payload.get("result", {}).get("username", "?")
                    logger.info("Telegram botu hazırdır: @%s", username)
                    return True
                logger.error("Telegram getMe uğursuz: %s", payload)
                return False
        except Exception as exc:  # noqa: BLE001
            logger.error("Telegram bağlantı xətası: %s", exc)
            return False

    async def send_box(self, box: TreasureBox) -> bool:
        if self._config.dry_run:
            logger.info("[DRY-RUN] Qutu: @%s növ=%s rate=%.2f", box.username, box.gift_type, box.rate)
            return True
        return await self.send_text(format_alert(box))

    async def send_text(self, text: str) -> bool:
        url = f"{TELEGRAM_API}/bot{self._config.telegram_bot_token}/sendMessage"
        body = {
            "chat_id": self._config.telegram_chat_id,
            "text": text,
            "parse_mode": "Markdown",
            "disable_web_page_preview": False,
        }
        async with self._lock:
            delay = 0.05
            for attempt in range(1, 4):
                try:
                    async with self._session.post(
                        url,
                        json=body,
                        timeout=aiohttp.ClientTimeout(total=12),
                    ) as resp:
                        payload: dict[str, Any] = await resp.json(content_type=None)
                        if payload.get("ok"):
                            return True
                        if resp.status == 429:
                            retry_after = float(payload.get("parameters", {}).get("retry_after", 2))
                            logger.warning("Telegram 429 — %.1fs gözlənilir", retry_after)
                            await asyncio.sleep(retry_after)
                            continue
                        logger.error("Telegram xətası: %s", payload.get("description"))
                        return False
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Telegram cəhd %s uğursuz: %s", attempt, exc)
                    await asyncio.sleep(delay)
                    delay *= 2
        return False
`,language:`python`},{name:`main.py`,zipPath:`sandiqradar-bot/main.py`,content:`"""SandıqRadar — giriş nöqtəsi."""

from __future__ import annotations

import asyncio
import logging
import signal
import sys
from pathlib import Path

import aiohttp

from checker import MonitorEngine, ProxyRotator
from config import Config
from identity import normalize_username
from telegram import TelegramDispatcher

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("sandiqradar")


def load_lines(path: Path) -> list[str]:
    if not path.exists():
        return []
    names: list[str] = []
    seen: set[str] = set()
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        item = line.lstrip("@").split()[0].strip()
        key = normalize_username(item)
        if key and key not in seen:
            seen.add(key)
            names.append(item)
    return names


async def amain() -> int:
    try:
        config = Config.load()
    except RuntimeError as exc:
        logger.error("%s", exc)
        return 2

    def reload_names() -> list[str]:
        return load_lines(config.usernames_file)

    usernames = reload_names()
    if len(usernames) < 1:
        logger.error(
            "İstifadəçi siyahısı boşdur. %s faylına hər sətirdə bir dəqiq username yazın.",
            config.usernames_file,
        )
        return 2

    proxies = ProxyRotator(load_lines(config.proxies_file) if config.proxies_file.exists() else [])
    timeout = aiohttp.ClientTimeout(total=config.request_timeout)
    jar = aiohttp.CookieJar(unsafe=True)
    connector = aiohttp.TCPConnector(
        limit=max(32, config.max_concurrent * 2),
        ttl_dns_cache=300,
        enable_cleanup_closed=True,
        ssl=True,
    )

    logger.info(
        "Hazırlıq: %s dəqiq kanal, interval=%.1fs, paralel=%s, stealth=%s, min_rate=%.2f",
        len(usernames),
        config.check_interval,
        config.max_concurrent,
        config.stealth,
        config.min_rate,
    )

    async with aiohttp.ClientSession(timeout=timeout, connector=connector, cookie_jar=jar) as session:
        telegram = TelegramDispatcher(config, session)
        if not await telegram.test_connection():
            logger.error("Telegram botu cavab vermir — token/chat_id yoxlanılsın.")
            return 3
        engine = MonitorEngine(
            config,
            usernames,
            telegram,
            proxies,
            session,
            reload_usernames=reload_names,
        )

        loop = asyncio.get_running_loop()
        stop_event = asyncio.Event()

        def _ask_stop() -> None:
            logger.info("Dayandırma siqnalı alındı…")
            engine.running = False
            stop_event.set()

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, _ask_stop)
            except NotImplementedError:
                pass

        runner = asyncio.create_task(engine.run())
        waiter = asyncio.create_task(stop_event.wait())
        done, pending = await asyncio.wait({runner, waiter}, return_when=asyncio.FIRST_COMPLETED)
        engine.running = False
        for task in pending:
            task.cancel()
        if runner in done:
            exc = runner.exception()
            if exc:
                logger.exception("Mühərrik xətası: %s", exc)
                return 1
    logger.info("SandıqRadar dayandı.")
    return 0


def main() -> None:
    try:
        code = asyncio.run(amain())
    except KeyboardInterrupt:
        code = 0
    sys.exit(code)


if __name__ == "__main__":
    main()
`,language:`python`},{name:`requirements.txt`,zipPath:`sandiqradar-bot/requirements.txt`,content:`aiohttp>=3.9.1
aiohttp-socks>=0.9.0
python-dotenv>=1.0.1
orjson>=3.10.0
# İxtiyari — WebSocket sandıq dinləməsi üçün:
# TikTokLive>=6.4.0
`,language:`text`},{name:`.env.example`,zipPath:`sandiqradar-bot/.env.example`,content:`TELEGRAM_BOT_TOKEN=123456789:AA-your-bot-token
TELEGRAM_CHAT_ID=-1001234567890
STEALTH=true
CHECK_INTERVAL=8
CHEST_POLL_INTERVAL=2.5
MAX_CONCURRENT=8
MAX_WS_LISTENERS=16
REQUEST_TIMEOUT=10
MIN_RATE=1
MIN_VIEWERS=0
MIN_COINS=0
JITTER_SEC=1.8
USER_AGENT_ROTATE=true
DRY_RUN=false
STRICT_IDENTITY=true
RELOAD_EVERY=8
WARMUP_COOKIES=true
USERNAMES_FILE=usernames.txt
PROXIES_FILE=proxies.txt
`,language:`text`},{name:`usernames.txt`,zipPath:`sandiqradar-bot/usernames.txt`,content:`# Həqiqi izləmə siyahısı — hər sətirdə bir dəqiq TikTok unique_id.
# @ işarəsi olsa da olar. Böyük/kiçik hərf fərqi yoxdur, durğu eynidir.
w777789
incirteroristiayan
jungminjaeda
versace76_
aldim_ve_getdim
shunshun1130
lun_shao
algorithmtechschool
zevs_show
youssef.iioq0
tyt_mixa_tyta
andreaprisco.22
keremuner
elsevervusal
sawyerthomson0
tjr_tradez
itslucasgracia
ddine_sz
tn_20606
mrsfazlieva
claudiasonson5
berdeavto100yedek
mulletmafia747
tekiso0929
rehim163
cindysiclaudia
adda88a
dragonduu124
tasbsjsk2
user4532882334
fantasy4lifemain
ksummm888
berdosik5757
oz.92k
2tthang
eugeniaup
blue_blue2911
aras_0791gmail
petch_itthi
araki_muscle
tumz0202
bahri813
35___54
chinami118
ninaketaren
ponpokorin311
kazutan1116
luz.deyling.flores
ipelex1
almor3eba
skorpik3456899
leoalcy
chaaithuong
baiibaifernfern
inuinuinuvu
rodrigo_ganem
aot_suta
sion..0502
188168yy
aylie505
quianna.nana
sakura37.m
useryurino_0111
momiji..ll
yusqa.97
y_w_o_o
l_ibra85
prannn
shnookie_x
sapa.caryyew1
rupia_zard
meronchan19
miiiiiin06
thinasuke
laudyismail888
kizunatti111
azizulhelm1
junt120
nazym_sw_
ceys.34
90d9g
colestytan
actor_2kang
runrun652
mandiecane_
banadokunma96
myunx_o0
taryel9.9.9
kay7xisking
ogdvbhf
user3413536268610
dygw2p6cm831
nanashiki_ry1
vitormagalh_
fegermadid32j4zo
user1396166918477
stayblessmusic
allahqorusun099
weare.vixen_
ya096i1
rinrinrin03040
lsywa1
mummaof6girls2boys
dyih0wd8ibmh
zen___j
saikonausagichan
kuro_969698
linxi1114888
iam.kath0
vvchamavv
aunny_anchali
edoss580
yujiho7778
taroutoki701
s_gg019
d819697
sena344646
dachanuda
dothanhbinh2512
h.dieu_ancut
davidnachtham
misa__3311
dydnlmk1vlr4
duy.c3620
nhatkhang12341
foreverloveyourself4
xin_nhe_cai_top36
luctrungquan4
luonghung.04
hind.x1992
ateliedalolaibitinga
jaoaornurse
dong__gi
in26222595
danielhunt88
mopkil
i3rara
o5__yya
beppu_chan
ashleyp890
hono.1225
horuslives
marinka14023
ninikang2
userdaidaidaidayo
hongyeu371
thin1211s
88_gayush_88
sasha13.1
obirmardinli_47_
anhtiktokdepzaittacckhoe
tqd305
shisha44free
xinyu_316
liliana.591
sparkie.boy04
v.hxy_0227
batea84
hazuki.sumile
chywv5
javidd26
popeye_5268
1__7__m
u.uura
marumaru6710
investidor_007
k7__7
armine.dawtyan
tduongg1908
mayu_129_manapanda
takutok25
ya.02
n.a.r.e22.22
itzarhneetar
faynyy.pan
dek7miopd
jiiko03270
froggysparklesmain1
budbudsabong797
doss_251
youngju2
zhizhi0117
user2323563367
liveeveryday.np
boz_qurt37
fan.fan378
username1114556
acimasiz02636229
hrrem.sultan3151
7nihadd
geldim.vurdum.01
yap10_geri_qayitdi
shtormichik
vaqodu_0001
ahhmantapp_crott
redbullaz
zver_on
ekberows_her_yerde1
ramiz_real
fmva9
posta.com.tr
heyvan_dunyasi12
skuter_samokat
nizami1022
01anaf01
wolt_azerbaijan
e6srider
n1toys0
mehhmetdragos
amchefdemisto
jooe907
danielstefu10
nm_livepro
queenmalik829
mr.barberuslan
officialmoustafamansour
global1joe
thom_babyy
anul__01
lomii733
tonystark060489
eltorquee
longxucxich.tuongot
h_kyung_176
lady.546
abusaif7070
aziz1990m1
edelinmathernature
rlkjota717
crvglopes98
madz_l24
maa.0510
geycikhaleesi
caiquizadaa
luizx7
zezev99
nuriiyev11
theusjosee
viniproducoesmusicais
hugorodelomusica
daa_on
bubbles0042
ricopin828
calm_lake223
jjangbbae
arin_960520
n..n789
azzamusicofficial
aisha.10tn
tannarll
bb_bbb_ultimate
adrianilies606
music_journey_01
sasticateaud
finc.mafia
mcjehda6_
ricxrdo.04
iishaaa_______
vit.r___
sokun0703
harbisari
neno..2727
mrsaitamavk2
joowon2103
richtzu888
ludere_deorum
ozune_hormet_qoy
gaarlic0921
kitty.na2
ryuji5_9
leoopostal
phil102545
ice3330120
itsme.chads
aussieveteran90
brunasaltorio
yuki_vrcats
kai_da75
supermum8_tt
donald_duck.1934.6.9
maurogmerican
qamarl07
iulianamatei86
tanesiinci
tullo.ostilio.82
chrixxxferr
bee9191
marvin_parcutilovibes
theodoresikiri
jussyercarvalho
skgotcha
minhhieudepzaicogisai
qaraqiz_1111
ahmed_optimist
m.martinez0417
osmantu079
hoanthien2608
cakaufa_magelang
ahmadsan33
almajhool201
al1000l00
raflesia074
cristina.23677
alessia_nare
dana_mvp
marochinoomochi
chronos_luka
bismillahkunfayakun23
dilaracimss
asem.dwairi
ksiyytw
starim.0
goktugkaynarr
k965h
nixon.3a21
anukunwar6
marino1220
vi_ew55
heyyimvv
belimeatimieludepasti
animal.hisaashii
al9saqr
bastichillma_official
hasank55
camilacorsinooo
luccas.valentine
microp_
mrdubaitop1
sevgimsen111_
midaswellquit
ilovetoptop93
aainn_621
mu_mu_mumumu
starbuc37
kaurato3
89shota89
maaami124
klauslove
shotaccc
.qara_010
zerosei_06
machiko.sensei
dr.account.xxx
soltan.usa
lookoutsnipe
cihan.ahnas4
nermanov_313
5mooii
ml212
dunghelthy8
hardcorrider01
viroza_1
nosinger487
litoriacaerulea
user377945497
star_universe_ever
ormankrallarii
courtneyfok
nodypc
daniel_wiwatwong
mijoo_lovely
bordobrli47
katsudonchan1
thachkieu10.02
user_edit6660
toshi_0042
emi_ocagi
mostfamahmod11
nasa_nebunilor
henz_construction
ninelli09
dekdiyah1
gabbycarina
hurdaci01.34
therebel937
dianamihali0
danielkrusee
zusminero
abbasalbloushivip
925ayar
brutall_2.0
mialily.jp
neoesram
chipomiru
zegkhv2030
indry_yuhuuu
vuong36au_2
aure_lian22222
erenn8690
userodukh76aec
cristinacristina664
user_13.alb_pe_negru
elnur___071
memmedova_roya_
raskon..m
user79014385
mehmetcengizank1
zorilaionpaul
agalokbatanlimahnilar
muhammed_glmsr34
brunetykaa
..ddelviago
ahmed_ali1_4
1dazel
maskelihatun49
candanote4142
gal_x77
w65m
alia_btp19
krieim34
endjulia_
son33.4
loaysokker
chinho.tm
a.e..001
eliyev0555
omarelnawawy96
ay_nuray_045
emilaghyv
ferahimkarimxanli
elen.111_
by_kamran_
m7md.tv
ko..056
hadi.hr1
devrim_47
mrmoldovan
psiholog.antonia
lafrandjaxerie
rzayevbehruz048
karadayi78
bomiiibomiii1
hangi_ferit
malak1a62
bodaaa5atar
pablokiss24
viroza_00
andorre01
atakishiev_97
sngabo6
ayxangeldi.44
hab.123h.3
memmedov8273
mr_lequar_aldima
ddo__xi1
kotobuki.twk
closednaw
natan0326nn210
muammerabrahams74
soli_moli888
jhonnathanmerchan
lelinho255
silasoil
lachocolatebiencuidada
mhamedahmdd
kemo___313
annefloor10
cj7.502
vankhanhkdzz
marrenta973
boopbianx
jandersonluis07
mizberesford007
jayvionthefront
nwa_milk05
soyelmicko
thescyyx
gaucho.do.tik.tok
rosariopsq
wwa5.23
morningstar_rj
nurllahy
a.zanza0
anadodo884
nehir_3434nn
papipopu____
alshaahin03
p.pimmo236
sadecekubos
hiatus.duluu
welorax._
ellaaeyo
samicadenaa
dragon_king_1989
3amo.samy.king0fgame
am_an206
dselinkose
.szandika
djandik8
yayinciogretmen1
live.streaming.se
goodybagtreasurebox
sultanofcoin
tambahfollowers.live
coinkrewe
takipyayini0000
tangkapfollowers.live
supportfollowerslive
growup.followers
coin.10.0004
coin10.0001
upfollowersaffiliatefyp
tangkap.mining.followers
romantik.haydut
italia__10
ahmadbakr7354
wepstore_567
theking_moha
vv9i
.yeraz_111
.mm...56
farid444
topdanoyuncaq.absheron
728.m
ikrxllw
lika_lik123
niko__654
boss_30
obeliks___
rusiya0117
aha.budefe.apardim_1
oanhkieule818
qaqas_5551
agacanbakii
rick_grimes66
shatoburian_sato
`,language:`text`},{name:`proxies.txt`,zipPath:`sandiqradar-bot/proxies.txt`,content:`# Hər sətirdə bir proxy. Boş qala bilər — o halda birbaşa çıxış.
# Nümunə:
# http://user:pass@1.2.3.4:8080
# socks5://1.2.3.4:1080
`,language:`text`},{name:`README.md`,zipPath:`sandiqradar-bot/README.md`,content:`# SandıqRadar — dəqiq canlı sandıq / hədiyyə çantası botu

Həqiqi TikTok unique_id siyahısını rəsmi API-siz tarayan mühərrik.
Yalnız **dəqiq eyni istifadəçi adı** canlıdırsa və aktiv **sandıq** və ya
**hədiyyə çantası** varsa Telegram-a Azərbaycan dilində xəbərdarlıq göndərir.

## Dəqiqlik

- \`uniqueId\` eyni olmalıdır (\`ramiz_real1\` keçmir).
- Yalnız \`status=2\` canlıdır.
- Növ: \`business_type=1\` → **Sandıq**, \`business_type=2\` → **Hədiyyə çantası**.
- Canlıdakı nəfər = cari \`user_count\` (enter_count ümumi girişdir, götürülmür).
- Duplicate: eyni \`box_id\` bir dəfə.
- Rate = jeton / yer.

## Anti-blok (STEALTH=true)

- Cookie warmup (\`ttwid\` sessiyası)
- UA + Client Hints rotasiyası
- Təsadüfi \`device_id\`
- 403/429-da eksponensial backoff
- Proxy yoxdursa paralel worker 8-ə enir
- Residential proxy (\`proxies.txt\`) tövsiyə olunur — datacenter IP kəsilir

## Qurulum

\`\`\`bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
\`\`\`

\`.env\` içində token və chat ID doldurun. İstəyə görə: \`pip install TikTokLive\`

\`\`\`bash
python main.py
python test_parser.py
\`\`\`

Dayandırmaq: \`Ctrl+C\`.
`,language:`markdown`}];function wi(e){let t=4294967295;for(let n=0;n<e.length;n+=1){t^=e[n]??0;for(let e=0;e<8;e+=1)t=t>>>1^(t&1?3988292384:0)}return t^4294967295}function Q(e){let t=new Uint8Array(2);return new DataView(t.buffer).setUint16(0,e,!0),t}function $(e){let t=new Uint8Array(4);return new DataView(t.buffer).setUint32(0,e,!0),t}function Ti(e){let t=e.reduce((e,t)=>e+t.length,0),n=new Uint8Array(t),r=0;for(let t of e)n.set(t,r),r+=t.length;return n}function Ei(e){let t=new TextEncoder,n=[],r=[],i=0;for(let a of e){let e=t.encode(a.name),o=t.encode(a.content),s=wi(o),c=Ti([$(67324752),Q(20),Q(0),Q(0),Q(0),Q(0),$(s),$(o.length),$(o.length),Q(e.length),Q(0),e,o]),l=Ti([$(33639248),Q(20),Q(20),Q(0),Q(0),Q(0),Q(0),$(s),$(o.length),$(o.length),Q(e.length),Q(0),Q(0),Q(0),Q(0),$(0),$(i),e]);n.push(c),r.push(l),i+=c.length}let a=Ti(r),o=Ti([$(101010256),Q(0),Q(0),Q(e.length),Q(e.length),$(a.length),$(i),Q(0)]),s=Ti([...n,a,o]),c=new ArrayBuffer(s.byteLength);return new Uint8Array(c).set(s),new Blob([c],{type:`application/zip`})}function Di(e,t){let n=URL.createObjectURL(e),r=document.createElement(`a`);r.href=n,r.download=t,r.click(),URL.revokeObjectURL(n)}function Oi(){let[e,t]=(0,O.useState)(Ci[0]?.name??`config.py`),[n,r]=(0,O.useState)(!1),i=(0,O.useMemo)(()=>Ci.find(t=>t.name===e)??Ci[0],[e]);function a(){Di(Ei(Ci.map(e=>({name:e.zipPath,content:e.content}))),`sandiqradar-bot.zip`),I.success(`Python paketi yükləndi`)}async function o(){i&&(await navigator.clipboard.writeText(i.content),r(!0),window.setTimeout(()=>r(!1),1400))}return(0,Y.jsxs)(`div`,{className:`flex flex-col gap-4`,children:[(0,Y.jsxs)(`div`,{className:`flex flex-wrap items-end justify-between gap-3`,children:[(0,Y.jsxs)(`div`,{children:[(0,Y.jsx)(`p`,{className:`text-xs font-medium tracking-wide text-muted uppercase`,children:`Python mühərriki`}),(0,Y.jsx)(`h2`,{className:`mt-1 text-xl font-semibold`,children:`Tam mənbə kodu`}),(0,Y.jsx)(`p`,{className:`mt-2 max-w-2xl text-sm text-muted`,children:"Stealth cookie, UA rotasiyası, dəqiq unique_id, status=2, sandıq vs hədiyyə çantası təsnifatı, cari nəfər sayı və Telegram. Öz VPS-də `python main.py`."})]}),(0,Y.jsxs)(X,{onClick:a,children:[(0,Y.jsx)(v,{className:`size-4`}),`ZIP yüklə`]})]}),(0,Y.jsxs)(`div`,{className:`overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]`,children:[(0,Y.jsx)(`div`,{className:`flex gap-1 overflow-x-auto border-b border-border p-2`,children:Ci.map(n=>(0,Y.jsx)(`button`,{type:`button`,onClick:()=>t(n.name),className:J(`h-10 shrink-0 rounded-md px-3 text-xs font-medium transition-colors duration-150`,n.name===e?`bg-raised text-fg`:`text-muted hover:text-fg`),children:n.name},n.name))}),(0,Y.jsxs)(`div`,{className:`flex items-center justify-between border-b border-border px-3 py-2`,children:[(0,Y.jsx)(`span`,{className:`font-mono text-xs text-muted`,children:i?.name}),(0,Y.jsxs)(X,{size:`sm`,variant:`ghost`,onClick:()=>void o(),children:[n?(0,Y.jsx)(h,{className:`size-4`}):(0,Y.jsx)(_,{className:`size-4`}),n?`Kopyalandı`:`Kopyala`]})]}),(0,Y.jsx)(`pre`,{className:`max-h-[560px] overflow-auto p-4 font-mono text-xs leading-relaxed text-fg/90`,children:i?.content})]})]})}function ki(e){let t=[`vaxt`,`istifadeci`,`nov`,`etibar`,`canlida_nefer`,`jeton`,`yer`,`rate`,`qosulan`,`qalan_san`,`basliq`,`gonderen`,`url`],n=e.map(e=>[new Date(e.ts).toISOString(),e.username,e.giftType,e.confidence,e.viewers,e.totalCoins,e.totalSlots,e.rate,e.participants,e.remainSec??0,Ai(e.title??``),e.sender??``,e.liveUrl].join(`,`));return[t.join(`,`),...n].join(`
`)}function Ai(e){return/[",\n]/.test(e)?`"${e.replace(/"/g,`""`)}"`:e}function ji(e,t,n){let r=new Blob([t],{type:n}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=e,a.click(),URL.revokeObjectURL(i)}var Mi=Wt(`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tabular-nums`,{variants:{variant:{default:`bg-raised text-muted`,live:`bg-live-dim text-live`,box:`bg-accent/15 text-accent`,bag:`bg-warn/15 text-warn`,danger:`bg-danger/15 text-danger`,cool:`bg-raised text-fg`}},defaultVariants:{variant:`default`}});function Ni({className:e,variant:t,...n}){return(0,Y.jsx)(`span`,{className:J(Mi({variant:t,className:e})),...n})}function Pi(){let e=H(e=>e.alerts),t=H(e=>e.sendAlert),n=H(e=>e.injectSample),r=H(e=>e.clearAlerts);function i(){if(e.length===0){I.error(`Lenta boşdur`);return}ji(`sandiqradar.csv`,ki(e),`text/csv;charset=utf-8`),I.success(`CSV endirildi`)}function a(){if(e.length===0){I.error(`Lenta boşdur`);return}ji(`sandiqradar.json`,JSON.stringify(e,null,2),`application/json`),I.success(`JSON endirildi`)}return(0,Y.jsxs)(`div`,{className:`mx-auto flex w-full max-w-3xl flex-col gap-4`,children:[(0,Y.jsxs)(`div`,{className:`flex flex-wrap items-end justify-between gap-3`,children:[(0,Y.jsxs)(`div`,{children:[(0,Y.jsx)(`p`,{className:`text-xs font-medium tracking-wide text-muted uppercase`,children:`Xəbərdarlıq lenti`}),(0,Y.jsx)(`h2`,{className:`mt-1 text-xl font-semibold`,children:`Sandıq və hədiyyə çantası`})]}),(0,Y.jsxs)(`div`,{className:`flex flex-wrap gap-2`,children:[(0,Y.jsx)(X,{variant:`secondary`,size:`sm`,onClick:()=>n(`chest`),children:`Nümunə sandıq`}),(0,Y.jsx)(X,{variant:`secondary`,size:`sm`,onClick:()=>n(`gift_bag`),children:`Nümunə çanta`}),(0,Y.jsxs)(X,{variant:`ghost`,size:`sm`,onClick:i,children:[(0,Y.jsx)(v,{className:`size-4`}),`CSV`]}),(0,Y.jsx)(X,{variant:`ghost`,size:`sm`,onClick:a,children:`JSON`}),(0,Y.jsx)(X,{variant:`ghost`,size:`sm`,onClick:r,children:`Təmizlə`})]})]}),e.length===0?(0,Y.jsx)(`div`,{className:`rounded-xl bg-surface px-4 py-16 text-center shadow-[var(--shadow-border)]`,children:(0,Y.jsx)(`p`,{className:`text-sm text-muted`,children:`Lenta boşdur. Dəqiq unique_id canlı olanda növ (sandıq və ya hədiyyə çantası) və nəfər sayı burada görünəcək.`})}):(0,Y.jsx)(`ul`,{className:`flex flex-col gap-4`,children:e.map(e=>{let n=e.totalSlots>0?Math.min(100,Math.round(e.participants/e.totalSlots*100)):0;return(0,Y.jsxs)(`li`,{className:`rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5`,children:[(0,Y.jsxs)(`div`,{className:`flex flex-wrap items-start justify-between gap-3`,children:[(0,Y.jsxs)(`div`,{children:[(0,Y.jsx)(`p`,{className:`text-xs text-muted`,children:new Date(e.ts).toLocaleTimeString(`az-AZ`,{hour:`2-digit`,minute:`2-digit`,second:`2-digit`})}),(0,Y.jsxs)(`h3`,{className:`mt-1 text-lg font-semibold tracking-tight`,children:[`@`,e.username]}),(0,Y.jsxs)(`div`,{className:`mt-1 flex flex-wrap items-center gap-2`,children:[(0,Y.jsx)(Ni,{variant:e.kind===`gift_bag`?`bag`:`box`,children:e.giftType}),e.confidence?(0,Y.jsxs)(`span`,{className:`text-xs text-muted`,children:[`etibar `,Math.round(e.confidence),`%`]}):null]}),e.title?(0,Y.jsx)(`p`,{className:`mt-1 text-sm text-muted`,children:e.title}):null]}),(0,Y.jsxs)(`div`,{className:`text-right`,children:[(0,Y.jsx)(`p`,{className:`font-mono text-3xl font-medium tracking-tight text-accent tabular-nums`,children:Je(e.rate)}),(0,Y.jsx)(`p`,{className:`text-xs text-muted`,children:`jeton / nəfər`})]})]}),(0,Y.jsxs)(`dl`,{className:`mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4`,children:[(0,Y.jsx)(Fi,{icon:y,label:`Canlıda`,value:`${V(e.viewers)} nəfər`}),(0,Y.jsx)(Fi,{icon:m,label:`Bölgü`,value:`${e.totalCoins}/${e.totalSlots}`}),(0,Y.jsx)(Fi,{icon:te,label:`Qoşulan`,value:`${V(e.participants)} / ${V(e.totalSlots)}`}),(0,Y.jsx)(Fi,{icon:w,label:`Telegram`,value:e.telegramSent?`Göndərildi`:e.telegramError??`Gözləyir`})]}),(0,Y.jsxs)(`div`,{className:`mt-3`,children:[(0,Y.jsxs)(`div`,{className:`mb-1 flex justify-between text-xs text-muted`,children:[(0,Y.jsx)(`span`,{children:`Qoşulma`}),(0,Y.jsxs)(`span`,{className:`tabular-nums`,children:[n,`%`]})]}),(0,Y.jsx)(`div`,{className:`progress-bar`,children:(0,Y.jsx)(`span`,{style:{width:`${n}%`}})})]}),(0,Y.jsx)(`pre`,{className:`mt-4 overflow-x-auto rounded-lg bg-raised p-3 font-mono text-xs leading-relaxed text-muted whitespace-pre-wrap`,children:Xe(e)}),(0,Y.jsxs)(`div`,{className:`mt-3 flex flex-wrap gap-2`,children:[(0,Y.jsx)(X,{size:`sm`,variant:`secondary`,onClick:()=>{t(e).then(()=>I.message(`Telegram sorğusu göndərildi`))},children:`Telegram-a at`}),(0,Y.jsx)(X,{size:`sm`,variant:`ghost`,asChild:!0,children:(0,Y.jsx)(`a`,{href:e.liveUrl,target:`_blank`,rel:`noreferrer`,children:`Yayıma keç`})})]})]},e.id)})})]})}function Fi({icon:e,label:t,value:n}){return(0,Y.jsxs)(`div`,{className:`rounded-lg bg-raised px-3 py-2`,children:[(0,Y.jsxs)(`div`,{className:`flex items-center gap-1.5 text-faint`,children:[(0,Y.jsx)(e,{className:`size-3.5`}),(0,Y.jsx)(`span`,{className:`text-xs`,children:t})]}),(0,Y.jsx)(`p`,{className:`mt-1 text-sm font-medium tabular-nums`,children:n})]})}var Ii=[{id:`all`,label:`Hamısı`},{id:`live`,label:`Canlı`},{id:`box`,label:`Qutu`},{id:`offline`,label:`Offline`}];function Li(){let e=H(e=>e.usernames),t=H(e=>e.setUsernames),n=H(e=>e.restoreWatchlist),r=H(e=>e.live),i=H(e=>e.listFilter),a=H(e=>e.setListFilter),[o,s]=(0,O.useState)(``),[c,l]=(0,O.useState)(``),[u,d]=(0,O.useState)(``),[f,p]=(0,O.useState)(!1),[m,h]=(0,O.useState)(null),[g,_]=(0,O.useState)(``),v=(0,O.useMemo)(()=>new Map(r.map(e=>[e.username,e])),[r]),y=(0,O.useMemo)(()=>{let t=nt(e,o);return i===`all`?t:t.filter(e=>{let t=v.get(e.name)?.status??`offline`;return i===`box`?t===`box`:i===`live`?t===`live`||t===`box`:t===`offline`||t===`error`||t===`checking`})},[o,e,i,v]),b=o.trim(),x=b?y.slice(0,140):y.slice(0,90),S=y.find(e=>e.match===`exact`)??null;function w(){let e=tt(c);if(e.length===0){I.error(`Siyahı boşdur`);return}t(e),I.success(`${e.length} dəqiq istifadəçi yükləndi`),l(``)}async function T(){let e=u.trim().replace(/^@/,``);if(e){p(!0),h(null),_(``);try{let t=await qe({data:{username:e}});if(h(t),t.blocked){_(`Blok: HTTP ${t.httpStatus||`şəbəkə`}`),I.error(`TikTok sorğunu blokladı`);return}if(!t.exactMatch){_(`Uyğunsuzluq: istənilən @${e}, tapılan @${t.uniqueId||`—`}`),I.error(`Dəqiq ad uyğun gəlmədi`);return}t.live?I.success(`@${t.uniqueId} canlıdır · ${V(t.viewers)} nəfər`):I.message(`@${t.uniqueId||e} offline`)}catch(e){I.error(e instanceof Error?e.message:`Yoxlama alınmadı`)}finally{p(!1)}}}return(0,Y.jsxs)(`div`,{className:`flex flex-col gap-5 lg:grid lg:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]`,children:[(0,Y.jsxs)(`section`,{className:`rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5`,children:[(0,Y.jsxs)(`div`,{className:`mb-4 flex flex-wrap items-end justify-between gap-3`,children:[(0,Y.jsxs)(`div`,{children:[(0,Y.jsx)(`p`,{className:`text-xs font-medium tracking-wide text-muted uppercase`,children:`İzləmə siyahısı`}),(0,Y.jsxs)(`h2`,{className:`mt-1 text-xl font-semibold`,children:[V(e.length),` dəqiq ad`]})]}),(0,Y.jsxs)(`div`,{className:`relative min-w-48 flex-1`,children:[(0,Y.jsx)(C,{className:`pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-faint`}),(0,Y.jsx)(_r,{className:`pl-9`,placeholder:`Dəqiq ad axtar…`,value:o,onChange:e=>s(e.target.value),"aria-label":`İstifadəçi axtar`})]})]}),(0,Y.jsx)(`div`,{className:`mb-3 flex flex-wrap gap-1.5`,children:Ii.map(e=>(0,Y.jsx)(`button`,{type:`button`,onClick:()=>a(e.id),className:`h-9 rounded-md px-3 text-xs font-medium transition-colors duration-150 ${i===e.id?`bg-raised text-fg`:`text-muted hover:text-fg`}`,children:e.label},e.id))}),S?(0,Y.jsxs)(`div`,{className:`mb-3 rounded-lg bg-live-dim px-3 py-3`,children:[(0,Y.jsx)(`p`,{className:`text-xs font-medium text-live`,children:`Dəqiq uyğunluq tapıldı`}),(0,Y.jsxs)(`p`,{className:`mt-1 truncate text-lg font-semibold tracking-tight`,children:[`@`,S.name]})]}):b?(0,Y.jsx)(`p`,{className:`mb-3 text-sm text-muted`,children:y.length===0?`Bu ad siyahıda yoxdur — oxşar ad qəbul edilmir.`:`${y.length} yaxın nəticə`}):null,(0,Y.jsx)(`ul`,{className:`divide-y divide-border`,children:x.map(e=>{let t=v.get(e.name),n=t?.status??`offline`;return(0,Y.jsxs)(`li`,{className:`flex items-center justify-between gap-3 py-3`,children:[(0,Y.jsxs)(`div`,{className:`min-w-0`,children:[(0,Y.jsxs)(`p`,{className:`truncate font-medium`,children:[`@`,e.name]}),t?.boxLabel?(0,Y.jsxs)(`p`,{className:`text-xs text-muted`,children:[t.boxLabel,t.boxSlots?` · ${t.boxJoined??0}/${t.boxSlots}`:``]}):t?.title?(0,Y.jsx)(`p`,{className:`truncate text-xs text-muted`,children:t.title}):null]}),(0,Y.jsxs)(`div`,{className:`flex items-center gap-2`,children:[t&&t.viewers>0?(0,Y.jsxs)(`span`,{className:`font-mono text-xs text-muted tabular-nums`,children:[V(t.viewers),` nəfər`]}):null,(0,Y.jsx)(Ni,{variant:n===`box`?t?.boxKind===`gift_bag`?`bag`:`box`:n===`live`?`live`:n===`error`?`danger`:`default`,children:n===`box`?t?.boxLabel??`Qutu`:n===`live`?`Canlı`:n===`checking`?`Yoxlanır`:n===`error`?`Xəta`:`Offline`})]})]},e.name)})}),y.length>x.length?(0,Y.jsxs)(`p`,{className:`mt-3 text-xs text-muted`,children:[`Daha `,y.length-x.length,` ad var — axtarışı daraldın.`]}):null]}),(0,Y.jsxs)(`div`,{className:`flex flex-col gap-5`,children:[(0,Y.jsxs)(`section`,{className:`rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5`,children:[(0,Y.jsx)(`h3`,{className:`text-sm font-medium`,children:`Dəqiq canlı yoxlama`}),(0,Y.jsx)(`p`,{className:`mt-1 mb-3 text-sm text-muted`,children:`uniqueId eyni olmalıdır. Nəticədə növ (sandıq/çanta) və canlıdakı nəfər sayı göstərilir.`}),(0,Y.jsxs)(`div`,{className:`flex flex-col gap-2 sm:flex-row`,children:[(0,Y.jsx)(_r,{value:u,onChange:e=>d(e.target.value),placeholder:`ramiz_real`,"aria-label":`Yoxlanacaq istifadəçi`}),(0,Y.jsx)(X,{onClick:()=>void T(),disabled:f||!u.trim(),children:f?`Yoxlanır…`:`Yoxla`})]}),g?(0,Y.jsx)(`p`,{className:`mt-3 text-sm text-muted`,children:g}):null,m&&m.exactMatch?(0,Y.jsxs)(`dl`,{className:`mt-4 grid grid-cols-2 gap-2`,children:[(0,Y.jsx)(Ri,{label:`Status`,value:m.live?`Canlı`:`Offline`}),(0,Y.jsx)(Ri,{label:`Canlıda`,value:`${V(m.viewers)} nəfər`}),(0,Y.jsx)(Ri,{label:`Növ`,value:m.box?m.box.giftType:`Qutu yoxdur`}),(0,Y.jsx)(Ri,{label:`Qoşulan`,value:m.box?`${m.box.participants}/${m.box.totalSlots}`:`—`}),(0,Y.jsx)(Ri,{label:`Rate`,value:m.box?Je(m.box.rate):`—`}),(0,Y.jsx)(Ri,{label:`Etibar`,value:m.box?`${Math.round(m.box.confidence)}%`:`—`}),m.title?(0,Y.jsx)(Ri,{label:`Başlıq`,value:m.title}):null,m.box?.sender?(0,Y.jsx)(Ri,{label:`Göndərən`,value:`@${m.box.sender}`}):null]}):null]}),(0,Y.jsxs)(`section`,{className:`rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5`,children:[(0,Y.jsx)(`h3`,{className:`text-sm font-medium`,children:`Toplu idxal`}),(0,Y.jsx)(`p`,{className:`mt-1 mb-3 text-sm text-muted`,children:`Hər sətirdə bir dəqiq unique_id.`}),(0,Y.jsx)(gi,{value:c,onChange:e=>l(e.target.value),placeholder:`ramiz_real
boz_qurt37
.qara_010`}),(0,Y.jsxs)(`div`,{className:`mt-3 flex flex-col gap-2`,children:[(0,Y.jsxs)(X,{className:`w-full`,variant:`secondary`,onClick:w,children:[(0,Y.jsx)(ee,{className:`size-4`}),`Siyahını əvəz et`]}),(0,Y.jsx)(X,{className:`w-full`,variant:`ghost`,onClick:()=>{n(),I.success(`Həqiqi siyahı bərpa olundu`)},children:`Həqiqi siyahını bərpa et`})]})]})]})]})}function Ri({label:e,value:t}){return(0,Y.jsxs)(`div`,{className:`rounded-lg bg-raised px-3 py-2`,children:[(0,Y.jsx)(`p`,{className:`text-xs text-faint`,children:e}),(0,Y.jsx)(`p`,{className:`mt-0.5 truncate text-sm font-medium tabular-nums`,children:t})]})}function zi(e){return e===`gift_bag`?`bag`:e===`chest`||e===`portal`||e===`lucky`?`box`:e===`envelope`?`live`:`default`}function Bi(){let e=H(e=>e.live),t=H(e=>e.stats),n=H(e=>e.running),r=H(e=>e.ticker),i=H(e=>e.alerts),a=H(e=>e.usernames),o=H(e=>e.health),s=H(e=>e.healthNote),c=H(e=>e.settings.stealthMode),l=e.slice(0,28),u=e.reduce((e,t)=>e+t.viewers,0),d=t.checks>0?Math.round(t.okHits/t.checks*100):0;return(0,Y.jsxs)(`div`,{className:`flex flex-col gap-5 lg:grid lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:gap-6`,children:[(0,Y.jsxs)(`section`,{className:`enter-up rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-5`,children:[(0,Y.jsxs)(`div`,{className:`mb-3 flex items-end justify-between gap-3`,children:[(0,Y.jsxs)(`div`,{children:[(0,Y.jsx)(`p`,{className:`text-xs font-medium tracking-wide text-muted uppercase`,children:`Canlı radar`}),(0,Y.jsx)(`h2`,{className:`mt-1 text-xl font-semibold tracking-tight`,children:`Dəqiq tarama`})]}),(0,Y.jsxs)(`div`,{className:`flex items-center gap-2`,children:[c?(0,Y.jsx)(Ni,{variant:`box`,children:`Stealth`}):null,(0,Y.jsx)(Ni,{variant:o===`blocked`?`danger`:o===`cooling`?`bag`:n?`live`:`default`,children:o===`blocked`?`Blok`:o===`cooling`?`Backoff`:n?`Aktiv`:`Dayanıb`})]})]}),s?(0,Y.jsx)(`p`,{className:`mb-3 rounded-lg bg-raised px-3 py-2 text-xs leading-relaxed text-muted`,children:s}):null,(0,Y.jsx)(`div`,{className:`relative mx-auto aspect-square max-h-64 w-full max-w-64 sm:max-h-[360px] sm:max-w-[360px]`,children:(0,Y.jsxs)(`svg`,{viewBox:`0 0 200 200`,className:`size-full`,"aria-hidden":`true`,children:[(0,Y.jsx)(`defs`,{children:(0,Y.jsxs)(`radialGradient`,{id:`radarGlow`,cx:`50%`,cy:`50%`,r:`50%`,children:[(0,Y.jsx)(`stop`,{offset:`0%`,stopColor:`var(--color-accent)`,stopOpacity:`0.18`}),(0,Y.jsx)(`stop`,{offset:`70%`,stopColor:`var(--color-accent)`,stopOpacity:`0.04`}),(0,Y.jsx)(`stop`,{offset:`100%`,stopColor:`transparent`,stopOpacity:`0`})]})}),(0,Y.jsx)(`circle`,{cx:`100`,cy:`100`,r:`96`,fill:`url(#radarGlow)`}),[28,52,76].map((e,t)=>(0,Y.jsx)(`circle`,{className:`radar-ring`,cx:`100`,cy:`100`,r:e,fill:`none`,stroke:`var(--color-border)`,strokeWidth:`0.7`,style:{animationDelay:`${t*400}ms`}},e)),(0,Y.jsxs)(`g`,{className:`radar-sweep`,children:[(0,Y.jsx)(`path`,{d:`M100 100 L100 8 A92 92 0 0 1 148 22 Z`,fill:`var(--color-accent)`,opacity:`0.12`}),(0,Y.jsx)(`line`,{x1:`100`,y1:`100`,x2:`100`,y2:`8`,stroke:`var(--color-accent)`,strokeWidth:`0.8`,opacity:`0.7`})]}),l.map((e,t)=>{let n=Hi(e.username)/180*Math.PI,r=22+Hi(e.username+`r`)%62,i=100+Math.cos(n)*r,a=100+Math.sin(n)*r,o=e.status===`box`,s=e.boxKind===`gift_bag`;return(0,Y.jsx)(`circle`,{cx:i,cy:a,r:o?3.4:2,fill:s?`var(--color-warn)`:o?`var(--color-accent)`:`var(--color-live)`,opacity:.55+t%5*.08},e.username)}),(0,Y.jsx)(`circle`,{cx:`100`,cy:`100`,r:`3.4`,fill:`var(--color-fg)`})]})}),(0,Y.jsxs)(`p`,{className:`mt-3 text-center font-mono text-xs text-muted tabular-nums`,children:[V(t.scanned),`/`,V(a.length),` yoxlanıb · `,V(t.live),` canlı · `,V(u),` nəfər`]}),(0,Y.jsx)(`p`,{className:`mt-1 truncate font-mono text-xs text-faint`,children:r.length>0?r.map(e=>`@${e}`).join(`  ·  `):`Növbə gözləyir`})]}),(0,Y.jsxs)(`div`,{className:`flex flex-col gap-5`,children:[(0,Y.jsxs)(`section`,{className:`grid grid-cols-2 gap-3 sm:grid-cols-3`,children:[(0,Y.jsx)(Vi,{icon:S,label:`Canlı`,value:V(t.live),tone:`live`}),(0,Y.jsx)(Vi,{icon:m,label:`Aktiv qutu`,value:V(t.boxes),tone:`accent`}),(0,Y.jsx)(Vi,{icon:te,label:`Nəfər (indi)`,value:V(u)}),(0,Y.jsx)(Vi,{icon:y,label:`Yoxlama`,value:V(t.checks)}),(0,Y.jsx)(Vi,{icon:D,label:`Xəbərdarlıq`,value:V(t.alerts)}),(0,Y.jsx)(Vi,{icon:E,label:`Uğur`,value:`${d}%`})]}),(0,Y.jsxs)(`section`,{className:`rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]`,children:[(0,Y.jsxs)(`div`,{className:`mb-3 flex items-center justify-between`,children:[(0,Y.jsx)(`h3`,{className:`text-sm font-medium`,children:`Canlı otaqlar`}),(0,Y.jsxs)(`span`,{className:`text-xs text-muted`,children:[e.length,` dəqiq uyğunluq`]})]}),(0,Y.jsx)(`ul`,{className:`flex flex-col gap-2`,children:e.slice(0,6).length===0?(0,Y.jsx)(`li`,{className:`rounded-lg bg-raised px-3 py-6 text-center text-sm text-muted`,children:`Hələ dəqiq unique_id canlı tapılmayıb. Stealth rejim yavaş, amma daha az bloklanır.`}):e.slice(0,6).map(e=>(0,Y.jsxs)(`li`,{className:`flex items-center justify-between gap-3 rounded-lg bg-raised px-3 py-2.5`,children:[(0,Y.jsxs)(`div`,{className:`min-w-0`,children:[(0,Y.jsxs)(`p`,{className:`truncate font-medium`,children:[`@`,e.uniqueId||e.username]}),(0,Y.jsxs)(`p`,{className:`text-xs text-muted`,children:[e.boxLabel??e.title??`Canlı`,e.boxSlots?` · ${e.boxJoined??0}/${e.boxSlots}`:``]})]}),(0,Y.jsxs)(`div`,{className:`flex shrink-0 flex-col items-end gap-1`,children:[(0,Y.jsxs)(`p`,{className:`font-mono text-sm tabular-nums`,children:[V(e.viewers),` nəfər`]}),e.status===`box`?(0,Y.jsxs)(Ni,{variant:zi(e.boxKind),children:[e.boxLabel??`Qutu`,` · `,Je(e.boxRate??0)]}):(0,Y.jsx)(Ni,{variant:`live`,children:`Canlı`})]})]},e.username))})]}),(0,Y.jsxs)(`section`,{className:`rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]`,children:[(0,Y.jsxs)(`div`,{className:`mb-3 flex items-center justify-between`,children:[(0,Y.jsx)(`h3`,{className:`text-sm font-medium`,children:`Son qutular`}),(0,Y.jsxs)(`span`,{className:`text-xs text-muted`,children:[i.length,` qeyd`]})]}),(0,Y.jsx)(`ul`,{className:`flex flex-col gap-2`,children:i.slice(0,4).length===0?(0,Y.jsx)(`li`,{className:`rounded-lg bg-raised px-3 py-5 text-center text-sm text-muted`,children:`Sandıq və ya hədiyyə çantası tapılanda növ + nəfər sayı burada görünür.`}):i.slice(0,4).map(e=>(0,Y.jsxs)(`li`,{className:`flex items-center justify-between gap-3 rounded-lg bg-raised px-3 py-2.5`,children:[(0,Y.jsxs)(`div`,{className:`min-w-0`,children:[(0,Y.jsxs)(`p`,{className:`truncate font-medium`,children:[`@`,e.username]}),(0,Y.jsxs)(`p`,{className:`text-xs text-muted`,children:[e.giftType,` · `,V(e.viewers),` nəfər · `,e.participants,`/`,e.totalSlots]})]}),(0,Y.jsx)(`p`,{className:`font-mono text-sm tabular-nums text-accent`,children:Je(e.rate)})]},e.id))})]})]})]})}function Vi({icon:e,label:t,value:n,tone:r}){return(0,Y.jsxs)(`div`,{className:`rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]`,children:[(0,Y.jsxs)(`div`,{className:`flex items-center gap-2 text-muted`,children:[(0,Y.jsx)(e,{className:`size-3.5`}),(0,Y.jsx)(`span`,{className:`text-xs`,children:t})]}),(0,Y.jsx)(`p`,{className:J(`mt-2 font-mono text-2xl font-medium tracking-tight tabular-nums`,r===`live`&&`text-live`,r===`accent`&&`text-accent`),children:n})]})}function Hi(e){let t=0;for(let n=0;n<e.length;n+=1)t=t*33+e.charCodeAt(n)>>>0;return t%360}var Ui=[{id:`radar`,label:`Radar`,icon:S},{id:`list`,label:`Siyahı`,icon:te},{id:`feed`,label:`Lenta`,icon:p},{id:`bot`,label:`Ayarlar`,icon:T},{id:`code`,label:`Kod`,icon:g}];function Wi(){let e=H(e=>e.view),t=H(e=>e.setView),n=H(e=>e.running),r=H(e=>e.start),i=H(e=>e.stop),a=H(e=>e.stats),o=H(e=>e.health),s=H(e=>e.live),c=H(e=>e.usernames.length),l=s.reduce((e,t)=>e+t.viewers,0);return(0,O.useEffect)(()=>(r(),()=>i()),[]),(0,Y.jsxs)(`div`,{className:`flex min-h-dvh bg-bg text-fg`,children:[(0,Y.jsx)(Ce,{theme:`dark`,position:`top-right`}),(0,Y.jsxs)(`aside`,{className:`sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border bg-surface/60 p-4 md:flex`,children:[(0,Y.jsx)(Gi,{}),(0,Y.jsx)(`nav`,{className:`mt-8 flex flex-1 flex-col gap-1`,children:Ui.map(n=>(0,Y.jsx)(Ki,{...n,active:e===n.id,onSelect:t},n.id))}),(0,Y.jsx)(`p`,{className:`text-xs text-faint`,children:`Sandıq / hədiyyə çantası · dəqiq nəfər`})]}),(0,Y.jsxs)(`div`,{className:`flex min-w-0 flex-1 flex-col pb-20 md:pb-0`,children:[(0,Y.jsxs)(`header`,{className:`sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 py-3 backdrop-blur-sm sm:px-6`,children:[(0,Y.jsx)(`div`,{className:`min-w-0 md:hidden`,children:(0,Y.jsx)(Gi,{compact:!0})}),(0,Y.jsxs)(`p`,{className:`hidden truncate text-sm text-muted md:block`,children:[V(a.live),` canlı · `,V(l),` nəfər · `,V(a.alerts),` xəbərdarlıq ·`,` `,V(a.scanned),`/`,V(c),o===`blocked`?` · blok`:o===`cooling`?` · backoff`:``]}),(0,Y.jsxs)(X,{size:`sm`,variant:n?`secondary`:`default`,onClick:()=>n?i():r(),"aria-pressed":n,children:[n?(0,Y.jsx)(b,{className:`size-4`}):(0,Y.jsx)(x,{className:`size-4`}),n?`Dayandır`:`Başlat`]})]}),(0,Y.jsxs)(`main`,{className:`flex-1 px-4 py-5 sm:px-6 sm:py-6`,children:[e===`radar`&&(0,Y.jsx)(Bi,{}),e===`list`&&(0,Y.jsx)(Li,{}),e===`feed`&&(0,Y.jsx)(Pi,{}),e===`bot`&&(0,Y.jsx)(vi,{}),e===`code`&&(0,Y.jsx)(Oi,{})]})]}),(0,Y.jsx)(`nav`,{className:`fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-surface/95 px-1 pt-1 pb-[max(0.35rem,env(safe-area-inset-bottom))] backdrop-blur-sm md:hidden`,children:Ui.map(n=>(0,Y.jsx)(Ki,{...n,active:e===n.id,onSelect:t,stacked:!0},n.id))})]})}function Gi({compact:e=!1}){return(0,Y.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,Y.jsx)(`span`,{className:`grid size-8 place-items-center rounded-md bg-raised shadow-[var(--shadow-border)]`,children:(0,Y.jsx)(S,{className:`size-4 text-accent`})}),(0,Y.jsxs)(`div`,{className:`min-w-0`,children:[(0,Y.jsx)(`p`,{className:`truncate text-sm font-semibold tracking-tight`,children:`SandıqRadar`}),e?null:(0,Y.jsx)(`p`,{className:`text-xs text-muted`,children:`Növ + nəfər sayı`})]})]})}function Ki({id:e,label:t,icon:n,active:r,onSelect:i,stacked:a}){return(0,Y.jsxs)(`button`,{type:`button`,onClick:()=>i(e),className:J(`flex items-center gap-2 rounded-md px-3 text-sm font-medium transition-colors duration-150`,a?`h-14 flex-col justify-center gap-1 px-1 text-[11px]`:`h-11`,r?`bg-raised text-fg`:`text-muted hover:text-fg`),"aria-current":r?`page`:void 0,children:[(0,Y.jsx)(n,{className:J(`size-4`,a&&`size-[18px]`)}),t]})}function qi(){return(0,Y.jsx)(Wi,{})}export{qi as component};