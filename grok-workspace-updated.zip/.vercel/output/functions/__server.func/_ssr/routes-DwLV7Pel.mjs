import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as Slot } from "../_libs/@radix-ui/react-primitive+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as fmtNum, o as parseUsernameList, r as fmtRate, s as searchUsernames, t as defaultWatchlist } from "./usernames-BlsEYq2x.mjs";
import { a as string, i as object, t as array } from "../_libs/zod.mjs";
import { _ as Box, a as Shield, c as Search, d as Pause, f as Eye, g as Check, h as CodeXml, l as Radio, m as Copy, n as Users, o as Settings, p as Download, r as Upload, s as Send, t as Zap, u as Play, v as Bell } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DwLV7Pel.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var sendTelegramAlert = createServerFn({ method: "POST" }).validator(object({
	token: string().min(10).max(200),
	chatId: string().min(1).max(64),
	text: string().min(1).max(4e3)
})).handler(createSsrRpc("bf41790866200090c2e98d8635870116685a89794264040ae816b9d8460360f2"));
function playAlertTone() {
	if (typeof window === "undefined") return;
	try {
		const ctx = new (window.AudioContext || window.webkitAudioContext)();
		const now = ctx.currentTime;
		const beep = (freq, at, dur) => {
			const osc = ctx.createOscillator();
			const gain = ctx.createGain();
			osc.type = "sine";
			osc.frequency.value = freq;
			gain.gain.setValueAtTime(1e-4, at);
			gain.gain.exponentialRampToValueAtTime(.07, at + .02);
			gain.gain.exponentialRampToValueAtTime(1e-4, at + dur);
			osc.connect(gain);
			gain.connect(ctx.destination);
			osc.start(at);
			osc.stop(at + dur + .02);
		};
		beep(880, now, .12);
		beep(1174, now + .14, .16);
		window.setTimeout(() => void ctx.close(), 600);
	} catch {}
}
async function requestNotifyPermission() {
	if (typeof window === "undefined" || !("Notification" in window)) return false;
	if (Notification.permission === "granted") return true;
	if (Notification.permission === "denied") return false;
	return await Notification.requestPermission() === "granted";
}
function pushBoxNotification(text) {
	if (typeof window === "undefined" || !("Notification" in window)) return;
	if (Notification.permission !== "granted") return;
	try {
		new Notification("SandıqRadar", {
			body: text,
			tag: "sandiqradar-box"
		});
	} catch {}
}
var PRODUCT_FEATURES = [
	{
		id: "kind",
		title: "Dəqiq növ",
		detail: "Sandıq, hədiyyə çantası, zərf, portal və şans qutusu business_type + ad siqnalları ilə ayrılır."
	},
	{
		id: "viewers",
		title: "Canlıda nəfər",
		detail: "Cari otaq sayı (user_count). Enter_count ümumi girişdir, baxış kimi götürülmür."
	},
	{
		id: "joined",
		title: "Sandığa qoşulan",
		detail: "Qoşulan / yer sayı (joined/slots) progress bar ilə."
	},
	{
		id: "rate",
		title: "Rate",
		detail: "Jeton ÷ yer. Minimum rate filtrinə düşməyənlər Telegram-a getmir."
	},
	{
		id: "remain",
		title: "Qalan vaxt",
		detail: "unpack_at və remain_time-dan gerisayım."
	},
	{
		id: "dup",
		title: "Duplicate qoruma",
		detail: "Eyni box_id bir dəfə xəbərdarlıq edir, bitəndə açar silinir."
	},
	{
		id: "id",
		title: "Dəqiq unique_id",
		detail: "ramiz_real1 ramiz_real sayılmır. Durğu işarəsi dəqiq eyni olmalıdır."
	},
	{
		id: "status",
		title: "Yalnız status=2",
		detail: "status=4 offline-dur, səhvən canlı göstərilmir."
	},
	{
		id: "stealth",
		title: "Stealth rejim",
		detail: "Aşağı paralel, jitter, insan tempi — TikTok WAF-ı az oyadır."
	},
	{
		id: "cookie",
		title: "Cookie warmup",
		detail: "ttwid/msToken sessiyası tiktok.com-dan götürülür və sorğulara yapışdırılır."
	},
	{
		id: "ua",
		title: "UA rotasiyası",
		detail: "Chrome/Safari/Firefox + uyğun sec-ch-ua Client Hints."
	},
	{
		id: "device",
		title: "Cihaz izi",
		detail: "Hər sessiyada təsadüfi device_id, ekran və dil parametrləri."
	},
	{
		id: "backoff",
		title: "Backoff",
		detail: "403/429/503-də eksponensial yavaşlama və circuit breaker."
	},
	{
		id: "multi",
		title: "Multi-endpoint",
		detail: "api-live, webcast, m.tiktok, HTML hydration ehtiyatı."
	},
	{
		id: "boxapi",
		title: "Sandıq API-ləri",
		detail: "room/info, envelope/list, room/enter eyni otaqda növü dəqiqləşdirir."
	},
	{
		id: "priority",
		title: "Prioritet kanallar",
		detail: "Seçilmiş adlar hər dövrdə birinci yoxlanır."
	},
	{
		id: "filters",
		title: "Filtrlər",
		detail: "Min baxış, min jeton, min rate, canlı/sandıq/offline."
	},
	{
		id: "sound",
		title: "Səs siqnalı",
		detail: "Sandıq tapılanda qısa ton."
	},
	{
		id: "notify",
		title: "Brauzer bildirişi",
		detail: "Növ + nəfər sayı bildiriş mətnində."
	},
	{
		id: "export",
		title: "İxrac",
		detail: "Xəbərdarlıqları JSON və CSV kimi endir."
	},
	{
		id: "sort",
		title: "Sıralama",
		detail: "Baxış, rate və vaxta görə."
	},
	{
		id: "stats",
		title: "Statistika",
		detail: "Uğur, blok faizi, yoxlama/saniyə, peak baxış."
	},
	{
		id: "tg",
		title: "Telegram",
		detail: "Növ, canlıdakı nəfər, qoşulan, rate, qalan vaxt — dublikatsız."
	},
	{
		id: "probe",
		title: "Dərin yoxlama",
		detail: "Tək ad üçün növ + nəfər + etibar faizi."
	},
	{
		id: "peak",
		title: "Peak baxış",
		detail: "Yayım ərzində ən yüksək nəfər sayı saxlanır."
	},
	{
		id: "title",
		title: "Yayım başlığı",
		detail: "Otaq title-ı kartda və Telegram-da."
	},
	{
		id: "sender",
		title: "Göndərən",
		detail: "Sandığı atan unique_id (varsa)."
	},
	{
		id: "conf",
		title: "Etibar faizi",
		detail: "Növ təsnifatının nə qədər əmin olduğu."
	},
	{
		id: "autopause",
		title: "Avto-pauza",
		detail: "Blok dalğasında tarama özü yavaşlayır, sonra davam edir."
	},
	{
		id: "proxy",
		title: "Proxy (Python)",
		detail: "VPS-də residential proxy + per-proxy cookie. Datacenter IP bloklanır."
	},
	{
		id: "watch",
		title: "Canlı izləmə",
		detail: "Tapılan otaq sandıq üçün sıx poll edilir, offline olanda dayanır."
	},
	{
		id: "list",
		title: "Siyahı idxal",
		detail: "500+ dəqiq unique_id, oxşar ad yoxdur."
	}
];
var scanLiveBatch = createServerFn({ method: "POST" }).validator(object({ usernames: array(string().min(1).max(64)).min(1).max(6) })).handler(createSsrRpc("cf4e33755709492a11bb9481d4c66b8242f1f8cb7a69ec3202f23e3efab32844"));
var probeUserLive = createServerFn({ method: "POST" }).validator(object({ username: string().min(1).max(64) })).handler(createSsrRpc("546d6aaf7a0a06d24e79f90b87080c080c75d7b7dbb2f0a3bcfbe355bff243a5"));
function md(text) {
	return text.replace(/\\/g, "\\\\").replace(/_/g, "\\_").replace(/\*/g, "\\*").replace(/`/g, "\\`").replace(/\[/g, "\\[");
}
function formatTelegramAlert(alert) {
	const remain = alert.remainSec && alert.remainSec > 0 ? `\n⏱ **Qalan vaxt:** ${alert.remainSec} san` : "";
	const title = alert.title ? `\n📺 **Yayım:** ${md(alert.title)}` : "";
	const sender = alert.sender ? `\n✍️ **Göndərən:** @${md(alert.sender)}` : "";
	const conf = alert.confidence ? `\n🎯 **Növ etibarı:** ${Math.round(alert.confidence)}%` : "";
	const peak = alert.peakViewers && alert.peakViewers > alert.viewers ? ` (peak ${fmtNum(alert.peakViewers)})` : "";
	return [
		"🚨 **CANLI VƏ QUTU TAPILDI!** 🚨",
		"",
		`👤 **İstifadəçi:** @${md(alert.username)}`,
		`🎁 **Növ:** ${md(alert.giftType)}`,
		`👀 **Canlıda nəfər:** ${fmtNum(alert.viewers)}${peak}`,
		`📊 **Bölgü:** ${alert.totalCoins}/${alert.totalSlots} jeton/yer`,
		`💎 **Rate:** ${fmtRate(alert.rate)} jeton/nəfər`,
		`👥 **Qutuya qoşulan:** ${fmtNum(alert.participants)} / ${fmtNum(alert.totalSlots)} nəfər${title}${sender}${remain}${conf}`,
		`🔗 **Canlı yayım:** [Yayıma Keç](${alert.liveUrl})`
	].join("\n");
}
function formatNotifyBody(alert) {
	return `@${alert.username} · ${alert.giftType} · canlıda ${fmtNum(alert.viewers)} nəfər · ${alert.totalCoins}/${alert.totalSlots} · rate ${fmtRate(alert.rate)}`;
}
var defaultSettings = {
	telegramToken: "",
	telegramChatId: "",
	autoTelegram: false,
	concurrency: 12,
	intervalMs: 8e3,
	minRate: 1,
	minViewers: 0,
	minCoins: 0,
	proxiesText: "",
	stealthMode: true,
	soundAlerts: true,
	browserNotify: false,
	autoPauseOnBlock: true,
	priorityText: ""
};
var emptyStats = {
	checks: 0,
	checksPerSec: 0,
	live: 0,
	boxes: 0,
	alerts: 0,
	telegramOk: 0,
	startedAt: null,
	scanned: 0,
	cycle: 0,
	blocked: 0,
	mismatches: 0,
	okHits: 0,
	peakLiveViewers: 0
};
var streamers = /* @__PURE__ */ new Map();
var activeKeys = /* @__PURE__ */ new Set();
var cursor = 0;
var runId = 0;
var checkWindow = 0;
var checkWindowAt = 0;
function seedStreamers(names) {
	const keep = new Map(streamers);
	streamers.clear();
	for (const u of names) {
		const prev = keep.get(u);
		streamers.set(u, prev ?? {
			username: u,
			status: "offline",
			viewers: 0,
			lastChecked: 0,
			exactMatch: true
		});
	}
}
function priorityNames(text, all) {
	const wanted = parseUsernameList(text);
	const set = new Set(all.map((n) => n.toLowerCase()));
	return wanted.filter((n) => set.has(n.toLowerCase()));
}
var useRadar = create()(persist((set, get) => ({
	view: "radar",
	setView: (view) => set({ view }),
	usernames: defaultWatchlist(),
	setUsernames: (names) => {
		const unique = names.length > 0 ? names : defaultWatchlist();
		seedStreamers(unique);
		cursor = 0;
		set({
			usernames: unique,
			live: []
		});
	},
	restoreWatchlist: () => {
		const unique = defaultWatchlist();
		seedStreamers(unique);
		cursor = 0;
		set({
			usernames: unique,
			live: []
		});
	},
	settings: defaultSettings,
	patchSettings: (patch) => set((s) => ({ settings: {
		...s.settings,
		...patch
	} })),
	running: false,
	stats: emptyStats,
	live: [],
	ticker: [],
	alerts: [],
	workersBusy: 0,
	health: "unknown",
	healthNote: "",
	listFilter: "all",
	setListFilter: (listFilter) => set({ listFilter }),
	sortKey: "viewers",
	setSortKey: (sortKey) => set({ sortKey }),
	start: () => {
		if (get().running) return;
		const names = get().usernames;
		seedStreamers(names);
		runId += 1;
		const my = runId;
		checkWindow = 0;
		checkWindowAt = performance.now();
		set({
			running: true,
			health: "unknown",
			healthNote: "",
			stats: {
				...emptyStats,
				startedAt: Date.now()
			}
		});
		runLoop(my, get, set);
	},
	stop: () => {
		runId += 1;
		set({
			running: false,
			workersBusy: 0,
			stats: {
				...get().stats,
				checksPerSec: 0
			}
		});
	},
	sendAlert: async (alert) => {
		const { settings } = get();
		if (!settings.telegramToken || !settings.telegramChatId) {
			set((s) => ({ alerts: s.alerts.map((a) => a.id === alert.id ? {
				...a,
				telegramError: "Token və ya chat ID yoxdur"
			} : a) }));
			return;
		}
		try {
			const res = await sendTelegramAlert({ data: {
				token: settings.telegramToken,
				chatId: settings.telegramChatId,
				text: formatTelegramAlert(alert)
			} });
			set((s) => ({
				alerts: s.alerts.map((a) => a.id === alert.id ? {
					...a,
					telegramSent: res.ok,
					telegramError: res.ok ? void 0 : res.error
				} : a),
				stats: res.ok ? {
					...s.stats,
					telegramOk: s.stats.telegramOk + 1
				} : s.stats
			}));
		} catch (err) {
			set((s) => ({ alerts: s.alerts.map((a) => a.id === alert.id ? {
				...a,
				telegramError: err instanceof Error ? err.message : "Göndərmə xətası"
			} : a) }));
		}
	},
	injectSample: (kind = "chest") => {
		const giftBag = kind === "gift_bag";
		emitAlert({
			id: `sample-${kind}-${Date.now()}`,
			username: giftBag ? "zevs_show" : "ramiz_real",
			viewers: giftBag ? 840 : 1250,
			peakViewers: giftBag ? 910 : 1400,
			giftType: giftBag ? "Hədiyyə çantası" : "Sandıq",
			kind: giftBag ? "gift_bag" : "chest",
			confidence: giftBag ? 92 : 96,
			totalCoins: giftBag ? 30 : 50,
			totalSlots: giftBag ? 10 : 10,
			rate: giftBag ? 3 : 5,
			participants: giftBag ? 6 : 8,
			liveUrl: giftBag ? "https://www.tiktok.com/@zevs_show/live" : "https://www.tiktok.com/@ramiz_real/live",
			ts: Date.now(),
			telegramSent: false,
			exactMatch: true,
			remainSec: 40,
			title: giftBag ? "gecə yayımı" : "live",
			sender: giftBag ? "fan_01" : "boz_qurt37",
			signals: giftBag ? ["business_type=2"] : ["business_type=1"]
		}, get, set);
	},
	clearAlerts: () => {
		activeKeys.clear();
		set({
			alerts: [],
			stats: {
				...get().stats,
				alerts: 0,
				boxes: 0
			}
		});
	}
}), {
	name: "sandiqradar-v3",
	partialize: (s) => ({
		usernames: s.usernames,
		settings: s.settings
	}),
	onRehydrateStorage: () => (state) => {
		if (!state) return;
		const first = state.usernames[0];
		if (state.usernames.length < 80 || first === "leyla_live" || first === "leyla_tv") state.usernames = defaultWatchlist();
		state.settings = {
			...defaultSettings,
			...state.settings
		};
		seedStreamers(state.usernames);
	}
}));
function sleep(ms) {
	return new Promise((resolve) => window.setTimeout(resolve, ms));
}
async function runLoop(id, get, set) {
	while (runId === id) {
		const { usernames, settings, health } = get();
		if (usernames.length === 0) {
			await sleep(800);
			continue;
		}
		if (health === "cooling" || health === "blocked" && settings.autoPauseOnBlock) await sleep(settings.stealthMode ? 12e3 : 9e3);
		const stealth = settings.stealthMode;
		const batchSize = health === "blocked" || health === "cooling" ? 1 : stealth ? Math.min(3, Math.max(1, Math.round(settings.concurrency / 8))) : Math.min(5, Math.max(2, Math.round(settings.concurrency / 10)));
		const batch = [];
		const prio = priorityNames(settings.priorityText, usernames);
		for (const name of prio) {
			if (batch.length >= Math.min(1, batchSize)) break;
			batch.push(name);
		}
		for (let i = 0; i < batchSize; i += 1) {
			const name = usernames[cursor % usernames.length];
			cursor += 1;
			if (name && !batch.includes(name)) batch.push(name);
		}
		for (const name of batch) {
			const prev = streamers.get(name);
			streamers.set(name, {
				username: name,
				status: "checking",
				viewers: prev?.viewers ?? 0,
				peakViewers: prev?.peakViewers,
				lastChecked: Date.now(),
				uniqueId: prev?.uniqueId,
				exactMatch: prev?.exactMatch,
				roomId: prev?.roomId,
				title: prev?.title,
				liveSince: prev?.liveSince
			});
		}
		set({
			ticker: batch,
			workersBusy: batch.length
		});
		try {
			const res = await scanLiveBatch({ data: { usernames: batch } });
			applyHits(res.hits, get, set, Boolean(res.cooling));
		} catch (err) {
			applyNetworkFail(batch, err, get, set);
		}
		await sleep(stealth ? get().health === "blocked" || get().health === "cooling" ? 11e3 : Math.max(1400, Math.round(settings.intervalMs / Math.max(2, batchSize))) : get().health === "blocked" ? 9e3 : Math.max(400, Math.round(settings.intervalMs / Math.max(6, batchSize))));
	}
}
function applyNetworkFail(batch, err, get, set) {
	const msg = err instanceof Error ? err.message : "şəbəkə xətası";
	for (const name of batch) streamers.set(name, {
		username: name,
		status: "error",
		viewers: 0,
		lastChecked: Date.now(),
		error: msg
	});
	publishLive(get, set, {
		checks: batch.length,
		blockedDelta: 0,
		mismatchDelta: 0,
		okDelta: 0,
		health: "blocked",
		note: "Tarama sorğusu uğursuz oldu. Python botunu öz VPS + proxy ilə işə salın — stealth rejim açıq saxlayın."
	});
}
function applyHits(hits, get, set, cooling) {
	let blocked = 0;
	let mismatches = 0;
	let ok = 0;
	const { settings } = get();
	for (const hit of hits) {
		if (hit.blocked) blocked += 1;
		else ok += 1;
		if (!hit.exactMatch) mismatches += 1;
		const prev = streamers.get(hit.username);
		const peak = Math.max(prev?.peakViewers ?? 0, hit.viewers);
		const liveSince = hit.live ? prev?.liveSince ?? Date.now() : void 0;
		const status = hit.box && hit.live ? "box" : hit.live ? "live" : hit.blocked ? "error" : "offline";
		streamers.set(hit.username, {
			username: hit.username,
			uniqueId: hit.uniqueId,
			exactMatch: hit.exactMatch,
			status,
			viewers: hit.viewers,
			peakViewers: peak,
			lastChecked: Date.now(),
			liveSince,
			title: hit.title,
			roomId: hit.roomId,
			error: hit.error || void 0,
			boxKind: hit.box?.kind,
			boxLabel: hit.box?.giftType,
			boxRate: hit.box?.rate,
			boxCoins: hit.box?.totalCoins,
			boxSlots: hit.box?.totalSlots,
			boxJoined: hit.box?.participants,
			remainSec: hit.box?.remainSec,
			boxConfidence: hit.box?.confidence,
			sender: hit.box?.sender
		});
		if (hit.live && hit.exactMatch && hit.box) {
			if (hit.viewers < settings.minViewers) continue;
			if (hit.box.totalCoins < settings.minCoins) continue;
			const alert = {
				id: `${hit.uniqueId}-${hit.box.boxId || `${hit.box.kind}-${hit.box.totalCoins}-${hit.box.totalSlots}`}-${Math.floor(Date.now() / 12e3)}`,
				username: hit.uniqueId || hit.username,
				viewers: hit.viewers,
				peakViewers: peak,
				giftType: hit.box.giftType,
				kind: hit.box.kind,
				confidence: hit.box.confidence,
				totalCoins: hit.box.totalCoins,
				totalSlots: hit.box.totalSlots,
				rate: hit.box.rate,
				participants: hit.box.participants,
				liveUrl: hit.liveUrl,
				ts: Date.now(),
				telegramSent: false,
				exactMatch: true,
				remainSec: hit.box.remainSec,
				title: hit.title,
				sender: hit.box.sender,
				signals: hit.box.signals
			};
			const key = `${alert.username}:${hit.box.boxId || `${alert.totalCoins}:${alert.totalSlots}:${alert.kind}`}`;
			if (!activeKeys.has(key)) emitAlert(alert, get, set);
		} else if (!hit.box) {
			for (const key of [...activeKeys]) if (key.startsWith(`${hit.uniqueId || hit.username}:`)) activeKeys.delete(key);
		}
	}
	const ratio = hits.length > 0 ? blocked / hits.length : 0;
	const health = cooling ? "cooling" : ratio >= .6 ? "blocked" : "ok";
	const note = health === "blocked" ? "TikTok bu IP-dən sorğuları kəsir. Stealth açıq saxlayın və ya Python paketini residential proxy ilə VPS-də işə salın." : health === "cooling" ? "Mühərrik yavaşladı — blok siqnalından sonra backoff." : "";
	publishLive(get, set, {
		checks: hits.length,
		blockedDelta: blocked,
		mismatchDelta: mismatches,
		okDelta: ok,
		health,
		note
	});
}
function publishLive(get, set, meta) {
	checkWindow += meta.checks;
	const elapsed = performance.now() - checkWindowAt;
	let cps = get().stats.checksPerSec;
	if (elapsed >= 800) {
		cps = Math.round(checkWindow / elapsed * 1e3);
		checkWindow = 0;
		checkWindowAt = performance.now();
	}
	const live = [];
	let viewerSum = 0;
	for (const s of streamers.values()) if (s.status === "live" || s.status === "box") {
		live.push(s);
		viewerSum += s.viewers;
	}
	const { sortKey } = get();
	live.sort((a, b) => {
		if (sortKey === "name") return a.username.localeCompare(b.username);
		if (sortKey === "rate") return (b.boxRate ?? 0) - (a.boxRate ?? 0);
		if (sortKey === "time") return (b.liveSince ?? 0) - (a.liveSince ?? 0);
		if (a.status !== b.status) return a.status === "box" ? -1 : 1;
		return b.viewers - a.viewers;
	});
	const scanned = [...streamers.values()].filter((s) => s.lastChecked > 0).length;
	const cycle = get().usernames.length > 0 ? Math.floor(get().stats.checks / get().usernames.length) : 0;
	set((s) => ({
		live: live.slice(0, 80),
		workersBusy: meta.checks,
		health: meta.health,
		healthNote: meta.note || (meta.health === "ok" ? "" : s.healthNote),
		stats: {
			...s.stats,
			checks: s.stats.checks + meta.checks,
			checksPerSec: cps,
			live: live.length,
			boxes: live.filter((x) => x.status === "box").length,
			scanned,
			cycle,
			blocked: s.stats.blocked + meta.blockedDelta,
			mismatches: s.stats.mismatches + meta.mismatchDelta,
			okHits: s.stats.okHits + meta.okDelta,
			peakLiveViewers: Math.max(s.stats.peakLiveViewers, viewerSum)
		}
	}));
}
function emitAlert(alert, get, set) {
	const { settings, alerts } = get();
	if (alert.rate < settings.minRate) return;
	if (alert.viewers < settings.minViewers) return;
	if (alert.totalCoins < settings.minCoins) return;
	if (alerts.some((a) => a.id === alert.id)) return;
	activeKeys.add(`${alert.username}:${alert.totalCoins}:${alert.totalSlots}:${alert.kind}`);
	set((s) => ({
		alerts: [alert, ...s.alerts].slice(0, 120),
		stats: {
			...s.stats,
			alerts: s.stats.alerts + 1,
			boxes: s.stats.boxes + 1
		}
	}));
	toast.success(`@${alert.username} · ${alert.giftType} · ${alert.viewers} nəfər`);
	if (settings.soundAlerts) playAlertTone();
	if (settings.browserNotify) pushBoxNotification(formatNotifyBody(alert));
	if (settings.autoTelegram && settings.telegramToken && settings.telegramChatId) get().sendAlert(alert);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-raised text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-muted hover:bg-raised hover:text-fg",
			danger: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md bg-raised px-3 text-sm text-fg shadow-[var(--shadow-border)]", "placeholder:text-faint focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50", "disabled:opacity-40", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-xs font-medium text-muted", className),
		...props
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-7 w-12 shrink-0 items-center rounded-full bg-raised shadow-[var(--shadow-border)]", "transition-colors duration-150 data-[state=checked]:bg-accent", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block size-5 translate-x-1 rounded-full bg-fg transition-transform duration-150", "data-[state=checked]:translate-x-6 data-[state=checked]:bg-accent-fg") })
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-32 w-full rounded-lg bg-raised px-3 py-3 text-sm text-fg shadow-[var(--shadow-border)]", "placeholder:text-faint focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50", className),
		...props
	});
}
var TABS = [
	{
		id: "stealth",
		label: "Stealth"
	},
	{
		id: "telegram",
		label: "Telegram"
	},
	{
		id: "filter",
		label: "Filtr"
	},
	{
		id: "features",
		label: "32 xüsusiyyət"
	}
];
function BotView() {
	const settings = useRadar((s) => s.settings);
	const patch = useRadar((s) => s.patchSettings);
	const stats = useRadar((s) => s.stats);
	const health = useRadar((s) => s.health);
	const [tab, setTab] = (0, import_react.useState)("stealth");
	const okRate = stats.checks > 0 ? Math.round(stats.okHits / stats.checks * 100) : 0;
	async function testTelegram() {
		if (!settings.telegramToken || !settings.telegramChatId) {
			toast.error("Token və chat ID doldurun");
			return;
		}
		try {
			const res = await sendTelegramAlert({ data: {
				token: settings.telegramToken,
				chatId: settings.telegramChatId,
				text: "SandıqRadar test. Növ + nəfər sayı işləkdir."
			} });
			if (res.ok) toast.success("Test mesajı göndərildi");
			else toast.error(res.error);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Göndərmə xətası");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-3xl flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted uppercase",
					children: "Mühərrik və xəbərdarlıq"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-xl font-semibold",
					children: "Ayarlar"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Stealth rejim cookie warmup, UA rotasiyası və backoff ilə TikTok-un blokunu azaldır. Datacenter IP yenə kəsilə bilər — Python paketini residential proxy ilə VPS-də işə salın."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Uğur",
						value: `${okRate}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Blok",
						value: fmtNum(stats.blocked)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Peak nəfər",
						value: fmtNum(stats.peakLiveViewers)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Sağlamlıq",
						value: health === "ok" ? "OK" : health === "cooling" ? "Backoff" : health === "blocked" ? "Blok" : "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(t.id),
					className: `h-10 rounded-md px-3 text-sm font-medium transition-colors duration-150 ${tab === t.id ? "bg-raised text-fg" : "text-muted hover:text-fg"}`,
					children: t.label
				}, t.id))
			}),
			tab === "stealth" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "Anti-blok"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Stealth rejim",
								hint: "Kiçik batch, jitter, cookie sessiyası, UA + Client Hints rotasiyası",
								checked: settings.stealthMode,
								onChange: (v) => patch({ stealthMode: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Blokda avto-yavaşla",
								hint: "403/429 dalğasında mühərrik özü backoff edir",
								checked: settings.autoPauseOnBlock,
								onChange: (v) => patch({ autoPauseOnBlock: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Səs siqnalı",
								hint: "Qutu tapılanda qısa ton",
								checked: settings.soundAlerts,
								onChange: (v) => patch({ soundAlerts: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								label: "Brauzer bildirişi",
								hint: "Növ və nəfər sayı bildiriş mətnində",
								checked: settings.browserNotify,
								onChange: (v) => {
									patch({ browserNotify: v });
									if (v) requestNotifyPermission().then((ok) => {
										if (!ok) toast.error("Bildiriş icazəsi verilmədi");
									});
								}
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "conc",
							label: "Paralel worker (Python)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "conc",
								type: "number",
								min: 4,
								max: 80,
								value: settings.concurrency,
								onChange: (e) => patch({ concurrency: clamp(Number(e.target.value) || 12, 4, 80) })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "intv",
							label: "Dövrə (ms)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "intv",
								type: "number",
								min: 2e3,
								max: 3e4,
								value: settings.intervalMs,
								onChange: (e) => patch({ intervalMs: clamp(Number(e.target.value) || 8e3, 2e3, 3e4) })
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "proxies",
								children: "Proxy siyahısı (Python)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "proxies",
								value: settings.proxiesText,
								onChange: (e) => patch({ proxiesText: e.target.value }),
								placeholder: "http://user:pass@host:port\nsocks5://host:1080",
								className: "min-h-24"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Web tarayıcı sizin brauzer IP-sindən gedir; proxy yalnız Python paketində işləyir."
							})
						]
					})
				]
			}) : null,
			tab === "telegram" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium",
					children: "Telegram"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "token",
							label: "Bot tokeni",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "token",
								type: "password",
								autoComplete: "off",
								value: settings.telegramToken,
								onChange: (e) => patch({ telegramToken: e.target.value.trim() }),
								placeholder: "123456:AA…"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: "chat",
							label: "Chat ID",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "chat",
								value: settings.telegramChatId,
								onChange: (e) => patch({ telegramChatId: e.target.value.trim() }),
								placeholder: "-100…"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							label: "Avtomatik göndər",
							hint: "Sandıq və ya hədiyyə çantası tapılanda dərhal",
							checked: settings.autoTelegram,
							onChange: (v) => patch({ autoTelegram: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => void testTelegram(),
							children: "Test mesajı göndər"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: ["Uğurlu göndəriş: ", stats.telegramOk]
						})
					]
				})]
			}) : null,
			tab === "filter" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "Xəbərdarlıq filtri"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-4 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								id: "rate",
								label: "Min rate",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "rate",
									type: "number",
									min: 0,
									step: .5,
									value: settings.minRate,
									onChange: (e) => patch({ minRate: Math.max(0, Number(e.target.value) || 0) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								id: "view",
								label: "Min nəfər",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "view",
									type: "number",
									min: 0,
									value: settings.minViewers,
									onChange: (e) => patch({ minViewers: Math.max(0, Number(e.target.value) || 0) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								id: "coins",
								label: "Min jeton",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "coins",
									type: "number",
									min: 0,
									value: settings.minCoins,
									onChange: (e) => patch({ minCoins: Math.max(0, Number(e.target.value) || 0) })
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "prio",
								children: "Prioritet unique_id"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "prio",
								value: settings.priorityText,
								onChange: (e) => patch({ priorityText: e.target.value }),
								placeholder: "ramiz_real\nzevs_show",
								className: "min-h-24"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Bu adlar hər dövrdə birinci yoxlanır."
							})
						]
					})
				]
			}) : null,
			tab === "features" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-sm font-medium",
					children: [PRODUCT_FEATURES.length, " xüsusiyyət"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 grid gap-2 sm:grid-cols-2",
					children: PRODUCT_FEATURES.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg bg-raised px-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-faint tabular-nums",
								children: String(i + 1).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm font-medium",
								children: f.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs leading-relaxed text-muted",
								children: f.detail
							})
						]
					}, f.id))
				})]
			}) : null
		]
	});
}
function Mini({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-mono text-lg tabular-nums",
			children: value
		})]
	});
}
function Field({ id, label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			htmlFor: id,
			children: label
		}), children]
	});
}
function Toggle({ label, hint, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 rounded-lg bg-raised px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: hint
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			checked,
			onCheckedChange: onChange,
			"aria-label": label
		})]
	});
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
var BOT_FILES = [
	{
		name: "config.py",
		zipPath: "sandiqradar-bot/config.py",
		content: "\"\"\"SandıqRadar konfiqurasiyası.\"\"\"\n\nfrom __future__ import annotations\n\nimport os\nfrom dataclasses import dataclass\nfrom pathlib import Path\n\nfrom dotenv import load_dotenv\n\nROOT = Path(__file__).resolve().parent\nload_dotenv(ROOT / \".env\")\n\n\ndef _int(name: str, default: int) -> int:\n    raw = os.getenv(name)\n    if raw is None or raw.strip() == \"\":\n        return default\n    return int(raw)\n\n\ndef _float(name: str, default: float) -> float:\n    raw = os.getenv(name)\n    if raw is None or raw.strip() == \"\":\n        return default\n    return float(raw)\n\n\ndef _bool(name: str, default: bool) -> bool:\n    raw = os.getenv(name)\n    if raw is None or raw.strip() == \"\":\n        return default\n    return raw.strip().lower() in {\"1\", \"true\", \"yes\", \"on\"}\n\n\n@dataclass(frozen=True, slots=True)\nclass Config:\n    telegram_bot_token: str\n    telegram_chat_id: str\n    usernames_file: Path\n    proxies_file: Path\n    check_interval: float\n    chest_poll_interval: float\n    max_concurrent: int\n    max_ws_listeners: int\n    request_timeout: float\n    min_rate: float\n    min_viewers: int\n    min_coins: int\n    jitter_sec: float\n    user_agent_rotate: bool\n    dry_run: bool\n    strict_identity: bool\n    reload_every: int\n    warmup_cookies: bool\n    stealth: bool\n\n    @classmethod\n    def load(cls) -> \"Config\":\n        token = os.getenv(\"TELEGRAM_BOT_TOKEN\", \"\").strip()\n        chat_id = os.getenv(\"TELEGRAM_CHAT_ID\", \"\").strip()\n        if not token or not chat_id:\n            raise RuntimeError(\"TELEGRAM_BOT_TOKEN və TELEGRAM_CHAT_ID .env faylında mütləqdir.\")\n        stealth = _bool(\"STEALTH\", True)\n        default_conc = 8 if stealth else 24\n        return cls(\n            telegram_bot_token=token,\n            telegram_chat_id=chat_id,\n            usernames_file=Path(os.getenv(\"USERNAMES_FILE\", str(ROOT / \"usernames.txt\"))),\n            proxies_file=Path(os.getenv(\"PROXIES_FILE\", str(ROOT / \"proxies.txt\"))),\n            check_interval=_float(\"CHECK_INTERVAL\", 8.0 if stealth else 6.0),\n            chest_poll_interval=_float(\"CHEST_POLL_INTERVAL\", 2.5),\n            max_concurrent=_int(\"MAX_CONCURRENT\", default_conc),\n            max_ws_listeners=_int(\"MAX_WS_LISTENERS\", 16),\n            request_timeout=_float(\"REQUEST_TIMEOUT\", 10.0),\n            min_rate=_float(\"MIN_RATE\", 1.0),\n            min_viewers=_int(\"MIN_VIEWERS\", 0),\n            min_coins=_int(\"MIN_COINS\", 0),\n            jitter_sec=_float(\"JITTER_SEC\", 1.8 if stealth else 1.2),\n            user_agent_rotate=_bool(\"USER_AGENT_ROTATE\", True),\n            dry_run=_bool(\"DRY_RUN\", False),\n            strict_identity=_bool(\"STRICT_IDENTITY\", True),\n            reload_every=_int(\"RELOAD_EVERY\", 8),\n            warmup_cookies=_bool(\"WARMUP_COOKIES\", True),\n            stealth=stealth,\n        )\n",
		language: "python"
	},
	{
		name: "stealth.py",
		zipPath: "sandiqradar-bot/stealth.py",
		content: "\"\"\"Brauzer kimliyi, cookie warmup və anti-blok başlıqları.\"\"\"\n\nfrom __future__ import annotations\n\nimport random\nfrom dataclasses import dataclass\n\n\n@dataclass(frozen=True, slots=True)\nclass BrowserProfile:\n    ua: str\n    sec_ch_ua: str\n    sec_ch_ua_mobile: str\n    sec_ch_ua_platform: str\n    platform: str\n    language: str\n    width: str\n    height: str\n\n\nPROFILES: tuple[BrowserProfile, ...] = (\n    BrowserProfile(\n        ua=(\n            \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 \"\n            \"(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36\"\n        ),\n        sec_ch_ua='\"Google Chrome\";v=\"131\", \"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"',\n        sec_ch_ua_mobile=\"?0\",\n        sec_ch_ua_platform='\"Windows\"',\n        platform=\"Win32\",\n        language=\"az-AZ,az;q=0.9,en-US;q=0.8,en;q=0.7\",\n        width=\"1920\",\n        height=\"1080\",\n    ),\n    BrowserProfile(\n        ua=(\n            \"Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7) AppleWebKit/605.1.15 \"\n            \"(KHTML, like Gecko) Version/18.1 Safari/605.1.15\"\n        ),\n        sec_ch_ua='\"Not A(Brand\";v=\"99\", \"Safari\";v=\"18\", \"Chromium\";v=\"130\"',\n        sec_ch_ua_mobile=\"?0\",\n        sec_ch_ua_platform='\"macOS\"',\n        platform=\"MacIntel\",\n        language=\"az-AZ,az;q=0.9,en;q=0.7\",\n        width=\"1680\",\n        height=\"1050\",\n    ),\n    BrowserProfile(\n        ua=(\n            \"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 \"\n            \"(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36\"\n        ),\n        sec_ch_ua='\"Chromium\";v=\"130\", \"Google Chrome\";v=\"130\", \"Not?A_Brand\";v=\"99\"',\n        sec_ch_ua_mobile=\"?0\",\n        sec_ch_ua_platform='\"Linux\"',\n        platform=\"Linux x86_64\",\n        language=\"en-US,en;q=0.9,az;q=0.6\",\n        width=\"1920\",\n        height=\"1200\",\n    ),\n    BrowserProfile(\n        ua=(\n            \"Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 \"\n            \"(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36\"\n        ),\n        sec_ch_ua='\"Google Chrome\";v=\"131\", \"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"',\n        sec_ch_ua_mobile=\"?1\",\n        sec_ch_ua_platform='\"Android\"',\n        platform=\"Linux armv8l\",\n        language=\"az-AZ,az;q=0.9,en-US;q=0.8\",\n        width=\"412\",\n        height=\"915\",\n    ),\n    BrowserProfile(\n        ua=\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0\",\n        sec_ch_ua='\"Not.A/Brand\";v=\"8\", \"Chromium\";v=\"131\"',\n        sec_ch_ua_mobile=\"?0\",\n        sec_ch_ua_platform='\"Windows\"',\n        platform=\"Win32\",\n        language=\"az,en-US;q=0.8,en;q=0.6\",\n        width=\"1536\",\n        height=\"864\",\n    ),\n)\n\n\ndef pick_profile() -> BrowserProfile:\n    return random.choice(PROFILES)\n\n\ndef random_device_id() -> str:\n    digits = [str(random.randint(1, 9))] + [str(random.randint(0, 9)) for _ in range(18)]\n    return \"\".join(digits)\n\n\ndef request_headers(username: str, profile: BrowserProfile, html: bool = False) -> dict[str, str]:\n    if html:\n        accept = \"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8\"\n        dest, mode = \"document\", \"navigate\"\n    else:\n        accept = \"application/json, text/html;q=0.9, */*;q=0.8\"\n        dest, mode = \"empty\", \"cors\"\n    return {\n        \"User-Agent\": profile.ua,\n        \"Accept\": accept,\n        \"Accept-Language\": profile.language,\n        \"Cache-Control\": \"no-cache\",\n        \"Pragma\": \"no-cache\",\n        \"Referer\": f\"https://www.tiktok.com/@{username}/live\" if username != \"tiktok\" else \"https://www.tiktok.com/\",\n        \"sec-ch-ua\": profile.sec_ch_ua,\n        \"sec-ch-ua-mobile\": profile.sec_ch_ua_mobile,\n        \"sec-ch-ua-platform\": profile.sec_ch_ua_platform,\n        \"sec-fetch-dest\": dest,\n        \"sec-fetch-mode\": mode,\n        \"sec-fetch-site\": \"same-origin\",\n    }\n\n\ndef web_params(profile: BrowserProfile, extra: dict[str, str]) -> dict[str, str]:\n    params = {\n        \"aid\": \"1988\",\n        \"app_name\": \"tiktok_web\",\n        \"device_platform\": \"web\",\n        \"cookie_enabled\": \"true\",\n        \"screen_width\": profile.width,\n        \"screen_height\": profile.height,\n        \"browser_language\": profile.language.split(\",\")[0],\n        \"browser_platform\": profile.platform,\n        \"browser_name\": \"Mozilla\",\n        \"browser_online\": \"true\",\n        \"timezone_name\": \"Asia/Baku\",\n        \"webcast_language\": \"az\",\n        \"app_language\": \"az\",\n    }\n    params.update(extra)\n    return params\n",
		language: "python"
	},
	{
		name: "identity.py",
		zipPath: "sandiqradar-bot/identity.py",
		content: "\"\"\"\nDəqiq istifadəçi kimliyi.\n\nTikTok unique_id böyük/kiçik hərfə həssas deyil, amma durğu (nöqtə, alt xətt)\neyni olmalıdır. Oxşar adlar (ramiz_real1) qəbul edilmir.\n\"\"\"\n\nfrom __future__ import annotations\n\nimport re\nfrom typing import Any\n\n_AT = re.compile(r\"^@+\")\n_WS = re.compile(r\"\\s+\")\n\n\ndef normalize_username(value: Any) -> str:\n    if value is None:\n        return \"\"\n    text = _WS.sub(\"\", str(value).strip())\n    text = _AT.sub(\"\", text)\n    return text.lower()\n\n\ndef usernames_match(requested: str, found: Any) -> bool:\n    a = normalize_username(requested)\n    b = normalize_username(found)\n    return bool(a) and a == b\n\n\ndef extract_unique_ids(payload: Any) -> list[str]:\n    \"\"\"Cavab JSON-undan bütün mümkün unique_id / display_id dəyərlərini çıxarır.\"\"\"\n    found: list[str] = []\n    seen: set[str] = set()\n\n    def add(val: Any) -> None:\n        name = str(val).strip() if val is not None else \"\"\n        if not name:\n            return\n        key = normalize_username(name)\n        if not key or key in seen:\n            return\n        seen.add(key)\n        found.append(name)\n\n    def walk(node: Any, depth: int = 0) -> None:\n        if depth > 8 or node is None:\n            return\n        if isinstance(node, dict):\n            for key, val in node.items():\n                lk = str(key).lower()\n                if lk in {\n                    \"uniqueid\",\n                    \"unique_id\",\n                    \"display_id\",\n                    \"displayid\",\n                    \"uniqueidstr\",\n                }:\n                    add(val)\n                elif lk in {\"user\", \"owner\", \"anchor\", \"ownerinfo\", \"userinfo\"}:\n                    walk(val, depth + 1)\n                elif isinstance(val, (dict, list)) and depth < 5:\n                    walk(val, depth + 1)\n        elif isinstance(node, list):\n            for item in node[:40]:\n                walk(item, depth + 1)\n\n    walk(payload)\n    return found\n\n\ndef identity_matches(requested: str, payload: Any) -> bool:\n    \"\"\"\n    Cavabda heç unique_id yoxdursa, endpoint username query-si ilə işləyir —\n    o zaman uyğunluq qəbul edilir. Əgər unique_id varsa, dəqiq uyğunluq şərtdir.\n    \"\"\"\n    ids = extract_unique_ids(payload)\n    if not ids:\n        return True\n    return any(usernames_match(requested, item) for item in ids)\n",
		language: "python"
	},
	{
		name: "parser.py",
		zipPath: "sandiqradar-bot/parser.py",
		content: "\"\"\"TikTok canlı otaq və sandıq/hədiyyə çantası parseri.\"\"\"\n\nfrom __future__ import annotations\n\nimport json\nimport re\nimport time\nfrom typing import Any\nfrom collections.abc import Iterable\n\nfrom identity import extract_unique_ids, usernames_match\nfrom models import BOX_KIND_LABEL, LiveRoom, TreasureBox\n\nLIVE_STATUS = {2}\n\n_BOX_HINTS = frozenset(\n    {\n        \"treasure_box\",\n        \"treasurebox\",\n        \"gift_box\",\n        \"giftbox\",\n        \"gift_bag\",\n        \"giftbag\",\n        \"lucky_box\",\n        \"luckybox\",\n        \"box_info\",\n        \"boxinfo\",\n        \"chest\",\n        \"chest_info\",\n        \"sandiq\",\n        \"activity_box\",\n        \"portal_box\",\n        \"envelope_info\",\n        \"envelop_info\",\n        \"envelope\",\n        \"envelop\",\n        \"lucky_money\",\n        \"red_packet\",\n        \"redpacket\",\n        \"box_list\",\n        \"envelope_list\",\n        \"portal\",\n        \"anchor_gift_box\",\n        \"anchorgiftbox\",\n        \"bag_info\",\n        \"lottery_box\",\n        \"split_box\",\n        \"coin_box\",\n    }\n)\n_COIN_KEYS = (\n    \"diamond_count\",\n    \"diamondcount\",\n    \"total_coins\",\n    \"totalcoins\",\n    \"reward_coins\",\n    \"coins\",\n    \"coin_count\",\n    \"coins_count\",\n    \"diamond_count_value\",\n    \"total_diamond\",\n    \"diamond\",\n    \"reward_diamond\",\n)\n_SLOT_KEYS = (\n    \"people_count\",\n    \"peoplecount\",\n    \"total_slots\",\n    \"totalslots\",\n    \"max_user\",\n    \"max_users\",\n    \"user_limit\",\n    \"join_limit\",\n    \"unpack_user_count\",\n    \"capacity\",\n    \"slots\",\n    \"max_count\",\n    \"target_user_count\",\n    \"max_people\",\n    \"people_num\",\n    \"total_people\",\n)\n_PART_KEYS = (\n    \"joined_count\",\n    \"join_count\",\n    \"current_user\",\n    \"participants\",\n    \"joined\",\n    \"participate_count\",\n    \"unpack_count\",\n    \"open_count\",\n    \"current_people\",\n    \"joined_user_count\",\n    \"now_count\",\n)\n_ID_KEYS = (\n    \"envelope_id\",\n    \"envelop_id\",\n    \"box_id\",\n    \"activity_id\",\n    \"treasure_id\",\n    \"id_str\",\n    \"id\",\n)\n_TYPE_KEYS = (\"name\", \"title\", \"type\", \"gift_name\", \"box_name\", \"desc\", \"business_type\", \"display_text\")\n_REMAIN_KEYS = (\n    \"remain_time\",\n    \"left_time\",\n    \"remain_seconds\",\n    \"countdown\",\n    \"unpack_at\",\n    \"end_time\",\n    \"expire_at\",\n)\n_SENDER_KEYS = (\"send_user_name\", \"send_username\", \"sender_name\", \"from_user\")\n_VIEWER_KEYS = (\n    \"userCount\",\n    \"user_count\",\n    \"viewer_count\",\n    \"viewerCount\",\n    \"audienceCount\",\n    \"audience_count\",\n    \"current_user_count\",\n    \"online_user_count\",\n    \"watching_count\",\n    \"display_long\",\n    \"display_value\",\n)\n\n_HYDRATION = (\n    r'<script id=\"__UNIVERSAL_DATA_FOR_REHYDRATION__\"[^>]*>(.+?)<\/script>',\n    r\"window\\['SIGI_STATE'\\]\\s*=\\s*(\\{.+?\\});\",\n    r'window\\[\"SIGI_STATE\"\\]\\s*=\\s*(\\{.+?\\});',\n    r'<script id=\"SIGI_STATE\"[^>]*>(.+?)<\/script>',\n    r'<script id=\"__NEXT_DATA__\"[^>]*>(.+?)<\/script>',\n)\n\n_CHEST_WORDS = re.compile(\n    r\"(sand[ıi]q|chest|treasure|mystery\\s*box|x[əe]zin[əe]|sunduk|hazine|сундук|treasure_box|treasurebox)\",\n    re.I,\n)\n_BAG_WORDS = re.compile(\n    r\"(çanta|canta|bag|gift\\s*bag|giftbag|lucky\\s*bag|h[əe]diyy[əe]\\s*çantas|hediye\\s*cantasi|gift_box|giftbox)\",\n    re.I,\n)\n_ENVELOPE_WORDS = re.compile(r\"(z[əe]rf|red\\s*packet|redpacket|lucky\\s*money|hongbao|红包)\", re.I)\n_LUCKY_WORDS = re.compile(r\"([şs]ans|lucky\\s*box|luckybox)\", re.I)\n_PORTAL_WORDS = re.compile(r\"\\bportal\\b\", re.I)\n\n\ndef parse_count(value: Any) -> int | None:\n    if isinstance(value, bool) or value is None:\n        return None\n    if isinstance(value, (int, float)) and value == value:\n        return max(0, int(value))\n    text = str(value).strip().replace(\" \", \"\").replace(\",\", \"\")\n    if not text:\n        return None\n    match = re.match(r\"^([\\d.]+)\\s*([kKmMbB])?$\", text)\n    if not match:\n        try:\n            return max(0, int(float(text)))\n        except (TypeError, ValueError):\n            return None\n    n = float(match.group(1))\n    unit = (match.group(2) or \"\").lower()\n    if unit == \"k\":\n        n *= 1000\n    elif unit == \"m\":\n        n *= 1_000_000\n    elif unit == \"b\":\n        n *= 1_000_000_000\n    return max(0, int(n))\n\n\ndef classify_box_kind(node: dict[str, Any]) -> tuple[str, str, int, list[str]]:\n    score = {\"chest\": 0, \"gift_bag\": 0, \"envelope\": 0, \"portal\": 0, \"lucky\": 0}\n    signals: list[str] = []\n    keys = {str(k).lower() for k in node.keys()}\n    lower = {str(k).lower(): v for k, v in node.items()}\n    texts = [str(lower.get(k, \"\")) for k in (\"name\", \"title\", \"type\", \"gift_name\", \"box_name\", \"desc\", \"display_text\")]\n    blob = \" \".join(texts + list(keys))\n\n    business = str(lower.get(\"business_type\") or lower.get(\"businesstype\") or lower.get(\"biz_type\") or \"\").strip().lower()\n    if business in {\"1\", \"user_diamond\", \"userdiamond\", \"treasure\"}:\n        score[\"chest\"] += 48\n        signals.append(\"business_type=1 (sandıq)\")\n    elif business in {\"2\", \"platform_diamond\", \"platformdiamond\", \"gift_bag\"}:\n        score[\"gift_bag\"] += 48\n        signals.append(\"business_type=2 (hədiyyə çantası)\")\n\n    env_type = str(lower.get(\"envelope_type\") or lower.get(\"envelopetype\") or lower.get(\"box_type\") or \"\").strip().lower()\n    if env_type in {\"2\", \"portal\"}:\n        score[\"portal\"] += 40\n        signals.append(\"envelope_type=portal\")\n\n    if any(\"portal_box\" in k or \"portalbox\" in k for k in keys):\n        score[\"portal\"] += 28\n        signals.append(\"portal_box sahəsi\")\n    if any(tok in k for k in keys for tok in (\"treasure_box\", \"treasurebox\", \"chest_info\", \"anchor_gift_box\")):\n        score[\"chest\"] += 22\n        signals.append(\"treasure/chest sahəsi\")\n    if any(tok in k for k in keys for tok in (\"gift_bag\", \"giftbag\", \"bag_info\", \"gift_box\", \"giftbox\")):\n        score[\"gift_bag\"] += 22\n        signals.append(\"gift bag sahəsi\")\n    if any(\"lucky_box\" in k or \"luckybox\" in k for k in keys):\n        score[\"lucky\"] += 24\n        signals.append(\"lucky_box sahəsi\")\n    if any(tok in k for k in keys for tok in (\"red_packet\", \"redpacket\", \"lucky_money\")):\n        score[\"envelope\"] += 24\n        signals.append(\"red packet sahəsi\")\n\n    if _CHEST_WORDS.search(blob):\n        score[\"chest\"] += 26\n        signals.append(\"ad: sandıq\")\n    if _BAG_WORDS.search(blob):\n        score[\"gift_bag\"] += 26\n        signals.append(\"ad: hədiyyə çantası\")\n    if _ENVELOPE_WORDS.search(blob) and \"envelope_id\" not in blob:\n        score[\"envelope\"] += 20\n        signals.append(\"ad: zərf\")\n    if _LUCKY_WORDS.search(blob) and not _BAG_WORDS.search(blob):\n        score[\"lucky\"] += 18\n        signals.append(\"ad: şans\")\n    if _PORTAL_WORDS.search(blob):\n        score[\"portal\"] += 18\n        signals.append(\"ad: portal\")\n\n    ranked = sorted(score.items(), key=lambda kv: kv[1], reverse=True)\n    best, best_score = ranked[0]\n    second = ranked[1][1] if len(ranked) > 1 else 0\n    if best_score <= 0:\n        if any(k in keys for k in (\"envelope_id\", \"envelop_id\", \"box_id\", \"treasure_id\")):\n            return \"chest\", BOX_KIND_LABEL[\"chest\"], 58, [\"standart bölünən zərf → Sandıq\"]\n        return \"unknown\", BOX_KIND_LABEL[\"unknown\"], 30, [\"zəif siqnal\"]\n    conf = min(99, 52 + best_score + min(18, best_score - second))\n    return best, BOX_KIND_LABEL[best], conf, signals\n\n\ndef parse_live_room(username: str, data: Any) -> LiveRoom | None:\n    if not isinstance(data, dict):\n        return None\n    nested = data.get(\"data\") if isinstance(data.get(\"data\"), dict) else data\n    live_room = _pick_live_room_node(nested if isinstance(nested, dict) else data)\n    if live_room is None:\n        live_room = nested if isinstance(nested, dict) else {}\n\n    status = _first_int(data, (\"status\", \"liveRoomStatus\", \"room_status\", \"live_status\"))\n    if status is None:\n        status = _first_int(live_room, (\"status\", \"live_status\", \"room_status\", \"liveRoomStatus\"))\n    is_live_flag = bool(live_room.get(\"isLive\") or live_room.get(\"is_live\")) if isinstance(live_room, dict) else False\n\n    room_id = _stringify(\n        _first(live_room, (\"roomID\", \"room_id\", \"id_str\", \"id\"))\n        or _first(nested if isinstance(nested, dict) else {}, (\"roomId\", \"room_id\", \"roomID\"))\n        or _first(data, (\"roomId\", \"room_id\"))\n    )\n    if room_id in {\"0\", \"None\", \"null\"}:\n        room_id = \"\"\n\n    live_by_status = status in LIVE_STATUS\n    if (not live_by_status and not is_live_flag) or not room_id:\n        return None\n    if status in {1, 4}:\n        return None\n\n    unique_ids = extract_unique_ids(data)\n    unique_id = next((u for u in unique_ids if usernames_match(username, u)), \"\")\n    if unique_ids and not unique_id:\n        return None\n    if not unique_id:\n        unique_id = username\n\n    viewers = _extract_viewers(live_room if isinstance(live_room, dict) else {}, nested if isinstance(nested, dict) else {})\n    title = str(_first(live_room, (\"title\", \"room_title\", \"live_room_title\")) or \"\")\n    started = _first_int(live_room, (\"start_time\", \"startTime\", \"create_time\", \"createTime\")) or 0\n    if started > 10_000_000_000:\n        started = started // 1000\n    return LiveRoom(\n        username=username,\n        unique_id=unique_id,\n        room_id=room_id,\n        viewers=max(0, viewers),\n        title=title,\n        live_url=f\"https://www.tiktok.com/@{unique_id or username}/live\",\n        exact_match=usernames_match(username, unique_id),\n        started_at=started,\n        peak_viewers=max(0, viewers),\n    )\n\n\ndef extract_hydration(html: str) -> Any | None:\n    if not html:\n        return None\n    for pat in _HYDRATION:\n        match = re.search(pat, html, re.DOTALL)\n        if not match:\n            continue\n        raw = match.group(1).strip()\n        try:\n            return json.loads(raw)\n        except json.JSONDecodeError:\n            continue\n    return None\n\n\ndef extract_treasure_box(payload: Any, room: LiveRoom) -> TreasureBox | None:\n    boxes = extract_treasure_boxes(payload, room)\n    if not boxes:\n        return None\n    return _best_box(boxes)\n\n\ndef extract_treasure_boxes(payload: Any, room: LiveRoom) -> list[TreasureBox]:\n    found: list[TreasureBox] = []\n    seen: set[str] = set()\n\n    def consider(node: dict[str, Any]) -> None:\n        if not is_active_split_box(node):\n            return\n        box = box_from_node(node, room)\n        if box is None:\n            return\n        key = box.box_id or f\"{box.kind}:{box.total_coins}:{box.total_slots}:{box.remain_sec}\"\n        if key in seen:\n            return\n        seen.add(key)\n        found.append(box)\n\n    def walk(node: Any, depth: int = 0) -> None:\n        if node is None or depth > 10:\n            return\n        if isinstance(node, dict):\n            keys = {str(k).lower() for k in node.keys()}\n            if keys & _BOX_HINTS:\n                for key, val in node.items():\n                    if str(key).lower() in _BOX_HINTS:\n                        if isinstance(val, dict):\n                            consider(val)\n                            walk(val, depth + 1)\n                        elif isinstance(val, list):\n                            for item in val:\n                                if isinstance(item, dict):\n                                    consider(item)\n                                walk(item, depth + 1)\n                consider(node)\n            elif is_active_split_box(node):\n                consider(node)\n            for val in node.values():\n                walk(val, depth + 1)\n        elif isinstance(node, list):\n            for item in node[:80]:\n                walk(item, depth + 1)\n\n    walk(payload)\n    return found\n\n\ndef box_from_node(node: dict[str, Any], room: LiveRoom) -> TreasureBox | None:\n    coins = _first_int(node, _COIN_KEYS) or 0\n    slots = _first_int(node, _SLOT_KEYS) or 0\n    if coins <= 0 or slots <= 0:\n        return None\n    parts = _first_int(node, _PART_KEYS) or 0\n    box_id = str(_first(node, _ID_KEYS) or \"\")\n    kind, label, conf, signals = classify_box_kind(node)\n    remain = _remain_sec(node)\n    sender = _sender(node)\n    return TreasureBox(\n        username=room.username,\n        room_id=room.room_id,\n        gift_type=label,\n        kind=kind,\n        confidence=conf,\n        total_coins=coins,\n        total_slots=slots,\n        participants_count=min(parts, slots) if parts else parts,\n        viewers_count=room.viewers,\n        box_id=box_id,\n        live_url=room.live_url,\n        remain_sec=remain,\n        unique_id=room.unique_id,\n        sender=sender,\n        title=room.title,\n        peak_viewers=room.peak_viewers,\n        signals=tuple(signals),\n    )\n\n\ndef is_active_split_box(node: dict[str, Any]) -> bool:\n    if not isinstance(node, dict):\n        return False\n    if _looks_gift_catalog(node):\n        return False\n    coins = _first_int(node, _COIN_KEYS)\n    slots = _first_int(node, _SLOT_KEYS)\n    if not coins or not slots or coins <= 0 or slots <= 0:\n        return False\n    keys = {str(k).lower() for k in node.keys()}\n    has_id = any(k in keys for k in (\"envelope_id\", \"envelop_id\", \"box_id\", \"treasure_id\", \"activity_id\"))\n    has_join = _first_int(node, _PART_KEYS) is not None\n    has_time = any(k in keys for k in _REMAIN_KEYS)\n    has_hint = bool(keys & _BOX_HINTS) or any(\n        token in \" \".join(keys) for token in (\"envelope\", \"envelop\", \"treasure\", \"lucky\", \"chest\", \"box\", \"bag\", \"packet\")\n    )\n    return bool(has_id or has_join or has_time or has_hint)\n\n\ndef _looks_gift_catalog(node: dict[str, Any]) -> bool:\n    keys = {str(k).lower() for k in node.keys()}\n    giftish = \"gift_id\" in keys or (\"id\" in keys and \"image\" in keys and \"name\" in keys)\n    splitish = any(\n        k in keys\n        for k in (\n            \"people_count\",\n            \"total_slots\",\n            \"envelope_id\",\n            \"box_id\",\n            \"join_count\",\n            \"joined_count\",\n        )\n    )\n    return giftish and not splitish\n\n\ndef _remain_sec(node: dict[str, Any]) -> int:\n    val = _first(node, _REMAIN_KEYS)\n    if val is None:\n        return 0\n    try:\n        n = int(val)\n    except (TypeError, ValueError):\n        return 0\n    now = int(time.time())\n    if n > now + 5:\n        return max(0, n - now)\n    if n > 10_000_000_000:\n        return max(0, n // 1000 - now)\n    return max(0, n)\n\n\ndef _sender(node: dict[str, Any]) -> str:\n    val = _first(node, _SENDER_KEYS)\n    if isinstance(val, str) and val.strip() and not val.strip().isdigit():\n        return val.strip()\n    for key in (\"send_user\", \"user\", \"sender\"):\n        user = node.get(key)\n        if isinstance(user, dict):\n            name = _first(user, (\"unique_id\", \"uniqueId\", \"nickname\", \"display_id\"))\n            if isinstance(name, str) and name.strip():\n                return name.strip()\n    return \"\"\n\n\ndef _extract_viewers(live_room: dict[str, Any], nested: dict[str, Any]) -> int:\n    n = _first_int(live_room, _VIEWER_KEYS)\n    if n is not None:\n        return n\n    stats = live_room.get(\"liveRoomStats\") if isinstance(live_room.get(\"liveRoomStats\"), dict) else None\n    if stats is None:\n        stats = live_room.get(\"stats\") if isinstance(live_room.get(\"stats\"), dict) else None\n    if isinstance(stats, dict):\n        n = _first_int(stats, _VIEWER_KEYS)\n        if n is not None:\n            return n\n        # enter_count / enterCount — ümumi giriş, cari nəfər DEYİL\n    n = _first_int(nested, _VIEWER_KEYS)\n    return n or 0\n\n\ndef _best_box(boxes: list[TreasureBox]) -> TreasureBox:\n    def key(b: TreasureBox) -> tuple[int, float, int]:\n        return (1 if b.remain_sec > 0 else 0, b.rate, b.total_coins)\n\n    return max(boxes, key=key)\n\n\ndef _pick_live_room_node(nested: Any) -> dict[str, Any] | None:\n    if not isinstance(nested, dict):\n        return None\n    for key in (\"liveRoom\", \"live_room\", \"room\", \"liveRoomInfo\", \"roomInfo\", \"room_info\"):\n        val = nested.get(key)\n        if isinstance(val, dict):\n            return val\n    return nested\n\n\ndef _first(node: dict[str, Any], keys: Iterable[str]) -> Any:\n    lower = {str(k).lower(): v for k, v in node.items()}\n    for key in keys:\n        if key.lower() in lower:\n            return lower[key.lower()]\n    return None\n\n\ndef _first_int(node: Any, keys: Iterable[str]) -> int | None:\n    if not isinstance(node, dict):\n        return None\n    return parse_count(_first(node, keys))\n\n\ndef _stringify(val: Any) -> str:\n    if val is None:\n        return \"\"\n    return str(val).strip()\n",
		language: "python"
	},
	{
		name: "models.py",
		zipPath: "sandiqradar-bot/models.py",
		content: "\"\"\"SandıqRadar məlumat modelləri.\"\"\"\n\nfrom __future__ import annotations\n\nfrom dataclasses import dataclass, field\n\n\nBoxKind = str  # chest | gift_bag | envelope | portal | lucky | unknown\n\n\nBOX_KIND_LABEL = {\n    \"chest\": \"Sandıq\",\n    \"gift_bag\": \"Hədiyyə çantası\",\n    \"envelope\": \"Zərf\",\n    \"portal\": \"Portal sandıq\",\n    \"lucky\": \"Şans qutusu\",\n    \"unknown\": \"Bölünən qutu\",\n}\n\n\n@dataclass(slots=True)\nclass LiveRoom:\n    username: str\n    unique_id: str\n    room_id: str\n    viewers: int\n    title: str = \"\"\n    live_url: str = \"\"\n    exact_match: bool = True\n    started_at: int = 0\n    peak_viewers: int = 0\n\n    def touch_viewers(self, n: int) -> None:\n        self.viewers = max(0, n)\n        if n > self.peak_viewers:\n            self.peak_viewers = n\n\n\n@dataclass(slots=True)\nclass TreasureBox:\n    username: str\n    room_id: str\n    gift_type: str\n    kind: str\n    confidence: int\n    total_coins: int\n    total_slots: int\n    participants_count: int\n    viewers_count: int\n    box_id: str = \"\"\n    live_url: str = \"\"\n    remain_sec: int = 0\n    unique_id: str = \"\"\n    sender: str = \"\"\n    title: str = \"\"\n    peak_viewers: int = 0\n    signals: tuple[str, ...] = ()\n\n    @property\n    def rate(self) -> float:\n        if self.total_slots <= 0:\n            return 0.0\n        return self.total_coins / float(self.total_slots)\n\n    @property\n    def split_label(self) -> str:\n        return f\"{self.total_coins}/{self.total_slots}\"\n\n    @property\n    def dedup_key(self) -> str:\n        if self.box_id:\n            return f\"{self.username}:{self.box_id}\"\n        return f\"{self.username}:{self.kind}:{self.total_coins}:{self.total_slots}:{self.gift_type}\"\n\n\n@dataclass(slots=True)\nclass EngineStats:\n    checks: int = 0\n    live: int = 0\n    boxes: int = 0\n    alerts: int = 0\n    mismatches: int = 0\n    http_errors: int = 0\n    blocked: int = 0\n    cycle: int = 0\n    last_error: str = \"\"\n    extra: dict[str, int] = field(default_factory=dict)\n",
		language: "python"
	},
	{
		name: "checker.py",
		zipPath: "sandiqradar-bot/checker.py",
		content: "\"\"\"Yüksək dəqiqlikli asinxron tarama mühərriki + stealth.\"\"\"\n\nfrom __future__ import annotations\n\nimport asyncio\nimport json\nimport logging\nimport random\nimport time\nfrom collections.abc import Iterable\nfrom typing import Any\nfrom urllib.parse import urlencode\n\nimport aiohttp\n\nfrom config import Config\nfrom models import EngineStats, LiveRoom, TreasureBox\nfrom parser import extract_hydration, extract_treasure_box, parse_live_room\nfrom stealth import pick_profile, random_device_id, request_headers, web_params\nfrom telegram import TelegramDispatcher\n\nlogger = logging.getLogger(\"sandiqradar.checker\")\n\n\nclass ProxyRotator:\n    def __init__(self, lines: Iterable[str]) -> None:\n        self._proxies = [ln.strip() for ln in lines if ln.strip() and not ln.strip().startswith(\"#\")]\n        self._i = 0\n\n    def next(self) -> str | None:\n        if not self._proxies:\n            return None\n        proxy = self._proxies[self._i % len(self._proxies)]\n        self._i += 1\n        return proxy\n\n    @property\n    def count(self) -> int:\n        return len(self._proxies)\n\n\nclass DuplicateGuard:\n    def __init__(self, ttl_sec: float = 900.0) -> None:\n        self._ttl = ttl_sec\n        self._seen: dict[str, float] = {}\n\n    def allow(self, key: str) -> bool:\n        now = time.monotonic()\n        self._purge(now)\n        if key in self._seen:\n            return False\n        self._seen[key] = now\n        return True\n\n    def forget_prefix(self, prefix: str) -> None:\n        drop = [k for k in self._seen if k.startswith(prefix)]\n        for k in drop:\n            del self._seen[k]\n\n    def _purge(self, now: float) -> None:\n        expired = [k for k, ts in self._seen.items() if now - ts > self._ttl]\n        for k in expired:\n            del self._seen[k]\n\n\nclass MonitorEngine:\n    def __init__(\n        self,\n        config: Config,\n        usernames: list[str],\n        telegram: TelegramDispatcher,\n        proxies: ProxyRotator,\n        session: aiohttp.ClientSession,\n        reload_usernames=None,\n    ) -> None:\n        self.config = config\n        self.usernames = usernames\n        self.telegram = telegram\n        self.proxies = proxies\n        self.session = session\n        self.reload_usernames = reload_usernames\n        self.queue: asyncio.Queue[str] = asyncio.Queue()\n        workers = config.max_concurrent\n        if config.stealth and self.proxies.count == 0:\n            workers = min(workers, 8)\n        self.sem = asyncio.Semaphore(workers)\n        self.dup = DuplicateGuard()\n        self.running = False\n        self.stats = EngineStats()\n        self._live: dict[str, LiveRoom] = {}\n        self._watchers: dict[str, asyncio.Task[None]] = {}\n        self._profile = pick_profile()\n        self._device_id = random_device_id()\n        self._backoff_until = 0.0\n        self._block_hits = 0\n\n    def _headers(self, username: str, html: bool = False) -> dict[str, str]:\n        if self.config.user_agent_rotate:\n            self._profile = pick_profile()\n        return request_headers(username, self._profile, html=html)\n\n    async def warmup(self) -> None:\n        if not self.config.warmup_cookies:\n            return\n        try:\n            timeout = aiohttp.ClientTimeout(total=self.config.request_timeout)\n            async with self.session.get(\n                \"https://www.tiktok.com/\",\n                headers=self._headers(\"tiktok\", html=True),\n                proxy=self.proxies.next(),\n                timeout=timeout,\n            ) as resp:\n                await resp.read()\n                logger.info(\"Cookie warmup: HTTP %s profile=%s\", resp.status, self._profile.platform)\n        except Exception as exc:  # noqa: BLE001\n            logger.debug(\"Cookie warmup uğursuz: %s\", exc)\n\n    async def run(self) -> None:\n        self.running = True\n        await self.warmup()\n        logger.info(\n            \"Mühərrik start: %s istifadəçi, %s paralel, %s proxy, stealth=%s, strict=%s\",\n            len(self.usernames),\n            self.config.max_concurrent,\n            self.proxies.count,\n            self.config.stealth,\n            self.config.strict_identity,\n        )\n        n_workers = self.sem._value  # noqa: SLF001\n        workers = [asyncio.create_task(self._worker(f\"w{i}\")) for i in range(max(1, n_workers))]\n        feeder = asyncio.create_task(self._feeder())\n        reaper = asyncio.create_task(self._reap_watchers())\n        reporter = asyncio.create_task(self._reporter())\n        warmer = asyncio.create_task(self._rewarm())\n        try:\n            await asyncio.gather(feeder, reaper, reporter, warmer, *workers)\n        finally:\n            self.running = False\n            for task in workers + [feeder, reaper, reporter, warmer]:\n                task.cancel()\n            for task in list(self._watchers.values()):\n                task.cancel()\n\n    async def stop(self) -> None:\n        self.running = False\n\n    async def _rewarm(self) -> None:\n        while self.running:\n            await asyncio.sleep(240)\n            self._profile = pick_profile()\n            self._device_id = random_device_id()\n            await self.warmup()\n\n    async def _feeder(self) -> None:\n        while self.running:\n            if self.stats.cycle > 0 and self.stats.cycle % max(1, self.config.reload_every) == 0:\n                if self.reload_usernames:\n                    fresh = self.reload_usernames()\n                    if fresh:\n                        self.usernames = fresh\n                        logger.info(\"Siyahı yeniləndi: %s istifadəçi\", len(fresh))\n            self.stats.cycle += 1\n            for name in list(self.usernames):\n                if not self.running:\n                    break\n                await self.queue.put(name)\n            jitter = random.uniform(0.0, self.config.jitter_sec)\n            sleep_for = self.config.check_interval + jitter\n            if time.monotonic() < self._backoff_until:\n                sleep_for = max(sleep_for, self._backoff_until - time.monotonic())\n            await asyncio.sleep(sleep_for)\n\n    async def _reporter(self) -> None:\n        while self.running:\n            await asyncio.sleep(20)\n            logger.info(\n                \"stat: yoxlama=%s canlı=%s qutu=%s xəbərdarlıq=%s uyğunsuz=%s http=%s blok=%s\",\n                self.stats.checks,\n                len(self._live),\n                self.stats.boxes,\n                self.stats.alerts,\n                self.stats.mismatches,\n                self.stats.http_errors,\n                self.stats.blocked,\n            )\n\n    async def _worker(self, label: str) -> None:\n        while self.running:\n            username = await self.queue.get()\n            try:\n                async with self.sem:\n                    if self.config.stealth:\n                        await asyncio.sleep(random.uniform(0.05, 0.35))\n                    await self._process(username)\n            except asyncio.CancelledError:\n                raise\n            except Exception as exc:  # noqa: BLE001\n                self.stats.http_errors += 1\n                self.stats.last_error = str(exc)\n                logger.debug(\"[%s] @%s xəta: %s\", label, username, exc)\n            finally:\n                self.queue.task_done()\n\n    async def _process(self, username: str) -> None:\n        self.stats.checks += 1\n        room = await self._fetch_live(username)\n        if room is None:\n            self._live.pop(username, None)\n            task = self._watchers.pop(username, None)\n            if task:\n                task.cancel()\n            return\n        if self.config.strict_identity and not room.exact_match:\n            self.stats.mismatches += 1\n            logger.info(\"Dəqiq uyğunluq yoxdur, atılır: istənilən=@%s tapılan=@%s\", username, room.unique_id)\n            return\n        prev = self._live.get(username)\n        if prev:\n            room.peak_viewers = max(prev.peak_viewers, room.viewers)\n        self._live[username] = room\n        self.stats.live = len(self._live)\n        if username not in self._watchers:\n            if len(self._watchers) >= self.config.max_ws_listeners:\n                box = await self._inspect_chest(room)\n                await self._maybe_alert(box)\n                return\n            self._watchers[username] = asyncio.create_task(self._watch_room(room))\n\n    async def _watch_room(self, room: LiveRoom) -> None:\n        username = room.username\n        logger.info(\n            \"Canlı izləmə: @%s room=%s nəfər=%s başlıq=%s\",\n            room.unique_id or username,\n            room.room_id,\n            room.viewers,\n            room.title or \"-\",\n        )\n        try:\n            used_ws = await self._watch_tiktoklive(room)\n            if used_ws:\n                return\n            while self.running and username in self._live:\n                current = self._live.get(username, room)\n                box = await self._inspect_chest(current)\n                await self._maybe_alert(box)\n                await asyncio.sleep(self.config.chest_poll_interval)\n        except asyncio.CancelledError:\n            raise\n        except Exception as exc:  # noqa: BLE001\n            logger.debug(\"@%s izləmə xətası: %s\", username, exc)\n        finally:\n            self._watchers.pop(username, None)\n            logger.info(\"Canlı izləmə bitdi: @%s\", username)\n\n    async def _reap_watchers(self) -> None:\n        while self.running:\n            await asyncio.sleep(5)\n            live_names = set(self._live)\n            for name, task in list(self._watchers.items()):\n                if name not in live_names or task.done():\n                    if not task.done():\n                        task.cancel()\n                    self._watchers.pop(name, None)\n\n    async def _maybe_alert(self, box: TreasureBox | None) -> None:\n        if box is None:\n            return\n        if box.rate < self.config.min_rate:\n            return\n        if box.viewers_count < self.config.min_viewers:\n            return\n        if box.total_coins < self.config.min_coins:\n            return\n        if not self.dup.allow(box.dedup_key):\n            return\n        self.stats.boxes += 1\n        self.stats.alerts += 1\n        logger.info(\n            \"QUTU: @%s növ=%s rate=%.2f nəfər=%s qoşulan=%s/%s id=%s etibar=%s\",\n            box.unique_id or box.username,\n            box.gift_type,\n            box.rate,\n            box.viewers_count,\n            box.participants_count,\n            box.total_slots,\n            box.box_id or \"-\",\n            box.confidence,\n        )\n        ok = await self.telegram.send_box(box)\n        if not ok:\n            logger.warning(\"Telegram göndərilmədi: @%s\", box.username)\n\n    async def _fetch_live(self, username: str) -> LiveRoom | None:\n        factories = [self._live_api_room, self._live_webcast_by_user, self._live_mobile]\n        random.shuffle(factories)\n        factories.append(self._live_html)\n        for factory in factories:\n            try:\n                room = await factory(username)\n                if room is not None:\n                    return room\n            except BlockedError:\n                self._note_block()\n            except asyncio.CancelledError:\n                raise\n            except Exception as exc:  # noqa: BLE001\n                logger.debug(\"@%s %s uğursuz: %s\", username, factory.__name__, exc)\n        return None\n\n    def _note_block(self) -> None:\n        self._block_hits += 1\n        self.stats.blocked += 1\n        delay = min(90.0, 2.0 * (2 ** min(self._block_hits, 5)))\n        self._backoff_until = max(self._backoff_until, time.monotonic() + delay)\n        self._profile = pick_profile()\n        self._device_id = random_device_id()\n        if self._block_hits in {1, 5, 15, 40}:\n            logger.warning(\"TikTok blok/429 — %.0fs yavaşlama (hit=%s)\", delay, self._block_hits)\n\n    async def _get_json(self, url: str, username: str) -> Any:\n        proxy = self.proxies.next()\n        timeout = aiohttp.ClientTimeout(total=self.config.request_timeout)\n        async with self.session.get(\n            url,\n            headers=self._headers(username),\n            proxy=proxy,\n            timeout=timeout,\n            allow_redirects=True,\n        ) as resp:\n            if resp.status in {403, 429, 503}:\n                raise BlockedError(f\"HTTP {resp.status}\")\n            if resp.status >= 400:\n                raise RuntimeError(f\"HTTP {resp.status}\")\n            ctype = resp.headers.get(\"Content-Type\", \"\")\n            if \"json\" in ctype:\n                return await resp.json(content_type=None)\n            text = await resp.text()\n            try:\n                return json.loads(text)\n            except json.JSONDecodeError:\n                return {\"_html\": text}\n\n    async def _live_api_room(self, username: str) -> LiveRoom | None:\n        params = web_params(self._profile, {\"uniqueId\": username, \"sourceType\": \"54\"})\n        url = \"https://www.tiktok.com/api-live/user/room/?\" + urlencode(params)\n        data = await self._get_json(url, username)\n        return parse_live_room(username, data)\n\n    async def _live_webcast_by_user(self, username: str) -> LiveRoom | None:\n        url = (\n            \"https://webcast.tiktok.com/webcast/room/info_by_user/\"\n            f\"?aid=1988&unique_id={username}&device_id={self._device_id}\"\n        )\n        data = await self._get_json(url, username)\n        return parse_live_room(username, data)\n\n    async def _live_mobile(self, username: str) -> LiveRoom | None:\n        url = f\"https://m.tiktok.com/api-live/user/room/?aid=1988&sourceType=54&uniqueId={username}\"\n        data = await self._get_json(url, username)\n        return parse_live_room(username, data)\n\n    async def _live_html(self, username: str) -> LiveRoom | None:\n        url = f\"https://www.tiktok.com/@{username}/live\"\n        proxy = self.proxies.next()\n        timeout = aiohttp.ClientTimeout(total=self.config.request_timeout)\n        async with self.session.get(\n            url, headers=self._headers(username, html=True), proxy=proxy, timeout=timeout\n        ) as resp:\n            if resp.status in {403, 429, 503}:\n                raise BlockedError(f\"HTTP {resp.status}\")\n            html = await resp.text()\n        blob = extract_hydration(html)\n        if blob is None:\n            return None\n        return parse_live_room(username, blob)\n\n    async def _inspect_chest(self, room: LiveRoom) -> TreasureBox | None:\n        urls = [\n            f\"https://webcast.tiktok.com/webcast/room/info/?aid=1988&room_id={room.room_id}&device_id={self._device_id}\",\n            f\"https://webcast.tiktok.com/webcast/room/enter/?aid=1988&room_id={room.room_id}\",\n            f\"https://webcast.tiktok.com/webcast/envelope/list/?aid=1988&room_id={room.room_id}\",\n        ]\n        for url in urls:\n            try:\n                data = await self._get_json(url, room.username)\n            except BlockedError:\n                self._note_block()\n                continue\n            except Exception as exc:  # noqa: BLE001\n                logger.debug(\"otaq info @%s: %s\", room.username, exc)\n                continue\n            box = extract_treasure_box(data, room)\n            if box:\n                return box\n        return None\n\n    async def _watch_tiktoklive(self, room: LiveRoom) -> bool:\n        try:\n            from TikTokLive import TikTokLiveClient  # type: ignore\n            from TikTokLive.events import DisconnectEvent, GiftEvent, LiveEndEvent  # type: ignore\n        except Exception:\n            return False\n\n        envelope_cls = None\n        try:\n            from TikTokLive.events import EnvelopeEvent  # type: ignore\n\n            envelope_cls = EnvelopeEvent\n        except Exception:\n            envelope_cls = None\n\n        client = TikTokLiveClient(unique_id=room.unique_id or room.username)\n        done = asyncio.Event()\n\n        @client.on(GiftEvent)\n        async def _on_gift(event: Any) -> None:  # noqa: ANN401\n            gift = getattr(event, \"gift\", None)\n            name = str(getattr(gift, \"name\", \"\") or \"\")\n            lowered = name.lower()\n            if not any(\n                k in lowered\n                for k in (\"box\", \"chest\", \"treasure\", \"bag\", \"sandıq\", \"sandiq\", \"çanta\", \"envelope\", \"lucky\")\n            ):\n                return\n            http_box = await self._inspect_chest(self._live.get(room.username, room))\n            if http_box:\n                await self._maybe_alert(http_box)\n\n        if envelope_cls is not None:\n\n            @client.on(envelope_cls)\n            async def _on_env(event: Any) -> None:  # noqa: ANN401\n                info = (\n                    getattr(event, \"envelope_info\", None)\n                    or getattr(event, \"info\", None)\n                    or getattr(event, \"envelop_info\", None)\n                    or {}\n                )\n                node = info if isinstance(info, dict) else _obj_to_dict(info)\n                http_box = await self._inspect_chest(self._live.get(room.username, room))\n                if http_box:\n                    await self._maybe_alert(http_box)\n                    return\n                if not isinstance(node, dict):\n                    return\n                box = extract_treasure_box({\"envelope_info\": node}, self._live.get(room.username, room))\n                await self._maybe_alert(box)\n\n        @client.on(DisconnectEvent)\n        async def _on_disc(_: Any) -> None:  # noqa: ANN401\n            done.set()\n\n        @client.on(LiveEndEvent)\n        async def _on_end(_: Any) -> None:  # noqa: ANN401\n            done.set()\n\n        try:\n            await client.start()\n            while self.running and room.username in self._live and not done.is_set():\n                http_box = await self._inspect_chest(self._live.get(room.username, room))\n                await self._maybe_alert(http_box)\n                try:\n                    await asyncio.wait_for(done.wait(), timeout=self.config.chest_poll_interval)\n                except asyncio.TimeoutError:\n                    pass\n        finally:\n            try:\n                await client.disconnect()\n            except Exception:\n                pass\n        return True\n\n\nclass BlockedError(RuntimeError):\n    pass\n\n\ndef _obj_to_dict(obj: Any) -> dict[str, Any]:\n    if obj is None:\n        return {}\n    if isinstance(obj, dict):\n        return obj\n    data: dict[str, Any] = {}\n    for key in dir(obj):\n        if key.startswith(\"_\"):\n            continue\n        try:\n            val = getattr(obj, key)\n        except Exception:\n            continue\n        if callable(val):\n            continue\n        data[key] = val\n    return data\n",
		language: "python"
	},
	{
		name: "telegram.py",
		zipPath: "sandiqradar-bot/telegram.py",
		content: "\"\"\"Asinxron Telegram xəbərdarlıq göndəricisi.\"\"\"\n\nfrom __future__ import annotations\n\nimport asyncio\nimport logging\nfrom typing import Any\n\nimport aiohttp\n\nfrom config import Config\nfrom models import TreasureBox\n\nlogger = logging.getLogger(\"sandiqradar.telegram\")\n\nTELEGRAM_API = \"https://api.telegram.org\"\n\n\ndef _md(text: str) -> str:\n    return (\n        str(text)\n        .replace(\"\\\\\", \"\\\\\\\\\")\n        .replace(\"_\", \"\\\\_\")\n        .replace(\"*\", \"\\\\*\")\n        .replace(\"`\", \"\\\\`\")\n        .replace(\"[\", \"\\\\[\")\n    )\n\n\ndef _fmt_num(n: int) -> str:\n    return f\"{int(n):,}\".replace(\",\", \" \")\n\n\ndef format_alert(box: TreasureBox) -> str:\n    rate = box.rate\n    rate_label = str(int(rate)) if rate == int(rate) else f\"{rate:.2f}\"\n    handle = box.unique_id or box.username\n    url = box.live_url or f\"https://www.tiktok.com/@{handle}/live\"\n    remain = f\"\\n⏱ **Qalan vaxt:** {box.remain_sec} san\" if box.remain_sec > 0 else \"\"\n    title = f\"\\n📺 **Yayım:** {_md(box.title)}\" if box.title else \"\"\n    sender = f\"\\n✍️ **Göndərən:** @{_md(box.sender)}\" if box.sender else \"\"\n    conf = f\"\\n🎯 **Növ etibarı:** {box.confidence}%\" if box.confidence else \"\"\n    peak = \"\"\n    if box.peak_viewers and box.peak_viewers > box.viewers_count:\n        peak = f\" (peak {_fmt_num(box.peak_viewers)})\"\n    return (\n        \"🚨 **CANLI VƏ QUTU TAPILDI!** 🚨\\n\"\n        \"\\n\"\n        f\"👤 **İstifadəçi:** @{_md(handle)}\\n\"\n        f\"🎁 **Növ:** {_md(box.gift_type)}\\n\"\n        f\"👀 **Canlıda nəfər:** {_fmt_num(box.viewers_count)}{peak}\\n\"\n        f\"📊 **Bölgü:** {box.total_coins}/{box.total_slots} jeton/yer\\n\"\n        f\"💎 **Rate:** {rate_label} jeton/nəfər\\n\"\n        f\"👥 **Qutuya qoşulan:** {_fmt_num(box.participants_count)} / {_fmt_num(box.total_slots)} nəfər\"\n        f\"{title}{sender}{remain}{conf}\\n\"\n        f\"🔗 **Canlı yayım:** [Yayıma Keç]({url})\"\n    )\n\n\nclass TelegramDispatcher:\n    def __init__(self, config: Config, session: aiohttp.ClientSession) -> None:\n        self._config = config\n        self._session = session\n        self._lock = asyncio.Lock()\n\n    async def test_connection(self) -> bool:\n        url = f\"{TELEGRAM_API}/bot{self._config.telegram_bot_token}/getMe\"\n        try:\n            async with self._session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:\n                payload: dict[str, Any] = await resp.json(content_type=None)\n                if payload.get(\"ok\"):\n                    username = payload.get(\"result\", {}).get(\"username\", \"?\")\n                    logger.info(\"Telegram botu hazırdır: @%s\", username)\n                    return True\n                logger.error(\"Telegram getMe uğursuz: %s\", payload)\n                return False\n        except Exception as exc:  # noqa: BLE001\n            logger.error(\"Telegram bağlantı xətası: %s\", exc)\n            return False\n\n    async def send_box(self, box: TreasureBox) -> bool:\n        if self._config.dry_run:\n            logger.info(\"[DRY-RUN] Qutu: @%s növ=%s rate=%.2f\", box.username, box.gift_type, box.rate)\n            return True\n        return await self.send_text(format_alert(box))\n\n    async def send_text(self, text: str) -> bool:\n        url = f\"{TELEGRAM_API}/bot{self._config.telegram_bot_token}/sendMessage\"\n        body = {\n            \"chat_id\": self._config.telegram_chat_id,\n            \"text\": text,\n            \"parse_mode\": \"Markdown\",\n            \"disable_web_page_preview\": False,\n        }\n        async with self._lock:\n            delay = 0.05\n            for attempt in range(1, 4):\n                try:\n                    async with self._session.post(\n                        url,\n                        json=body,\n                        timeout=aiohttp.ClientTimeout(total=12),\n                    ) as resp:\n                        payload: dict[str, Any] = await resp.json(content_type=None)\n                        if payload.get(\"ok\"):\n                            return True\n                        if resp.status == 429:\n                            retry_after = float(payload.get(\"parameters\", {}).get(\"retry_after\", 2))\n                            logger.warning(\"Telegram 429 — %.1fs gözlənilir\", retry_after)\n                            await asyncio.sleep(retry_after)\n                            continue\n                        logger.error(\"Telegram xətası: %s\", payload.get(\"description\"))\n                        return False\n                except Exception as exc:  # noqa: BLE001\n                    logger.warning(\"Telegram cəhd %s uğursuz: %s\", attempt, exc)\n                    await asyncio.sleep(delay)\n                    delay *= 2\n        return False\n",
		language: "python"
	},
	{
		name: "main.py",
		zipPath: "sandiqradar-bot/main.py",
		content: "\"\"\"SandıqRadar — giriş nöqtəsi.\"\"\"\n\nfrom __future__ import annotations\n\nimport asyncio\nimport logging\nimport signal\nimport sys\nfrom pathlib import Path\n\nimport aiohttp\n\nfrom checker import MonitorEngine, ProxyRotator\nfrom config import Config\nfrom identity import normalize_username\nfrom telegram import TelegramDispatcher\n\nlogging.basicConfig(\n    level=logging.INFO,\n    format=\"%(asctime)s | %(levelname)-7s | %(name)s | %(message)s\",\n    datefmt=\"%H:%M:%S\",\n)\nlogger = logging.getLogger(\"sandiqradar\")\n\n\ndef load_lines(path: Path) -> list[str]:\n    if not path.exists():\n        return []\n    names: list[str] = []\n    seen: set[str] = set()\n    for raw in path.read_text(encoding=\"utf-8\").splitlines():\n        line = raw.strip()\n        if not line or line.startswith(\"#\"):\n            continue\n        item = line.lstrip(\"@\").split()[0].strip()\n        key = normalize_username(item)\n        if key and key not in seen:\n            seen.add(key)\n            names.append(item)\n    return names\n\n\nasync def amain() -> int:\n    try:\n        config = Config.load()\n    except RuntimeError as exc:\n        logger.error(\"%s\", exc)\n        return 2\n\n    def reload_names() -> list[str]:\n        return load_lines(config.usernames_file)\n\n    usernames = reload_names()\n    if len(usernames) < 1:\n        logger.error(\n            \"İstifadəçi siyahısı boşdur. %s faylına hər sətirdə bir dəqiq username yazın.\",\n            config.usernames_file,\n        )\n        return 2\n\n    proxies = ProxyRotator(load_lines(config.proxies_file) if config.proxies_file.exists() else [])\n    timeout = aiohttp.ClientTimeout(total=config.request_timeout)\n    jar = aiohttp.CookieJar(unsafe=True)\n    connector = aiohttp.TCPConnector(\n        limit=max(32, config.max_concurrent * 2),\n        ttl_dns_cache=300,\n        enable_cleanup_closed=True,\n        ssl=True,\n    )\n\n    logger.info(\n        \"Hazırlıq: %s dəqiq kanal, interval=%.1fs, paralel=%s, stealth=%s, min_rate=%.2f\",\n        len(usernames),\n        config.check_interval,\n        config.max_concurrent,\n        config.stealth,\n        config.min_rate,\n    )\n\n    async with aiohttp.ClientSession(timeout=timeout, connector=connector, cookie_jar=jar) as session:\n        telegram = TelegramDispatcher(config, session)\n        if not await telegram.test_connection():\n            logger.error(\"Telegram botu cavab vermir — token/chat_id yoxlanılsın.\")\n            return 3\n        engine = MonitorEngine(\n            config,\n            usernames,\n            telegram,\n            proxies,\n            session,\n            reload_usernames=reload_names,\n        )\n\n        loop = asyncio.get_running_loop()\n        stop_event = asyncio.Event()\n\n        def _ask_stop() -> None:\n            logger.info(\"Dayandırma siqnalı alındı…\")\n            engine.running = False\n            stop_event.set()\n\n        for sig in (signal.SIGINT, signal.SIGTERM):\n            try:\n                loop.add_signal_handler(sig, _ask_stop)\n            except NotImplementedError:\n                pass\n\n        runner = asyncio.create_task(engine.run())\n        waiter = asyncio.create_task(stop_event.wait())\n        done, pending = await asyncio.wait({runner, waiter}, return_when=asyncio.FIRST_COMPLETED)\n        engine.running = False\n        for task in pending:\n            task.cancel()\n        if runner in done:\n            exc = runner.exception()\n            if exc:\n                logger.exception(\"Mühərrik xətası: %s\", exc)\n                return 1\n    logger.info(\"SandıqRadar dayandı.\")\n    return 0\n\n\ndef main() -> None:\n    try:\n        code = asyncio.run(amain())\n    except KeyboardInterrupt:\n        code = 0\n    sys.exit(code)\n\n\nif __name__ == \"__main__\":\n    main()\n",
		language: "python"
	},
	{
		name: "requirements.txt",
		zipPath: "sandiqradar-bot/requirements.txt",
		content: "aiohttp>=3.9.1\naiohttp-socks>=0.9.0\npython-dotenv>=1.0.1\norjson>=3.10.0\n# İxtiyari — WebSocket sandıq dinləməsi üçün:\n# TikTokLive>=6.4.0\n",
		language: "text"
	},
	{
		name: ".env.example",
		zipPath: "sandiqradar-bot/.env.example",
		content: "TELEGRAM_BOT_TOKEN=123456789:AA-your-bot-token\nTELEGRAM_CHAT_ID=-1001234567890\nSTEALTH=true\nCHECK_INTERVAL=8\nCHEST_POLL_INTERVAL=2.5\nMAX_CONCURRENT=8\nMAX_WS_LISTENERS=16\nREQUEST_TIMEOUT=10\nMIN_RATE=1\nMIN_VIEWERS=0\nMIN_COINS=0\nJITTER_SEC=1.8\nUSER_AGENT_ROTATE=true\nDRY_RUN=false\nSTRICT_IDENTITY=true\nRELOAD_EVERY=8\nWARMUP_COOKIES=true\nUSERNAMES_FILE=usernames.txt\nPROXIES_FILE=proxies.txt\n",
		language: "text"
	},
	{
		name: "usernames.txt",
		zipPath: "sandiqradar-bot/usernames.txt",
		content: "# Həqiqi izləmə siyahısı — hər sətirdə bir dəqiq TikTok unique_id.\n# @ işarəsi olsa da olar. Böyük/kiçik hərf fərqi yoxdur, durğu eynidir.\nw777789\nincirteroristiayan\njungminjaeda\nversace76_\naldim_ve_getdim\nshunshun1130\nlun_shao\nalgorithmtechschool\nzevs_show\nyoussef.iioq0\ntyt_mixa_tyta\nandreaprisco.22\nkeremuner\nelsevervusal\nsawyerthomson0\ntjr_tradez\nitslucasgracia\nddine_sz\ntn_20606\nmrsfazlieva\nclaudiasonson5\nberdeavto100yedek\nmulletmafia747\ntekiso0929\nrehim163\ncindysiclaudia\nadda88a\ndragonduu124\ntasbsjsk2\nuser4532882334\nfantasy4lifemain\nksummm888\nberdosik5757\noz.92k\n2tthang\neugeniaup\nblue_blue2911\naras_0791gmail\npetch_itthi\naraki_muscle\ntumz0202\nbahri813\n35___54\nchinami118\nninaketaren\nponpokorin311\nkazutan1116\nluz.deyling.flores\nipelex1\nalmor3eba\nskorpik3456899\nleoalcy\nchaaithuong\nbaiibaifernfern\ninuinuinuvu\nrodrigo_ganem\naot_suta\nsion..0502\n188168yy\naylie505\nquianna.nana\nsakura37.m\nuseryurino_0111\nmomiji..ll\nyusqa.97\ny_w_o_o\nl_ibra85\nprannn\nshnookie_x\nsapa.caryyew1\nrupia_zard\nmeronchan19\nmiiiiiin06\nthinasuke\nlaudyismail888\nkizunatti111\nazizulhelm1\njunt120\nnazym_sw_\nceys.34\n90d9g\ncolestytan\nactor_2kang\nrunrun652\nmandiecane_\nbanadokunma96\nmyunx_o0\ntaryel9.9.9\nkay7xisking\nogdvbhf\nuser3413536268610\ndygw2p6cm831\nnanashiki_ry1\nvitormagalh_\nfegermadid32j4zo\nuser1396166918477\nstayblessmusic\nallahqorusun099\nweare.vixen_\nya096i1\nrinrinrin03040\nlsywa1\nmummaof6girls2boys\ndyih0wd8ibmh\nzen___j\nsaikonausagichan\nkuro_969698\nlinxi1114888\niam.kath0\nvvchamavv\naunny_anchali\nedoss580\nyujiho7778\ntaroutoki701\ns_gg019\nd819697\nsena344646\ndachanuda\ndothanhbinh2512\nh.dieu_ancut\ndavidnachtham\nmisa__3311\ndydnlmk1vlr4\nduy.c3620\nnhatkhang12341\nforeverloveyourself4\nxin_nhe_cai_top36\nluctrungquan4\nluonghung.04\nhind.x1992\nateliedalolaibitinga\njaoaornurse\ndong__gi\nin26222595\ndanielhunt88\nmopkil\ni3rara\no5__yya\nbeppu_chan\nashleyp890\nhono.1225\nhoruslives\nmarinka14023\nninikang2\nuserdaidaidaidayo\nhongyeu371\nthin1211s\n88_gayush_88\nsasha13.1\nobirmardinli_47_\nanhtiktokdepzaittacckhoe\ntqd305\nshisha44free\nxinyu_316\nliliana.591\nsparkie.boy04\nv.hxy_0227\nbatea84\nhazuki.sumile\nchywv5\njavidd26\npopeye_5268\n1__7__m\nu.uura\nmarumaru6710\ninvestidor_007\nk7__7\narmine.dawtyan\ntduongg1908\nmayu_129_manapanda\ntakutok25\nya.02\nn.a.r.e22.22\nitzarhneetar\nfaynyy.pan\ndek7miopd\njiiko03270\nfroggysparklesmain1\nbudbudsabong797\ndoss_251\nyoungju2\nzhizhi0117\nuser2323563367\nliveeveryday.np\nboz_qurt37\nfan.fan378\nusername1114556\nacimasiz02636229\nhrrem.sultan3151\n7nihadd\ngeldim.vurdum.01\nyap10_geri_qayitdi\nshtormichik\nvaqodu_0001\nahhmantapp_crott\nredbullaz\nzver_on\nekberows_her_yerde1\nramiz_real\nfmva9\nposta.com.tr\nheyvan_dunyasi12\nskuter_samokat\nnizami1022\n01anaf01\nwolt_azerbaijan\ne6srider\nn1toys0\nmehhmetdragos\namchefdemisto\njooe907\ndanielstefu10\nnm_livepro\nqueenmalik829\nmr.barberuslan\nofficialmoustafamansour\nglobal1joe\nthom_babyy\nanul__01\nlomii733\ntonystark060489\neltorquee\nlongxucxich.tuongot\nh_kyung_176\nlady.546\nabusaif7070\naziz1990m1\nedelinmathernature\nrlkjota717\ncrvglopes98\nmadz_l24\nmaa.0510\ngeycikhaleesi\ncaiquizadaa\nluizx7\nzezev99\nnuriiyev11\ntheusjosee\nviniproducoesmusicais\nhugorodelomusica\ndaa_on\nbubbles0042\nricopin828\ncalm_lake223\njjangbbae\narin_960520\nn..n789\nazzamusicofficial\naisha.10tn\ntannarll\nbb_bbb_ultimate\nadrianilies606\nmusic_journey_01\nsasticateaud\nfinc.mafia\nmcjehda6_\nricxrdo.04\niishaaa_______\nvit.r___\nsokun0703\nharbisari\nneno..2727\nmrsaitamavk2\njoowon2103\nrichtzu888\nludere_deorum\nozune_hormet_qoy\ngaarlic0921\nkitty.na2\nryuji5_9\nleoopostal\nphil102545\nice3330120\nitsme.chads\naussieveteran90\nbrunasaltorio\nyuki_vrcats\nkai_da75\nsupermum8_tt\ndonald_duck.1934.6.9\nmaurogmerican\nqamarl07\niulianamatei86\ntanesiinci\ntullo.ostilio.82\nchrixxxferr\nbee9191\nmarvin_parcutilovibes\ntheodoresikiri\njussyercarvalho\nskgotcha\nminhhieudepzaicogisai\nqaraqiz_1111\nahmed_optimist\nm.martinez0417\nosmantu079\nhoanthien2608\ncakaufa_magelang\nahmadsan33\nalmajhool201\nal1000l00\nraflesia074\ncristina.23677\nalessia_nare\ndana_mvp\nmarochinoomochi\nchronos_luka\nbismillahkunfayakun23\ndilaracimss\nasem.dwairi\nksiyytw\nstarim.0\ngoktugkaynarr\nk965h\nnixon.3a21\nanukunwar6\nmarino1220\nvi_ew55\nheyyimvv\nbelimeatimieludepasti\nanimal.hisaashii\nal9saqr\nbastichillma_official\nhasank55\ncamilacorsinooo\nluccas.valentine\nmicrop_\nmrdubaitop1\nsevgimsen111_\nmidaswellquit\nilovetoptop93\naainn_621\nmu_mu_mumumu\nstarbuc37\nkaurato3\n89shota89\nmaaami124\nklauslove\nshotaccc\n.qara_010\nzerosei_06\nmachiko.sensei\ndr.account.xxx\nsoltan.usa\nlookoutsnipe\ncihan.ahnas4\nnermanov_313\n5mooii\nml212\ndunghelthy8\nhardcorrider01\nviroza_1\nnosinger487\nlitoriacaerulea\nuser377945497\nstar_universe_ever\normankrallarii\ncourtneyfok\nnodypc\ndaniel_wiwatwong\nmijoo_lovely\nbordobrli47\nkatsudonchan1\nthachkieu10.02\nuser_edit6660\ntoshi_0042\nemi_ocagi\nmostfamahmod11\nnasa_nebunilor\nhenz_construction\nninelli09\ndekdiyah1\ngabbycarina\nhurdaci01.34\ntherebel937\ndianamihali0\ndanielkrusee\nzusminero\nabbasalbloushivip\n925ayar\nbrutall_2.0\nmialily.jp\nneoesram\nchipomiru\nzegkhv2030\nindry_yuhuuu\nvuong36au_2\naure_lian22222\nerenn8690\nuserodukh76aec\ncristinacristina664\nuser_13.alb_pe_negru\nelnur___071\nmemmedova_roya_\nraskon..m\nuser79014385\nmehmetcengizank1\nzorilaionpaul\nagalokbatanlimahnilar\nmuhammed_glmsr34\nbrunetykaa\n..ddelviago\nahmed_ali1_4\n1dazel\nmaskelihatun49\ncandanote4142\ngal_x77\nw65m\nalia_btp19\nkrieim34\nendjulia_\nson33.4\nloaysokker\nchinho.tm\na.e..001\neliyev0555\nomarelnawawy96\nay_nuray_045\nemilaghyv\nferahimkarimxanli\nelen.111_\nby_kamran_\nm7md.tv\nko..056\nhadi.hr1\ndevrim_47\nmrmoldovan\npsiholog.antonia\nlafrandjaxerie\nrzayevbehruz048\nkaradayi78\nbomiiibomiii1\nhangi_ferit\nmalak1a62\nbodaaa5atar\npablokiss24\nviroza_00\nandorre01\natakishiev_97\nsngabo6\nayxangeldi.44\nhab.123h.3\nmemmedov8273\nmr_lequar_aldima\nddo__xi1\nkotobuki.twk\nclosednaw\nnatan0326nn210\nmuammerabrahams74\nsoli_moli888\njhonnathanmerchan\nlelinho255\nsilasoil\nlachocolatebiencuidada\nmhamedahmdd\nkemo___313\nannefloor10\ncj7.502\nvankhanhkdzz\nmarrenta973\nboopbianx\njandersonluis07\nmizberesford007\njayvionthefront\nnwa_milk05\nsoyelmicko\nthescyyx\ngaucho.do.tik.tok\nrosariopsq\nwwa5.23\nmorningstar_rj\nnurllahy\na.zanza0\nanadodo884\nnehir_3434nn\npapipopu____\nalshaahin03\np.pimmo236\nsadecekubos\nhiatus.duluu\nwelorax._\nellaaeyo\nsamicadenaa\ndragon_king_1989\n3amo.samy.king0fgame\nam_an206\ndselinkose\n.szandika\ndjandik8\nyayinciogretmen1\nlive.streaming.se\ngoodybagtreasurebox\nsultanofcoin\ntambahfollowers.live\ncoinkrewe\ntakipyayini0000\ntangkapfollowers.live\nsupportfollowerslive\ngrowup.followers\ncoin.10.0004\ncoin10.0001\nupfollowersaffiliatefyp\ntangkap.mining.followers\nromantik.haydut\nitalia__10\nahmadbakr7354\nwepstore_567\ntheking_moha\nvv9i\n.yeraz_111\n.mm...56\nfarid444\ntopdanoyuncaq.absheron\n728.m\nikrxllw\nlika_lik123\nniko__654\nboss_30\nobeliks___\nrusiya0117\naha.budefe.apardim_1\noanhkieule818\nqaqas_5551\nagacanbakii\nrick_grimes66\nshatoburian_sato\n",
		language: "text"
	},
	{
		name: "proxies.txt",
		zipPath: "sandiqradar-bot/proxies.txt",
		content: "# Hər sətirdə bir proxy. Boş qala bilər — o halda birbaşa çıxış.\n# Nümunə:\n# http://user:pass@1.2.3.4:8080\n# socks5://1.2.3.4:1080\n",
		language: "text"
	},
	{
		name: "README.md",
		zipPath: "sandiqradar-bot/README.md",
		content: "# SandıqRadar — dəqiq canlı sandıq / hədiyyə çantası botu\n\nHəqiqi TikTok unique_id siyahısını rəsmi API-siz tarayan mühərrik.\nYalnız **dəqiq eyni istifadəçi adı** canlıdırsa və aktiv **sandıq** və ya\n**hədiyyə çantası** varsa Telegram-a Azərbaycan dilində xəbərdarlıq göndərir.\n\n## Dəqiqlik\n\n- `uniqueId` eyni olmalıdır (`ramiz_real1` keçmir).\n- Yalnız `status=2` canlıdır.\n- Növ: `business_type=1` → **Sandıq**, `business_type=2` → **Hədiyyə çantası**.\n- Canlıdakı nəfər = cari `user_count` (enter_count ümumi girişdir, götürülmür).\n- Duplicate: eyni `box_id` bir dəfə.\n- Rate = jeton / yer.\n\n## Anti-blok (STEALTH=true)\n\n- Cookie warmup (`ttwid` sessiyası)\n- UA + Client Hints rotasiyası\n- Təsadüfi `device_id`\n- 403/429-da eksponensial backoff\n- Proxy yoxdursa paralel worker 8-ə enir\n- Residential proxy (`proxies.txt`) tövsiyə olunur — datacenter IP kəsilir\n\n## Qurulum\n\n```bash\npython -m venv .venv\nsource .venv/bin/activate\npip install -r requirements.txt\ncp .env.example .env\n```\n\n`.env` içində token və chat ID doldurun. İstəyə görə: `pip install TikTokLive`\n\n```bash\npython main.py\npython test_parser.py\n```\n\nDayandırmaq: `Ctrl+C`.\n",
		language: "markdown"
	}
];
function crc32(data) {
	let crc = 4294967295;
	for (let i = 0; i < data.length; i += 1) {
		crc ^= data[i] ?? 0;
		for (let j = 0; j < 8; j += 1) crc = crc >>> 1 ^ (crc & 1 ? 3988292384 : 0);
	}
	return crc ^ 4294967295;
}
function u16(n) {
	const b = /* @__PURE__ */ new Uint8Array(2);
	new DataView(b.buffer).setUint16(0, n, true);
	return b;
}
function u32(n) {
	const b = /* @__PURE__ */ new Uint8Array(4);
	new DataView(b.buffer).setUint32(0, n, true);
	return b;
}
function concat(parts) {
	const len = parts.reduce((s, p) => s + p.length, 0);
	const out = new Uint8Array(len);
	let o = 0;
	for (const p of parts) {
		out.set(p, o);
		o += p.length;
	}
	return out;
}
function makeZip(files) {
	const enc = new TextEncoder();
	const locals = [];
	const centrals = [];
	let offset = 0;
	for (const file of files) {
		const name = enc.encode(file.name);
		const data = enc.encode(file.content);
		const crc = crc32(data);
		const local = concat([
			u32(67324752),
			u16(20),
			u16(0),
			u16(0),
			u16(0),
			u16(0),
			u32(crc),
			u32(data.length),
			u32(data.length),
			u16(name.length),
			u16(0),
			name,
			data
		]);
		const central = concat([
			u32(33639248),
			u16(20),
			u16(20),
			u16(0),
			u16(0),
			u16(0),
			u16(0),
			u32(crc),
			u32(data.length),
			u32(data.length),
			u16(name.length),
			u16(0),
			u16(0),
			u16(0),
			u16(0),
			u32(0),
			u32(offset),
			name
		]);
		locals.push(local);
		centrals.push(central);
		offset += local.length;
	}
	const centralDir = concat(centrals);
	const end = concat([
		u32(101010256),
		u16(0),
		u16(0),
		u16(files.length),
		u16(files.length),
		u32(centralDir.length),
		u32(offset),
		u16(0)
	]);
	const bytes = concat([
		...locals,
		centralDir,
		end
	]);
	const buf = new ArrayBuffer(bytes.byteLength);
	new Uint8Array(buf).set(bytes);
	return new Blob([buf], { type: "application/zip" });
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
function CodeView() {
	const [active, setActive] = (0, import_react.useState)(BOT_FILES[0]?.name ?? "config.py");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const file = (0, import_react.useMemo)(() => BOT_FILES.find((f) => f.name === active) ?? BOT_FILES[0], [active]);
	function downloadZip() {
		downloadBlob(makeZip(BOT_FILES.map((f) => ({
			name: f.zipPath,
			content: f.content
		}))), "sandiqradar-bot.zip");
		toast.success("Python paketi yükləndi");
	}
	async function copy() {
		if (!file) return;
		await navigator.clipboard.writeText(file.content);
		setCopied(true);
		window.setTimeout(() => setCopied(false), 1400);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted uppercase",
					children: "Python mühərriki"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-xl font-semibold",
					children: "Tam mənbə kodu"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted",
					children: "Stealth cookie, UA rotasiyası, dəqiq unique_id, status=2, sandıq vs hədiyyə çantası təsnifatı, cari nəfər sayı və Telegram. Öz VPS-də `python main.py`."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: downloadZip,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "ZIP yüklə"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 overflow-x-auto border-b border-border p-2",
					children: BOT_FILES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActive(f.name),
						className: cn("h-10 shrink-0 rounded-md px-3 text-xs font-medium transition-colors duration-150", f.name === active ? "bg-raised text-fg" : "text-muted hover:text-fg"),
						children: f.name
					}, f.name))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs text-muted",
						children: file?.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => void copy(),
						children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied ? "Kopyalandı" : "Kopyala"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "max-h-[560px] overflow-auto p-4 font-mono text-xs leading-relaxed text-fg/90",
					children: file?.content
				})
			]
		})]
	});
}
function alertsToCsv(alerts) {
	const header = [
		"vaxt",
		"istifadeci",
		"nov",
		"etibar",
		"canlida_nefer",
		"jeton",
		"yer",
		"rate",
		"qosulan",
		"qalan_san",
		"basliq",
		"gonderen",
		"url"
	];
	const rows = alerts.map((a) => [
		new Date(a.ts).toISOString(),
		a.username,
		a.giftType,
		a.confidence,
		a.viewers,
		a.totalCoins,
		a.totalSlots,
		a.rate,
		a.participants,
		a.remainSec ?? 0,
		csvEscape(a.title ?? ""),
		a.sender ?? "",
		a.liveUrl
	].join(","));
	return [header.join(","), ...rows].join("\n");
}
function csvEscape(value) {
	if (/[",\n]/.test(value)) return `"${value.replace(/"/g, "\"\"")}"`;
	return value;
}
function downloadText(filename, text, mime) {
	const blob = new Blob([text], { type: mime });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tabular-nums", {
	variants: { variant: {
		default: "bg-raised text-muted",
		live: "bg-live-dim text-live",
		box: "bg-accent/15 text-accent",
		bag: "bg-warn/15 text-warn",
		danger: "bg-danger/15 text-danger",
		cool: "bg-raised text-fg"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({
			variant,
			className
		})),
		...props
	});
}
function FeedView() {
	const alerts = useRadar((s) => s.alerts);
	const sendAlert = useRadar((s) => s.sendAlert);
	const injectSample = useRadar((s) => s.injectSample);
	const clearAlerts = useRadar((s) => s.clearAlerts);
	function exportCsv() {
		if (alerts.length === 0) {
			toast.error("Lenta boşdur");
			return;
		}
		downloadText("sandiqradar.csv", alertsToCsv(alerts), "text/csv;charset=utf-8");
		toast.success("CSV endirildi");
	}
	function exportJson() {
		if (alerts.length === 0) {
			toast.error("Lenta boşdur");
			return;
		}
		downloadText("sandiqradar.json", JSON.stringify(alerts, null, 2), "application/json");
		toast.success("JSON endirildi");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-3xl flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted uppercase",
				children: "Xəbərdarlıq lenti"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 text-xl font-semibold",
				children: "Sandıq və hədiyyə çantası"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						size: "sm",
						onClick: () => injectSample("chest"),
						children: "Nümunə sandıq"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						size: "sm",
						onClick: () => injectSample("gift_bag"),
						children: "Nümunə çanta"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: exportCsv,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "CSV"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: exportJson,
						children: "JSON"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: clearAlerts,
						children: "Təmizlə"
					})
				]
			})]
		}), alerts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-xl bg-surface px-4 py-16 text-center shadow-[var(--shadow-border)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Lenta boşdur. Dəqiq unique_id canlı olanda növ (sandıq və ya hədiyyə çantası) və nəfər sayı burada görünəcək."
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-4",
			children: alerts.map((a) => {
				const fill = a.totalSlots > 0 ? Math.min(100, Math.round(a.participants / a.totalSlots * 100)) : 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: new Date(a.ts).toLocaleTimeString("az-AZ", {
										hour: "2-digit",
										minute: "2-digit",
										second: "2-digit"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "mt-1 text-lg font-semibold tracking-tight",
									children: ["@", a.username]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: a.kind === "gift_bag" ? "bag" : "box",
										children: a.giftType
									}), a.confidence ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted",
										children: [
											"etibar ",
											Math.round(a.confidence),
											"%"
										]
									}) : null]
								}),
								a.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: a.title
								}) : null
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-3xl font-medium tracking-tight text-accent tabular-nums",
									children: fmtRate(a.rate)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "jeton / nəfər"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
									icon: Eye,
									label: "Canlıda",
									value: `${fmtNum(a.viewers)} nəfər`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
									icon: Box,
									label: "Bölgü",
									value: `${a.totalCoins}/${a.totalSlots}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
									icon: Users,
									label: "Qoşulan",
									value: `${fmtNum(a.participants)} / ${fmtNum(a.totalSlots)}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
									icon: Send,
									label: "Telegram",
									value: a.telegramSent ? "Göndərildi" : a.telegramError ?? "Gözləyir"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 flex justify-between text-xs text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Qoşulma" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums",
									children: [fill, "%"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "progress-bar",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { width: `${fill}%` } })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "mt-4 overflow-x-auto rounded-lg bg-raised p-3 font-mono text-xs leading-relaxed text-muted whitespace-pre-wrap",
							children: formatTelegramAlert(a)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "secondary",
								onClick: () => {
									sendAlert(a).then(() => toast.message("Telegram sorğusu göndərildi"));
								},
								children: "Telegram-a at"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: a.liveUrl,
									target: "_blank",
									rel: "noreferrer",
									children: "Yayıma keç"
								})
							})]
						})
					]
				}, a.id);
			})
		})]
	});
}
function Meta({ icon: Icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-raised px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1.5 text-faint",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs",
				children: label
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm font-medium tabular-nums",
			children: value
		})]
	});
}
var FILTERS = [
	{
		id: "all",
		label: "Hamısı"
	},
	{
		id: "live",
		label: "Canlı"
	},
	{
		id: "box",
		label: "Qutu"
	},
	{
		id: "offline",
		label: "Offline"
	}
];
function ListView() {
	const usernames = useRadar((s) => s.usernames);
	const setUsernames = useRadar((s) => s.setUsernames);
	const restoreWatchlist = useRadar((s) => s.restoreWatchlist);
	const live = useRadar((s) => s.live);
	const listFilter = useRadar((s) => s.listFilter);
	const setListFilter = useRadar((s) => s.setListFilter);
	const [q, setQ] = (0, import_react.useState)("");
	const [bulk, setBulk] = (0, import_react.useState)("");
	const [probeName, setProbeName] = (0, import_react.useState)("");
	const [probing, setProbing] = (0, import_react.useState)(false);
	const [probe, setProbe] = (0, import_react.useState)(null);
	const [probeNote, setProbeNote] = (0, import_react.useState)("");
	const liveMap = (0, import_react.useMemo)(() => new Map(live.map((s) => [s.username, s])), [live]);
	const ranked = (0, import_react.useMemo)(() => {
		const base = searchUsernames(usernames, q);
		if (listFilter === "all") return base;
		return base.filter((row) => {
			const st = liveMap.get(row.name)?.status ?? "offline";
			if (listFilter === "box") return st === "box";
			if (listFilter === "live") return st === "live" || st === "box";
			return st === "offline" || st === "error" || st === "checking";
		});
	}, [
		q,
		usernames,
		listFilter,
		liveMap
	]);
	const needle = q.trim();
	const visible = needle ? ranked.slice(0, 140) : ranked.slice(0, 90);
	const exact = ranked.find((r) => r.match === "exact") ?? null;
	function applyBulk() {
		const parsed = parseUsernameList(bulk);
		if (parsed.length === 0) {
			toast.error("Siyahı boşdur");
			return;
		}
		setUsernames(parsed);
		toast.success(`${parsed.length} dəqiq istifadəçi yükləndi`);
		setBulk("");
	}
	async function runProbe() {
		const name = probeName.trim().replace(/^@/, "");
		if (!name) return;
		setProbing(true);
		setProbe(null);
		setProbeNote("");
		try {
			const res = await probeUserLive({ data: { username: name } });
			setProbe(res);
			if (res.blocked) {
				setProbeNote(`Blok: HTTP ${res.httpStatus || "şəbəkə"}`);
				toast.error("TikTok sorğunu blokladı");
				return;
			}
			if (!res.exactMatch) {
				setProbeNote(`Uyğunsuzluq: istənilən @${name}, tapılan @${res.uniqueId || "—"}`);
				toast.error("Dəqiq ad uyğun gəlmədi");
				return;
			}
			if (res.live) toast.success(`@${res.uniqueId} canlıdır · ${fmtNum(res.viewers)} nəfər`);
			else toast.message(`@${res.uniqueId || name} offline`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Yoxlama alınmadı");
		} finally {
			setProbing(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 lg:grid lg:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted uppercase",
						children: "İzləmə siyahısı"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-1 text-xl font-semibold",
						children: [fmtNum(usernames.length), " dəqiq ad"]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative min-w-48 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-faint" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "pl-9",
							placeholder: "Dəqiq ad axtar…",
							value: q,
							onChange: (e) => setQ(e.target.value),
							"aria-label": "İstifadəçi axtar"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-3 flex flex-wrap gap-1.5",
					children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setListFilter(f.id),
						className: `h-9 rounded-md px-3 text-xs font-medium transition-colors duration-150 ${listFilter === f.id ? "bg-raised text-fg" : "text-muted hover:text-fg"}`,
						children: f.label
					}, f.id))
				}),
				exact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 rounded-lg bg-live-dim px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-live",
						children: "Dəqiq uyğunluq tapıldı"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 truncate text-lg font-semibold tracking-tight",
						children: ["@", exact.name]
					})]
				}) : needle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: ranked.length === 0 ? "Bu ad siyahıda yoxdur — oxşar ad qəbul edilmir." : `${ranked.length} yaxın nəticə`
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border",
					children: visible.map((row) => {
						const liveRow = liveMap.get(row.name);
						const status = liveRow?.status ?? "offline";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate font-medium",
									children: ["@", row.name]
								}), liveRow?.boxLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [liveRow.boxLabel, liveRow.boxSlots ? ` · ${liveRow.boxJoined ?? 0}/${liveRow.boxSlots}` : ""]
								}) : liveRow?.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs text-muted",
									children: liveRow.title
								}) : null]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [liveRow && liveRow.viewers > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-xs text-muted tabular-nums",
									children: [fmtNum(liveRow.viewers), " nəfər"]
								}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: status === "box" ? liveRow?.boxKind === "gift_bag" ? "bag" : "box" : status === "live" ? "live" : status === "error" ? "danger" : "default",
									children: status === "box" ? liveRow?.boxLabel ?? "Qutu" : status === "live" ? "Canlı" : status === "checking" ? "Yoxlanır" : status === "error" ? "Xəta" : "Offline"
								})]
							})]
						}, row.name);
					})
				}),
				ranked.length > visible.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-muted",
					children: [
						"Daha ",
						ranked.length - visible.length,
						" ad var — axtarışı daraldın."
					]
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "Dəqiq canlı yoxlama"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 mb-3 text-sm text-muted",
						children: "uniqueId eyni olmalıdır. Nəticədə növ (sandıq/çanta) və canlıdakı nəfər sayı göstərilir."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: probeName,
							onChange: (e) => setProbeName(e.target.value),
							placeholder: "ramiz_real",
							"aria-label": "Yoxlanacaq istifadəçi"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void runProbe(),
							disabled: probing || !probeName.trim(),
							children: probing ? "Yoxlanır…" : "Yoxla"
						})]
					}),
					probeNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: probeNote
					}) : null,
					probe && probe.exactMatch ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProbeMeta, {
								label: "Status",
								value: probe.live ? "Canlı" : "Offline"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProbeMeta, {
								label: "Canlıda",
								value: `${fmtNum(probe.viewers)} nəfər`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProbeMeta, {
								label: "Növ",
								value: probe.box ? probe.box.giftType : "Qutu yoxdur"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProbeMeta, {
								label: "Qoşulan",
								value: probe.box ? `${probe.box.participants}/${probe.box.totalSlots}` : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProbeMeta, {
								label: "Rate",
								value: probe.box ? fmtRate(probe.box.rate) : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProbeMeta, {
								label: "Etibar",
								value: probe.box ? `${Math.round(probe.box.confidence)}%` : "—"
							}),
							probe.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProbeMeta, {
								label: "Başlıq",
								value: probe.title
							}) : null,
							probe.box?.sender ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProbeMeta, {
								label: "Göndərən",
								value: `@${probe.box.sender}`
							}) : null
						]
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "Toplu idxal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 mb-3 text-sm text-muted",
						children: "Hər sətirdə bir dəqiq unique_id."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: bulk,
						onChange: (e) => setBulk(e.target.value),
						placeholder: "ramiz_real\nboz_qurt37\n.qara_010"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "w-full",
							variant: "secondary",
							onClick: applyBulk,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), "Siyahını əvəz et"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							variant: "ghost",
							onClick: () => {
								restoreWatchlist();
								toast.success("Həqiqi siyahı bərpa olundu");
							},
							children: "Həqiqi siyahını bərpa et"
						})]
					})
				]
			})]
		})]
	});
}
function ProbeMeta({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-raised px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-faint",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-0.5 truncate text-sm font-medium tabular-nums",
			children: value
		})]
	});
}
function kindVariant(kind) {
	if (kind === "gift_bag") return "bag";
	if (kind === "chest" || kind === "portal" || kind === "lucky") return "box";
	if (kind === "envelope") return "live";
	return "default";
}
function RadarView() {
	const live = useRadar((s) => s.live);
	const stats = useRadar((s) => s.stats);
	const running = useRadar((s) => s.running);
	const ticker = useRadar((s) => s.ticker);
	const alerts = useRadar((s) => s.alerts);
	const usernames = useRadar((s) => s.usernames);
	const health = useRadar((s) => s.health);
	const healthNote = useRadar((s) => s.healthNote);
	const stealth = useRadar((s) => s.settings.stealthMode);
	const dots = live.slice(0, 28);
	const viewerSum = live.reduce((acc, s) => acc + s.viewers, 0);
	const okRate = stats.checks > 0 ? Math.round(stats.okHits / stats.checks * 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 lg:grid lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "enter-up rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted uppercase",
						children: "Canlı radar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-semibold tracking-tight",
						children: "Dəqiq tarama"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [stealth ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "box",
							children: "Stealth"
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: health === "blocked" ? "danger" : health === "cooling" ? "bag" : running ? "live" : "default",
							children: health === "blocked" ? "Blok" : health === "cooling" ? "Backoff" : running ? "Aktiv" : "Dayanıb"
						})]
					})]
				}),
				healthNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 rounded-lg bg-raised px-3 py-2 text-xs leading-relaxed text-muted",
					children: healthNote
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative mx-auto aspect-square max-h-64 w-full max-w-64 sm:max-h-[360px] sm:max-w-[360px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 200 200",
						className: "size-full",
						"aria-hidden": "true",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
								id: "radarGlow",
								cx: "50%",
								cy: "50%",
								r: "50%",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "0%",
										stopColor: "var(--color-accent)",
										stopOpacity: "0.18"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "70%",
										stopColor: "var(--color-accent)",
										stopOpacity: "0.04"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
										offset: "100%",
										stopColor: "transparent",
										stopOpacity: "0"
									})
								]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "100",
								cy: "100",
								r: "96",
								fill: "url(#radarGlow)"
							}),
							[
								28,
								52,
								76
							].map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								className: "radar-ring",
								cx: "100",
								cy: "100",
								r,
								fill: "none",
								stroke: "var(--color-border)",
								strokeWidth: "0.7",
								style: { animationDelay: `${i * 400}ms` }
							}, r)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
								className: "radar-sweep",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M100 100 L100 8 A92 92 0 0 1 148 22 Z",
									fill: "var(--color-accent)",
									opacity: "0.12"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "100",
									y1: "100",
									x2: "100",
									y2: "8",
									stroke: "var(--color-accent)",
									strokeWidth: "0.8",
									opacity: "0.7"
								})]
							}),
							dots.map((s, i) => {
								const angle = hashAngle(s.username) / 180 * Math.PI;
								const radius = 22 + hashAngle(s.username + "r") % 62;
								const x = 100 + Math.cos(angle) * radius;
								const y = 100 + Math.sin(angle) * radius;
								const box = s.status === "box";
								const bag = s.boxKind === "gift_bag";
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: x,
									cy: y,
									r: box ? 3.4 : 2,
									fill: bag ? "var(--color-warn)" : box ? "var(--color-accent)" : "var(--color-live)",
									opacity: .55 + i % 5 * .08
								}, s.username);
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "100",
								cy: "100",
								r: "3.4",
								fill: "var(--color-fg)"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-center font-mono text-xs text-muted tabular-nums",
					children: [
						fmtNum(stats.scanned),
						"/",
						fmtNum(usernames.length),
						" yoxlanıb · ",
						fmtNum(stats.live),
						" canlı · ",
						fmtNum(viewerSum),
						" nəfər"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 truncate font-mono text-xs text-faint",
					children: ticker.length > 0 ? ticker.map((t) => `@${t}`).join("  ·  ") : "Növbə gözləyir"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid grid-cols-2 gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: Radio,
							label: "Canlı",
							value: fmtNum(stats.live),
							tone: "live"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: Box,
							label: "Aktiv qutu",
							value: fmtNum(stats.boxes),
							tone: "accent"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: Users,
							label: "Nəfər (indi)",
							value: fmtNum(viewerSum)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: Eye,
							label: "Yoxlama",
							value: fmtNum(stats.checks)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: Zap,
							label: "Xəbərdarlıq",
							value: fmtNum(stats.alerts)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							icon: Shield,
							label: "Uğur",
							value: `${okRate}%`
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium",
							children: "Canlı otaqlar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted",
							children: [live.length, " dəqiq uyğunluq"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: live.slice(0, 6).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-lg bg-raised px-3 py-6 text-center text-sm text-muted",
							children: "Hələ dəqiq unique_id canlı tapılmayıb. Stealth rejim yavaş, amma daha az bloklanır."
						}) : live.slice(0, 6).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 rounded-lg bg-raised px-3 py-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate font-medium",
									children: ["@", s.uniqueId || s.username]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [s.boxLabel ?? s.title ?? "Canlı", s.boxSlots ? ` · ${s.boxJoined ?? 0}/${s.boxSlots}` : ""]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex shrink-0 flex-col items-end gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-sm tabular-nums",
									children: [fmtNum(s.viewers), " nəfər"]
								}), s.status === "box" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: kindVariant(s.boxKind),
									children: [
										s.boxLabel ?? "Qutu",
										" · ",
										fmtRate(s.boxRate ?? 0)
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "live",
									children: "Canlı"
								})]
							})]
						}, s.username))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium",
							children: "Son qutular"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted",
							children: [alerts.length, " qeyd"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: alerts.slice(0, 4).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-lg bg-raised px-3 py-5 text-center text-sm text-muted",
							children: "Sandıq və ya hədiyyə çantası tapılanda növ + nəfər sayı burada görünür."
						}) : alerts.slice(0, 4).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 rounded-lg bg-raised px-3 py-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate font-medium",
									children: ["@", a.username]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										a.giftType,
										" · ",
										fmtNum(a.viewers),
										" nəfər · ",
										a.participants,
										"/",
										a.totalSlots
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-sm tabular-nums text-accent",
								children: fmtRate(a.rate)
							})]
						}, a.id))
					})]
				})
			]
		})]
	});
}
function Stat({ icon: Icon, label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs",
				children: label
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("mt-2 font-mono text-2xl font-medium tracking-tight tabular-nums", tone === "live" && "text-live", tone === "accent" && "text-accent"),
			children: value
		})]
	});
}
function hashAngle(s) {
	let h = 0;
	for (let i = 0; i < s.length; i += 1) h = h * 33 + s.charCodeAt(i) >>> 0;
	return h % 360;
}
var NAV = [
	{
		id: "radar",
		label: "Radar",
		icon: Radio
	},
	{
		id: "list",
		label: "Siyahı",
		icon: Users
	},
	{
		id: "feed",
		label: "Lenta",
		icon: Bell
	},
	{
		id: "bot",
		label: "Ayarlar",
		icon: Settings
	},
	{
		id: "code",
		label: "Kod",
		icon: CodeXml
	}
];
function AppShell() {
	const view = useRadar((s) => s.view);
	const setView = useRadar((s) => s.setView);
	const running = useRadar((s) => s.running);
	const start = useRadar((s) => s.start);
	const stop = useRadar((s) => s.stop);
	const stats = useRadar((s) => s.stats);
	const health = useRadar((s) => s.health);
	const live = useRadar((s) => s.live);
	const total = useRadar((s) => s.usernames.length);
	const viewerSum = live.reduce((acc, s) => acc + s.viewers, 0);
	(0, import_react.useEffect)(() => {
		start();
		return () => stop();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-right"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border bg-surface/60 p-4 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-8 flex flex-1 flex-col gap-1",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							...item,
							active: view === item.id,
							onSelect: setView
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-faint",
						children: "Sandıq / hədiyyə çantası · dəqiq nəfər"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col pb-20 md:pb-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 py-3 backdrop-blur-sm sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-0 md:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { compact: true })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "hidden truncate text-sm text-muted md:block",
							children: [
								fmtNum(stats.live),
								" canlı · ",
								fmtNum(viewerSum),
								" nəfər · ",
								fmtNum(stats.alerts),
								" xəbərdarlıq ·",
								" ",
								fmtNum(stats.scanned),
								"/",
								fmtNum(total),
								health === "blocked" ? " · blok" : health === "cooling" ? " · backoff" : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: running ? "secondary" : "default",
							onClick: () => running ? stop() : start(),
							"aria-pressed": running,
							children: [running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), running ? "Dayandır" : "Başlat"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex-1 px-4 py-5 sm:px-6 sm:py-6",
					children: [
						view === "radar" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadarView, {}),
						view === "list" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListView, {}),
						view === "feed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeedView, {}),
						view === "bot" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BotView, {}),
						view === "code" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeView, {})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-surface/95 px-1 pt-1 pb-[max(0.35rem,env(safe-area-inset-bottom))] backdrop-blur-sm md:hidden",
				children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
					...item,
					active: view === item.id,
					onSelect: setView,
					stacked: true
				}, item.id))
			})
		]
	});
}
function Brand({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-8 place-items-center rounded-md bg-raised shadow-[var(--shadow-border)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-4 text-accent" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-sm font-semibold tracking-tight",
				children: "SandıqRadar"
			}), compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "Növ + nəfər sayı"
			})]
		})]
	});
}
function NavBtn({ id, label, icon: Icon, active, onSelect, stacked }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => onSelect(id),
		className: cn("flex items-center gap-2 rounded-md px-3 text-sm font-medium transition-colors duration-150", stacked ? "h-14 flex-col justify-center gap-1 px-1 text-[11px]" : "h-11", active ? "bg-raised text-fg" : "text-muted hover:text-fg"),
		"aria-current": active ? "page" : void 0,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("size-4", stacked && "size-[18px]") }), label]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
