import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { a as string, i as object } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/send-telegram-fgfBUisW.js
var sendTelegramAlert_createServerFn_handler = createServerRpc({
	id: "bf41790866200090c2e98d8635870116685a89794264040ae816b9d8460360f2",
	name: "sendTelegramAlert",
	filename: "src/lib/send-telegram.ts"
}, (opts) => sendTelegramAlert.__executeServer(opts));
var sendTelegramAlert = createServerFn({ method: "POST" }).validator(object({
	token: string().min(10).max(200),
	chatId: string().min(1).max(64),
	text: string().min(1).max(4e3)
})).handler(sendTelegramAlert_createServerFn_handler, async ({ data }) => {
	const payload = await (await fetch(`https://api.telegram.org/bot${data.token}/sendMessage`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			chat_id: data.chatId,
			text: data.text,
			parse_mode: "Markdown",
			disable_web_page_preview: false
		})
	})).json();
	if (!payload.ok) return {
		ok: false,
		error: payload.description ?? "Telegram xətası"
	};
	return {
		ok: true,
		error: ""
	};
});
//#endregion
export { sendTelegramAlert_createServerFn_handler };
