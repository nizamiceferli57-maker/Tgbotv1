import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { a as parseCount, c as usernamesMatch, i as normalizeUsername } from "./usernames-BlsEYq2x.mjs";
import { a as string, i as object, t as array } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/probe-live-CeyWnYFZ.js
var BROWSER_PROFILES = [
	{
		ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
		secChUa: `"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"`,
		secChUaMobile: "?0",
		secChUaPlatform: `"Windows"`,
		platform: "Win32",
		language: "az-AZ,az;q=0.9,en-US;q=0.8,en;q=0.7",
		width: "1920",
		height: "1080"
	},
	{
		ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15",
		secChUa: `"Not A(Brand";v="99", "Safari";v="18", "Chromium";v="130"`,
		secChUaMobile: "?0",
		secChUaPlatform: `"macOS"`,
		platform: "MacIntel",
		language: "az-AZ,az;q=0.9,en;q=0.7",
		width: "1680",
		height: "1050"
	},
	{
		ua: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
		secChUa: `"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"`,
		secChUaMobile: "?0",
		secChUaPlatform: `"Linux"`,
		platform: "Linux x86_64",
		language: "en-US,en;q=0.9,az;q=0.6",
		width: "1920",
		height: "1200"
	},
	{
		ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1",
		secChUa: `"Not A(Brand";v="8", "Chromium";v="131", "Mobile Safari";v="131"`,
		secChUaMobile: "?1",
		secChUaPlatform: `"iOS"`,
		platform: "iPhone",
		language: "az-AZ,az;q=0.9,en;q=0.7",
		width: "390",
		height: "844"
	},
	{
		ua: "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
		secChUa: `"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"`,
		secChUaMobile: "?1",
		secChUaPlatform: `"Android"`,
		platform: "Linux armv8l",
		language: "az-AZ,az;q=0.9,en-US;q=0.8",
		width: "412",
		height: "915"
	},
	{
		ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0",
		secChUa: `"Not.A/Brand";v="8", "Chromium";v="131"`,
		secChUaMobile: "?0",
		secChUaPlatform: `"Windows"`,
		platform: "Win32",
		language: "az,en-US;q=0.8,en;q=0.6",
		width: "1536",
		height: "864"
	}
];
function pickProfile(seed = Date.now()) {
	return BROWSER_PROFILES[Math.abs(seed) % BROWSER_PROFILES.length];
}
function randomDeviceId() {
	let id = "";
	for (let i = 0; i < 19; i += 1) id += String(Math.floor(Math.random() * 10));
	if (id[0] === "0") id = `7${id.slice(1)}`;
	return id;
}
function stealthHeaders(username, profile, cookie) {
	const headers = {
		"User-Agent": profile.ua,
		Accept: "application/json, text/html;q=0.9, */*;q=0.8",
		"Accept-Language": profile.language,
		"Cache-Control": "no-cache",
		Pragma: "no-cache",
		Referer: `https://www.tiktok.com/@${username}/live`,
		"sec-ch-ua": profile.secChUa,
		"sec-ch-ua-mobile": profile.secChUaMobile,
		"sec-ch-ua-platform": profile.secChUaPlatform,
		"sec-fetch-dest": "empty",
		"sec-fetch-mode": "cors",
		"sec-fetch-site": "same-origin"
	};
	if (cookie) headers.Cookie = cookie;
	return headers;
}
function htmlHeaders(username, profile, cookie) {
	const headers = {
		"User-Agent": profile.ua,
		Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
		"Accept-Language": profile.language,
		Referer: "https://www.tiktok.com/",
		"sec-ch-ua": profile.secChUa,
		"sec-ch-ua-mobile": profile.secChUaMobile,
		"sec-ch-ua-platform": profile.secChUaPlatform,
		"sec-fetch-dest": "document",
		"sec-fetch-mode": "navigate",
		"sec-fetch-site": "same-origin",
		"upgrade-insecure-requests": "1"
	};
	if (cookie) headers.Cookie = cookie;
	return headers;
}
function webQuery(profile, extra) {
	return new URLSearchParams({
		aid: "1988",
		app_name: "tiktok_web",
		device_platform: "web",
		cookie_enabled: "true",
		screen_width: profile.width,
		screen_height: profile.height,
		browser_language: profile.language.split(",")[0] ?? "az-AZ",
		browser_platform: profile.platform,
		browser_name: "Mozilla",
		browser_online: "true",
		timezone_name: "Asia/Baku",
		webcast_language: "az",
		app_language: "az",
		...extra
	}).toString();
}
function parseSetCookie(headers) {
	const out = {};
	const raw = typeof headers.getSetCookie === "function" ? headers.getSetCookie() : headers.get("set-cookie") ? [headers.get("set-cookie")] : [];
	for (const line of raw) {
		const pair = line.split(";")[0];
		if (!pair) continue;
		const eq = pair.indexOf("=");
		if (eq <= 0) continue;
		const name = pair.slice(0, eq).trim();
		const value = pair.slice(eq + 1).trim();
		if (name && value) out[name] = value;
	}
	return out;
}
function cookieHeader(jar) {
	return Object.entries(jar).map(([k, v]) => `${k}=${v}`).join("; ");
}
function mergeCookies(jar, incoming) {
	return {
		...jar,
		...incoming
	};
}
function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
function jitter(baseMs, spreadMs) {
	return Math.max(40, Math.round(baseMs + (Math.random() * 2 - 1) * spreadMs));
}
var BOX_KIND_LABEL = {
	chest: "Sandıq",
	gift_bag: "Hədiyyə çantası",
	envelope: "Zərf",
	portal: "Portal sandıq",
	lucky: "Şans qutusu",
	unknown: "Bölünən qutu"
};
var CHEST_WORDS = /\b(sand[ıi]q|sanduq|chest|treasure|mystery\s*box|x[əe]zin[əe]|sunduk|hazine|сундук|宝箱|treasure_box|treasurebox)\b/i;
var BAG_WORDS = /\b(çanta|canta|bag|gift\s*bag|giftbag|lucky\s*bag|shopping\s*bag|h[əe]diyy[əe]\s*çantas[ıi]|hediye\s*cantasi|purse|福袋|gift_box|giftbox)\b/i;
var ENVELOPE_WORDS = /\b(z[əe]rf|red\s*packet|redpacket|lucky\s*money|hongbao|hong\s*bao|红包|envelop(?:e)?)\b/i;
var LUCKY_WORDS = /\b([şs]ans|lucky\s*box|luckybox)\b/i;
var PORTAL_WORDS = /\b(portal)\b/i;
function emptyScore() {
	return {
		chest: 0,
		gift_bag: 0,
		envelope: 0,
		portal: 0,
		lucky: 0,
		unknown: 0
	};
}
function asRecord$1(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
}
function lowerKeys(node) {
	return new Map(Object.keys(node).map((k) => [k.toLowerCase(), node[k]]));
}
function blobText(node) {
	const keys = [
		"name",
		"title",
		"type",
		"gift_name",
		"box_name",
		"desc",
		"description",
		"display_text",
		"label"
	];
	const map = lowerKeys(node);
	const parts = [];
	for (const key of keys) {
		const val = map.get(key);
		if (typeof val === "string" && val.trim()) parts.push(val);
	}
	parts.push(...Object.keys(node));
	return parts.join(" ").toLowerCase();
}
function numish(value) {
	if (value === void 0 || value === null) return "";
	return String(value).trim().toLowerCase();
}
/**
* TikTok envelope business_type:
*   1 = user diamond treasure box  → Sandıq
*   2 = platform diamond gift bag  → Hədiyyə çantası
* envelope_type 2 = portal box.
*/
function classifyBoxKind(node) {
	const rec = asRecord$1(node);
	if (!rec) return {
		kind: "unknown",
		label: BOX_KIND_LABEL.unknown,
		confidence: 0,
		signals: []
	};
	const score = emptyScore();
	const signals = [];
	const map = lowerKeys(rec);
	const keys = [...map.keys()];
	const text = blobText(rec);
	const business = numish(map.get("business_type") ?? map.get("businesstype") ?? map.get("biz_type"));
	if (business === "1" || business === "user_diamond" || business === "userdiamond" || business === "treasure") {
		score.chest += 48;
		signals.push("business_type=1 (istifadəçi sandığı)");
	} else if (business === "2" || business === "platform_diamond" || business === "platformdiamond" || business === "gift_bag") {
		score.gift_bag += 48;
		signals.push("business_type=2 (platforma hədiyyə çantası)");
	}
	const envelopeType = numish(map.get("envelope_type") ?? map.get("envelopetype") ?? map.get("box_type"));
	if (envelopeType === "2" || envelopeType === "portal") {
		score.portal += 40;
		signals.push("envelope_type=portal");
	}
	if (keys.some((k) => /portal_box|portalbox/.test(k))) {
		score.portal += 28;
		signals.push("portal_box sahəsi");
	}
	if (keys.some((k) => /treasure_box|treasurebox|chest_info|anchor_gift_box/.test(k))) {
		score.chest += 22;
		signals.push("treasure/chest sahəsi");
	}
	if (keys.some((k) => /gift_bag|giftbag|bag_info|gift_box|giftbox/.test(k))) {
		score.gift_bag += 22;
		signals.push("gift bag sahəsi");
	}
	if (keys.some((k) => /lucky_box|luckybox/.test(k))) {
		score.lucky += 24;
		signals.push("lucky_box sahəsi");
	}
	if (keys.some((k) => /red_packet|redpacket|lucky_money/.test(k))) {
		score.envelope += 24;
		signals.push("red packet sahəsi");
	}
	if (CHEST_WORDS.test(text)) {
		score.chest += 26;
		signals.push("ad: sandıq/chest");
	}
	if (BAG_WORDS.test(text)) {
		score.gift_bag += 26;
		signals.push("ad: hədiyyə çantası/bag");
	}
	if (ENVELOPE_WORDS.test(text) && !/envelope_info|envelop_info|envelope_id|envelop_id/.test(text)) {
		score.envelope += 20;
		signals.push("ad: zərf");
	}
	if (LUCKY_WORDS.test(text) && !BAG_WORDS.test(text)) {
		score.lucky += 18;
		signals.push("ad: şans qutusu");
	}
	if (PORTAL_WORDS.test(text)) {
		score.portal += 18;
		signals.push("ad: portal");
	}
	const ranked = Object.keys(score).filter((k) => k !== "unknown").sort((a, b) => score[b] - score[a]);
	const best = ranked[0] ?? "unknown";
	const bestScore = score[best];
	const second = ranked[1] ? score[ranked[1]] : 0;
	if (bestScore <= 0) {
		if (map.has("envelope_id") || map.has("envelop_id") || map.has("box_id") || map.has("treasure_id")) return {
			kind: "chest",
			label: BOX_KIND_LABEL.chest,
			confidence: 58,
			signals: ["standart bölünən zərf → Sandıq"]
		};
		return {
			kind: "unknown",
			label: BOX_KIND_LABEL.unknown,
			confidence: 30,
			signals: ["zəif siqnal"]
		};
	}
	const gap = bestScore - second;
	const confidence = Math.min(99, 52 + bestScore + Math.min(18, gap));
	return {
		kind: best,
		label: BOX_KIND_LABEL[best],
		confidence,
		signals
	};
}
var LIVE_STATUS = /* @__PURE__ */ new Set([2]);
var BOX_HINTS = /* @__PURE__ */ new Set([
	"treasure_box",
	"treasurebox",
	"gift_box",
	"giftbox",
	"gift_bag",
	"giftbag",
	"lucky_box",
	"luckybox",
	"box_info",
	"boxinfo",
	"chest",
	"chest_info",
	"sandiq",
	"activity_box",
	"portal_box",
	"envelope_info",
	"envelop_info",
	"envelope",
	"envelop",
	"lucky_money",
	"red_packet",
	"redpacket",
	"box_list",
	"envelope_list",
	"portal",
	"anchor_gift_box",
	"anchorgiftbox",
	"bag_info",
	"lottery_box",
	"split_box",
	"coin_box"
]);
var COIN_KEYS = [
	"diamond_count",
	"diamondcount",
	"total_coins",
	"totalcoins",
	"reward_coins",
	"coins",
	"coin_count",
	"coins_count",
	"diamond",
	"total_diamond",
	"diamond_count_value",
	"reward_diamond"
];
var SLOT_KEYS = [
	"people_count",
	"peoplecount",
	"total_slots",
	"totalslots",
	"max_user",
	"max_users",
	"user_limit",
	"join_limit",
	"unpack_user_count",
	"capacity",
	"slots",
	"max_count",
	"target_user_count",
	"max_people",
	"people_num",
	"total_people"
];
var PART_KEYS = [
	"joined_count",
	"join_count",
	"current_user",
	"participants",
	"joined",
	"unpack_count",
	"participate_count",
	"open_count",
	"current_people",
	"joined_user_count",
	"now_count"
];
var ID_KEYS = [
	"envelope_id",
	"envelop_id",
	"box_id",
	"activity_id",
	"treasure_id",
	"id_str",
	"id"
];
var TYPE_KEYS = [
	"name",
	"title",
	"type",
	"gift_name",
	"box_name",
	"desc",
	"business_type",
	"display_text"
];
var REMAIN_KEYS = [
	"remain_time",
	"left_time",
	"remain_seconds",
	"countdown",
	"unpack_at",
	"end_time",
	"expire_at"
];
var SENDER_KEYS = [
	"send_user_name",
	"send_username",
	"sender_name",
	"from_user",
	"unique_id",
	"uniqueid"
];
var VIEWER_KEYS = [
	"userCount",
	"user_count",
	"viewer_count",
	"viewerCount",
	"audienceCount",
	"audience_count",
	"current_user_count",
	"online_user_count",
	"watching_count",
	"display_long",
	"display_value"
];
function asRecord(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value) ? value : null;
}
function first(node, keys) {
	const lower = new Map(Object.keys(node).map((k) => [k.toLowerCase(), node[k]]));
	for (const key of keys) if (lower.has(key.toLowerCase())) return lower.get(key.toLowerCase());
}
function firstInt(node, keys) {
	const rec = asRecord(node);
	if (!rec) return null;
	return parseCount(first(rec, keys));
}
function collectUniqueIds(payload, depth = 0, out = [], seen = /* @__PURE__ */ new Set()) {
	if (depth > 8 || payload == null) return out;
	const rec = asRecord(payload);
	if (rec) for (const [key, val] of Object.entries(rec)) {
		const lk = key.toLowerCase();
		if ([
			"uniqueid",
			"unique_id",
			"display_id",
			"displayid",
			"uniqueidstr"
		].includes(lk) && typeof val === "string") {
			const k = val.trim().toLowerCase();
			if (k && !seen.has(k)) {
				seen.add(k);
				out.push(val.trim());
			}
		} else if (val && typeof val === "object") collectUniqueIds(val, depth + 1, out, seen);
	}
	else if (Array.isArray(payload)) for (const item of payload.slice(0, 40)) collectUniqueIds(item, depth + 1, out, seen);
	return out;
}
function pickLiveRoom(nested) {
	for (const key of [
		"liveRoom",
		"live_room",
		"room",
		"liveRoomInfo",
		"roomInfo",
		"room_info"
	]) {
		const val = asRecord(nested[key]);
		if (val) return val;
	}
	return nested;
}
function extractViewersFromRoom(liveRoom, nested) {
	const candidates = [];
	const push = (n) => {
		if (n !== null && n >= 0) candidates.push(n);
	};
	push(firstInt(liveRoom, VIEWER_KEYS));
	const stats = asRecord(liveRoom.liveRoomStats) ?? asRecord(liveRoom.stats) ?? asRecord(liveRoom.room_stats);
	if (stats) push(firstInt(stats, VIEWER_KEYS));
	push(firstInt(nested, VIEWER_KEYS));
	if (asRecord(asRecord(liveRoom.owner)?.follow_info)) {}
	if (candidates.length === 0) return 0;
	return Math.max(0, candidates[0]);
}
function parseLiveRoom(username, data) {
	const root = asRecord(data);
	if (!root) return null;
	const nested = asRecord(root.data) ?? root;
	const liveRoom = pickLiveRoom(nested);
	let status = firstInt(root, [
		"status",
		"liveRoomStatus",
		"room_status",
		"live_status"
	]);
	if (status === null) status = firstInt(liveRoom, [
		"status",
		"live_status",
		"room_status",
		"liveRoomStatus"
	]);
	const isLiveFlag = liveRoom.isLive === true || liveRoom.is_live === true || nested.isLive === true;
	let roomId = String(first(liveRoom, [
		"roomID",
		"room_id",
		"id_str",
		"id"
	]) ?? first(nested, [
		"roomId",
		"room_id",
		"roomID"
	]) ?? "").trim();
	if (roomId === "0" || roomId === "None" || roomId === "null") roomId = "";
	if (!(status !== null && LIVE_STATUS.has(status)) && !isLiveFlag || !roomId) return null;
	if (status === 4 || status === 1) return null;
	const ids = collectUniqueIds(data);
	const uniqueId = ids.find((id) => usernamesMatch(username, id)) ?? "";
	if (ids.length > 0 && !uniqueId) return null;
	const viewers = extractViewersFromRoom(liveRoom, nested);
	const title = String(first(liveRoom, [
		"title",
		"room_title",
		"live_room_title"
	]) ?? "");
	const startedAt = firstInt(liveRoom, [
		"start_time",
		"startTime",
		"create_time",
		"createTime"
	]) ?? 0;
	const cover = String(first(liveRoom, [
		"coverUrl",
		"cover_url",
		"origin_cover"
	]) ?? "");
	const handle = uniqueId || username;
	return {
		username,
		uniqueId: handle,
		roomId,
		viewers,
		title,
		liveUrl: `https://www.tiktok.com/@${handle}/live`,
		exactMatch: usernamesMatch(username, handle),
		startedAt: startedAt > 1e10 ? Math.trunc(startedAt / 1e3) : startedAt,
		coverUrl: cover
	};
}
function looksGiftCatalog(node) {
	const keys = new Set(Object.keys(node).map((k) => k.toLowerCase()));
	const giftish = keys.has("gift_id") || keys.has("id") && keys.has("image") && keys.has("name");
	const splitish = [
		"people_count",
		"total_slots",
		"envelope_id",
		"box_id",
		"join_count",
		"joined_count"
	].some((k) => keys.has(k));
	return giftish && !splitish;
}
function isActiveSplitBox(node) {
	const rec = asRecord(node);
	if (!rec || looksGiftCatalog(rec)) return false;
	const coins = firstInt(rec, COIN_KEYS);
	const slots = firstInt(rec, SLOT_KEYS);
	if (!coins || !slots || coins <= 0 || slots <= 0) return false;
	const keys = new Set(Object.keys(rec).map((k) => k.toLowerCase()));
	const hasId = [
		"envelope_id",
		"envelop_id",
		"box_id",
		"treasure_id",
		"activity_id"
	].some((k) => keys.has(k));
	const hasJoin = firstInt(rec, PART_KEYS) !== null;
	const hasTime = REMAIN_KEYS.some((k) => keys.has(k));
	const hasHint = [...keys].some((k) => BOX_HINTS.has(k)) || [...keys].some((k) => /envelope|envelop|treasure|lucky|chest|box|bag|packet/.test(k));
	return hasId || hasJoin || hasTime || hasHint;
}
function remainSec(node) {
	const val = first(node, REMAIN_KEYS);
	if (val === void 0 || val === null) return 0;
	const n = Number(val);
	if (!Number.isFinite(n)) return 0;
	const now = Math.floor(Date.now() / 1e3);
	if (n > now + 5) return Math.max(0, Math.trunc(n - now));
	if (n > 1e10) return Math.max(0, Math.trunc(n / 1e3 - now));
	return Math.max(0, Math.trunc(n));
}
function senderOf(node) {
	const direct = first(node, SENDER_KEYS);
	if (typeof direct === "string" && direct.trim() && !/^\d+$/.test(direct.trim())) return direct.trim();
	const user = asRecord(node.send_user) ?? asRecord(node.user) ?? asRecord(node.sender);
	if (user) {
		const name = first(user, [
			"unique_id",
			"uniqueId",
			"nickname",
			"display_id"
		]);
		if (typeof name === "string" && name.trim()) return name.trim();
	}
	return "";
}
function boxFromNode(node) {
	const coins = firstInt(node, COIN_KEYS) ?? 0;
	const slots = firstInt(node, SLOT_KEYS) ?? 0;
	if (coins <= 0 || slots <= 0) return null;
	const parts = firstInt(node, PART_KEYS) ?? 0;
	const classified = classifyBoxKind(node);
	const rawName = first(node, TYPE_KEYS);
	return {
		giftType: classified.kind === "unknown" && typeof rawName === "string" && rawName.trim() ? rawName.trim() : classified.label,
		kind: classified.kind,
		confidence: classified.confidence,
		totalCoins: coins,
		totalSlots: slots,
		participants: parts && parts > slots ? slots : Math.max(0, parts),
		boxId: String(first(node, ID_KEYS) ?? ""),
		remainSec: remainSec(node),
		rate: coins / slots,
		sender: senderOf(node),
		signals: classified.signals
	};
}
function betterBox(a, b) {
	if (a.remainSec > 0 && b.remainSec === 0) return a;
	if (b.remainSec > 0 && a.remainSec === 0) return b;
	if (a.rate !== b.rate) return a.rate >= b.rate ? a : b;
	return a.totalCoins >= b.totalCoins ? a : b;
}
function extractTreasureBoxes(payload) {
	const found = [];
	const seen = /* @__PURE__ */ new Set();
	const consider = (node) => {
		if (!isActiveSplitBox(node)) return;
		const box = boxFromNode(node);
		if (!box) return;
		const key = box.boxId || `${box.kind}:${box.totalCoins}:${box.totalSlots}:${box.remainSec}`;
		if (seen.has(key)) return;
		seen.add(key);
		found.push(box);
	};
	const walk = (node, depth = 0) => {
		if (node == null || depth > 10) return;
		const rec = asRecord(node);
		if (rec) {
			if (Object.keys(rec).map((k) => k.toLowerCase()).some((k) => BOX_HINTS.has(k))) {
				for (const [key, val] of Object.entries(rec)) {
					if (!BOX_HINTS.has(key.toLowerCase())) continue;
					const inner = asRecord(val);
					if (inner) {
						consider(inner);
						walk(inner, depth + 1);
					} else if (Array.isArray(val)) for (const item of val) {
						const r = asRecord(item);
						if (r) consider(r);
						walk(item, depth + 1);
					}
				}
				consider(rec);
			} else if (isActiveSplitBox(rec)) consider(rec);
			for (const val of Object.values(rec)) walk(val, depth + 1);
		} else if (Array.isArray(node)) for (const item of node.slice(0, 80)) walk(item, depth + 1);
	};
	walk(payload);
	return found;
}
function extractTreasureBox(payload) {
	const boxes = extractTreasureBoxes(payload);
	if (boxes.length === 0) return null;
	return boxes.reduce(betterBox);
}
var HYDRATION = [
	/<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.+?)<\/script>/s,
	/window\['SIGI_STATE'\]\s*=\s*(\{.+?\});/s,
	/window\["SIGI_STATE"\]\s*=\s*(\{.+?\});/s,
	/<script id="SIGI_STATE"[^>]*>(.+?)<\/script>/s,
	/<script id="__NEXT_DATA__"[^>]*>(.+?)<\/script>/s
];
function extractHydration(html) {
	for (const pat of HYDRATION) {
		const match = html.match(pat);
		if (!match?.[1]) continue;
		try {
			return JSON.parse(match[1]);
		} catch {
			continue;
		}
	}
	return null;
}
var session = {
	jar: {},
	profile: pickProfile(),
	deviceId: randomDeviceId(),
	lastWarmup: 0,
	blockUntil: 0,
	consecutiveBlocks: 0,
	inflightWarmup: null
};
function rotateIdentity() {
	session.profile = pickProfile(Date.now() + Math.floor(Math.random() * 99));
	session.deviceId = randomDeviceId();
}
function noteBlock() {
	session.consecutiveBlocks += 1;
	const delay = Math.min(9e4, 2500 * 2 ** Math.min(session.consecutiveBlocks, 5));
	session.blockUntil = Math.max(session.blockUntil, Date.now() + delay);
	if (session.consecutiveBlocks >= 2) rotateIdentity();
}
function noteOk() {
	session.consecutiveBlocks = 0;
}
async function warmup() {
	if (session.inflightWarmup) {
		await session.inflightWarmup;
		return;
	}
	if (Date.now() - session.lastWarmup < 24e4 && Object.keys(session.jar).length > 0) return;
	const run = (async () => {
		try {
			const res = await fetch("https://www.tiktok.com/", {
				headers: htmlHeaders("tiktok", session.profile, cookieHeader(session.jar)),
				redirect: "follow",
				signal: AbortSignal.timeout(8e3)
			});
			session.jar = mergeCookies(session.jar, parseSetCookie(res.headers));
			session.lastWarmup = Date.now();
			await res.arrayBuffer();
		} catch {
			session.lastWarmup = Date.now();
		}
	})();
	session.inflightWarmup = run;
	try {
		await run;
	} finally {
		session.inflightWarmup = null;
	}
}
async function fetchText(url, username, timeoutMs, html = false) {
	if (Date.now() < session.blockUntil) await sleep(Math.min(4e3, session.blockUntil - Date.now()));
	await warmup();
	const cookie = cookieHeader(session.jar);
	const headers = html ? htmlHeaders(username, session.profile, cookie) : stealthHeaders(username, session.profile, cookie);
	try {
		const res = await fetch(url, {
			headers,
			redirect: "follow",
			signal: AbortSignal.timeout(timeoutMs)
		});
		session.jar = mergeCookies(session.jar, parseSetCookie(res.headers));
		const text = await res.text();
		const blocked = res.status === 403 || res.status === 429 || res.status === 503;
		if (blocked) noteBlock();
		else if (res.status < 400) noteOk();
		return {
			status: res.status,
			text,
			blocked
		};
	} catch (err) {
		const name = err instanceof Error ? err.name : "";
		if (name === "AbortError" || name === "TimeoutError") throw new Error("timeout");
		throw err;
	}
}
function parseJsonLoose(text) {
	try {
		return JSON.parse(text);
	} catch {
		return null;
	}
}
function roomUrls(username) {
	const encoded = encodeURIComponent(username);
	const list = [
		`https://www.tiktok.com/api-live/user/room/?${webQuery(session.profile, {
			uniqueId: username,
			unique_id: username,
			sourceType: "54"
		})}`,
		`https://webcast.tiktok.com/webcast/room/info_by_user/?aid=1988&unique_id=${encoded}&device_id=${session.deviceId}`,
		`https://m.tiktok.com/api-live/user/room/?aid=1988&sourceType=54&uniqueId=${encoded}`
	];
	for (let i = list.length - 1; i > 0; i -= 1) {
		const j = Math.floor(Math.random() * (i + 1));
		const tmp = list[i];
		list[i] = list[j];
		list[j] = tmp;
	}
	return list;
}
async function fetchRoom(username, deep) {
	let lastStatus = 0;
	let blocked = false;
	let lastError = "";
	let endpoint = "";
	for (const url of roomUrls(username)) try {
		await sleep(jitter(80, 60));
		const got = await fetchText(url, username, 5500);
		lastStatus = got.status;
		endpoint = url.split("?")[0] ?? url;
		if (got.blocked) {
			blocked = true;
			lastError = `HTTP ${got.status}`;
			continue;
		}
		if (got.status >= 400) {
			lastError = `HTTP ${got.status}`;
			continue;
		}
		const data = parseJsonLoose(got.text);
		const room = data ? parseLiveRoom(username, data) : null;
		if (room) return {
			room,
			status: got.status,
			blocked: false,
			error: "",
			endpoint
		};
	} catch (err) {
		lastError = err instanceof Error ? err.message : "şəbəkə";
	}
	if (!deep) return {
		room: null,
		status: lastStatus,
		blocked,
		error: lastError,
		endpoint
	};
	try {
		const got = await fetchText(`https://www.tiktok.com/@${encodeURIComponent(username)}/live`, username, 9e3, true);
		lastStatus = got.status;
		endpoint = "html:/live";
		if (got.blocked) return {
			room: null,
			status: got.status,
			blocked: true,
			error: `HTTP ${got.status}`,
			endpoint
		};
		const blob = extractHydration(got.text);
		const room = blob ? parseLiveRoom(username, blob) : null;
		return {
			room,
			status: got.status,
			blocked: false,
			error: room ? "" : lastError,
			endpoint
		};
	} catch (err) {
		return {
			room: null,
			status: lastStatus,
			blocked,
			error: err instanceof Error ? err.message : lastError || "şəbəkə",
			endpoint
		};
	}
}
async function fetchBox(username, roomId) {
	const encoded = encodeURIComponent(roomId);
	const urls = [
		`https://webcast.tiktok.com/webcast/room/info/?aid=1988&room_id=${encoded}&device_id=${session.deviceId}`,
		`https://webcast.tiktok.com/webcast/envelope/list/?aid=1988&room_id=${encoded}`,
		`https://webcast.tiktok.com/webcast/room/enter/?aid=1988&room_id=${encoded}`
	];
	for (const url of urls) try {
		await sleep(jitter(60, 40));
		const got = await fetchText(url, username, 8e3);
		if (got.status >= 400) continue;
		const data = parseJsonLoose(got.text);
		const box = data ? extractTreasureBox(data) : null;
		if (box) return box;
	} catch {
		continue;
	}
	return null;
}
async function scanOne(username, deep = false) {
	const name = normalizeUsername(username) ? username.replace(/^@+/, "").trim() : username;
	const base = {
		username: name,
		uniqueId: name,
		exactMatch: true,
		live: false,
		roomId: "",
		viewers: 0,
		title: "",
		liveUrl: `https://www.tiktok.com/@${name}/live`,
		httpStatus: 0,
		blocked: false,
		error: "",
		box: null,
		endpoint: "",
		stealth: true
	};
	const fetched = await fetchRoom(name, deep);
	base.httpStatus = fetched.status;
	base.blocked = fetched.blocked;
	base.error = fetched.error;
	base.endpoint = fetched.endpoint;
	if (!fetched.room) return base;
	const room = fetched.room;
	base.uniqueId = room.uniqueId;
	base.exactMatch = room.exactMatch;
	base.live = room.exactMatch;
	base.roomId = room.roomId;
	base.viewers = room.viewers;
	base.title = room.title;
	base.liveUrl = room.liveUrl;
	if (room.exactMatch && room.roomId) base.box = await fetchBox(name, room.roomId);
	return base;
}
var scanLiveBatch_createServerFn_handler = createServerRpc({
	id: "cf4e33755709492a11bb9481d4c66b8242f1f8cb7a69ec3202f23e3efab32844",
	name: "scanLiveBatch",
	filename: "src/lib/probe-live.ts"
}, (opts) => scanLiveBatch.__executeServer(opts));
var scanLiveBatch = createServerFn({ method: "POST" }).validator(object({ usernames: array(string().min(1).max(64)).min(1).max(6) })).handler(scanLiveBatch_createServerFn_handler, async ({ data }) => {
	const hits = [];
	for (const name of data.usernames) {
		hits.push(await scanOne(name, false));
		await sleep(jitter(120, 80));
	}
	return {
		hits,
		cooling: Date.now() < session.blockUntil,
		blockHits: session.consecutiveBlocks
	};
});
var probeUserLive_createServerFn_handler = createServerRpc({
	id: "546d6aaf7a0a06d24e79f90b87080c080c75d7b7dbb2f0a3bcfbe355bff243a5",
	name: "probeUserLive",
	filename: "src/lib/probe-live.ts"
}, (opts) => probeUserLive.__executeServer(opts));
var probeUserLive = createServerFn({ method: "POST" }).validator(object({ username: string().min(1).max(64) })).handler(probeUserLive_createServerFn_handler, async ({ data }) => {
	return await scanOne(data.username, true);
});
//#endregion
export { probeUserLive_createServerFn_handler, scanLiveBatch_createServerFn_handler };
