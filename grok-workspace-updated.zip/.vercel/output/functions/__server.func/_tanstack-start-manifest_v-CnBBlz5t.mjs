//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CnBBlz5t.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BwjeN0cC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BwjeN0cC.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-6hbj1ISO.js"]
	}
} });
//#endregion
export { tsrStartManifest };
