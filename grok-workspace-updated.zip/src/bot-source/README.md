# SandıqRadar — dəqiq canlı sandıq / hədiyyə çantası botu

Həqiqi TikTok unique_id siyahısını rəsmi API-siz tarayan mühərrik.
Yalnız **dəqiq eyni istifadəçi adı** canlıdırsa və aktiv **sandıq** və ya
**hədiyyə çantası** varsa Telegram-a Azərbaycan dilində xəbərdarlıq göndərir.

## Dəqiqlik

- `uniqueId` eyni olmalıdır (`ramiz_real1` keçmir).
- Yalnız `status=2` canlıdır.
- Növ: `business_type=1` → **Sandıq**, `business_type=2` → **Hədiyyə çantası**.
- Canlıdakı nəfər = cari `user_count` (enter_count ümumi girişdir, götürülmür).
- Duplicate: eyni `box_id` bir dəfə.
- Rate = jeton / yer.

## Anti-blok (STEALTH=true)

- Cookie warmup (`ttwid` sessiyası)
- UA + Client Hints rotasiyası
- Təsadüfi `device_id`
- 403/429-da eksponensial backoff
- Proxy yoxdursa paralel worker 8-ə enir
- Residential proxy (`proxies.txt`) tövsiyə olunur — datacenter IP kəsilir

## Qurulum

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

`.env` içində token və chat ID doldurun. İstəyə görə: `pip install TikTokLive`

```bash
python main.py
python test_parser.py
```

Dayandırmaq: `Ctrl+C`.
