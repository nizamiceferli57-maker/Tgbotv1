"""Parser və dəqiq kimlik testləri — şəbəkə yoxdur."""

from __future__ import annotations

from identity import identity_matches, normalize_username, usernames_match
from models import LiveRoom
from parser import classify_box_kind, extract_treasure_box, is_active_split_box, parse_count, parse_live_room


def test_identity() -> None:
    assert usernames_match("Ramiz_Real", "ramiz_real")
    assert usernames_match("@w777789", "w777789")
    assert usernames_match(".qara_010", ".qara_010")
    assert not usernames_match("ramiz_real", "ramiz_real1")
    assert not usernames_match("sion..0502", "sion.0502")
    assert normalize_username(" @Elvin_Live ") == "elvin_live"


def test_live_status_2_only() -> None:
    live = {
        "data": {
            "user": {"uniqueId": "ramiz_real"},
            "liveRoom": {"status": 2, "roomID": "712345", "userCount": 88, "title": "live"},
        }
    }
    room = parse_live_room("ramiz_real", live)
    assert room is not None
    assert room.room_id == "712345"
    assert room.viewers == 88
    assert room.exact_match
    assert room.title == "live"

    offline = {
        "data": {
            "user": {"uniqueId": "ramiz_real"},
            "liveRoom": {"status": 4, "roomID": "712345", "userCount": 0},
        }
    }
    assert parse_live_room("ramiz_real", offline) is None


def test_mismatch_rejected() -> None:
    payload = {
        "data": {
            "user": {"uniqueId": "ramiz_real1"},
            "liveRoom": {"status": 2, "roomID": "99", "userCount": 10},
        }
    }
    assert parse_live_room("ramiz_real", payload) is None
    assert not identity_matches("ramiz_real", payload)


def test_viewers_ignore_enter_count() -> None:
    payload = {
        "data": {
            "user": {"uniqueId": "zevs_show"},
            "liveRoom": {
                "status": 2,
                "roomID": "99",
                "userCount": 42,
                "liveRoomStats": {"userCount": 42, "enterCount": 9999},
            },
        }
    }
    room = parse_live_room("zevs_show", payload)
    assert room is not None
    assert room.viewers == 42


def test_parse_count_units() -> None:
    assert parse_count("1.2K") == 1200
    assert parse_count("2.5M") == 2_500_000
    assert parse_count(88) == 88


def test_box_vs_catalog() -> None:
    catalog = {"id": 1, "name": "Rose", "diamond_count": 1, "image": {"url_list": []}}
    assert not is_active_split_box(catalog)

    envelope = {
        "envelope_info": {
            "envelope_id": "env-1",
            "diamond_count": 50,
            "people_count": 10,
            "joined_count": 8,
            "remain_time": 40,
            "name": "Sandıq",
            "business_type": 1,
        }
    }
    room = LiveRoom(
        username="ramiz_real",
        unique_id="ramiz_real",
        room_id="1",
        viewers=1250,
        live_url="https://www.tiktok.com/@ramiz_real/live",
    )
    box = extract_treasure_box(envelope, room)
    assert box is not None
    assert box.total_coins == 50
    assert box.total_slots == 10
    assert box.rate == 5
    assert box.participants_count == 8
    assert box.kind == "chest"
    assert box.gift_type == "Sandıq"


def test_gift_bag_business_type_2() -> None:
    payload = {
        "envelope_info": {
            "envelope_id": "bag-9",
            "diamond_count": 30,
            "people_count": 10,
            "joined_count": 6,
            "business_type": 2,
            "name": "Gift Bag",
        }
    }
    room = LiveRoom(username="zevs_show", unique_id="zevs_show", room_id="2", viewers=840)
    box = extract_treasure_box(payload, room)
    assert box is not None
    assert box.kind == "gift_bag"
    assert box.gift_type == "Hədiyyə çantası"


def test_classify_default_chest() -> None:
    kind, label, conf, _ = classify_box_kind({"envelope_id": "x", "diamond_count": 10, "people_count": 5})
    assert kind == "chest"
    assert label == "Sandıq"
    assert conf >= 50


if __name__ == "__main__":
    test_identity()
    test_live_status_2_only()
    test_mismatch_rejected()
    test_viewers_ignore_enter_count()
    test_parse_count_units()
    test_box_vs_catalog()
    test_gift_bag_business_type_2()
    test_classify_default_chest()
    print("ok")
