"""TikTok canlı otaq və sandıq/hədiyyə çantası parseri."""

from __future__ import annotations

import json
import re
import time
from typing import Any
from collections.abc import Iterable

from identity import extract_unique_ids, usernames_match
from models import BOX_KIND_LABEL, LiveRoom, TreasureBox

LIVE_STATUS = {2}

_BOX_HINTS = frozenset(
    {
        "treasure_box",
        "treasurebox",
        "gift_box",
        "giftbox",
        "gift_bag",
        "giftbag",
        "lucky_box",
        "luckybox",
        "box_info",
        "boxinfo",
        "chest",
        "chest_info",
        "sandiq",
        "activity_box",
        "portal_box",
        "envelope_info",
        "envelop_info",
        "envelope",
        "envelop",
        "lucky_money",
        "red_packet",
        "redpacket",
        "box_list",
        "envelope_list",
        "portal",
        "anchor_gift_box",
        "anchorgiftbox",
        "bag_info",
        "lottery_box",
        "split_box",
        "coin_box",
    }
)
_COIN_KEYS = (
    "diamond_count",
    "diamondcount",
    "total_coins",
    "totalcoins",
    "reward_coins",
    "coins",
    "coin_count",
    "coins_count",
    "diamond_count_value",
    "total_diamond",
    "diamond",
    "reward_diamond",
)
_SLOT_KEYS = (
    "people_count",
    "peoplecount",
    "total_slots",
    "totalslots",
    "max_user",
    "max_users",
    "user_limit",
    "join_limit",
    "unpack_user_count",
    "capacity",
    "slots",
    "max_count",
    "target_user_count",
    "max_people",
    "people_num",
    "total_people",
)
_PART_KEYS = (
    "joined_count",
    "join_count",
    "current_user",
    "participants",
    "joined",
    "participate_count",
    "unpack_count",
    "open_count",
    "current_people",
    "joined_user_count",
    "now_count",
)
_ID_KEYS = (
    "envelope_id",
    "envelop_id",
    "box_id",
    "activity_id",
    "treasure_id",
    "id_str",
    "id",
)
_TYPE_KEYS = ("name", "title", "type", "gift_name", "box_name", "desc", "business_type", "display_text")
_REMAIN_KEYS = (
    "remain_time",
    "left_time",
    "remain_seconds",
    "countdown",
    "unpack_at",
    "end_time",
    "expire_at",
)
_SENDER_KEYS = ("send_user_name", "send_username", "sender_name", "from_user")
_VIEWER_KEYS = (
    "userCount",
    "user_count",
    "viewer_count",
    "viewerCount",
    "audienceCount",
    "audience_count",
    "current_user_count",
    "online_user_count",
    "watching_count",
    "display_long",
    "display_value",
)

_HYDRATION = (
    r'<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.+?)</script>',
    r"window\['SIGI_STATE'\]\s*=\s*(\{.+?\});",
    r'window\["SIGI_STATE"\]\s*=\s*(\{.+?\});',
    r'<script id="SIGI_STATE"[^>]*>(.+?)</script>',
    r'<script id="__NEXT_DATA__"[^>]*>(.+?)</script>',
)

_CHEST_WORDS = re.compile(
    r"(sand[ıi]q|chest|treasure|mystery\s*box|x[əe]zin[əe]|sunduk|hazine|сундук|treasure_box|treasurebox)",
    re.I,
)
_BAG_WORDS = re.compile(
    r"(çanta|canta|bag|gift\s*bag|giftbag|lucky\s*bag|h[əe]diyy[əe]\s*çantas|hediye\s*cantasi|gift_box|giftbox)",
    re.I,
)
_ENVELOPE_WORDS = re.compile(r"(z[əe]rf|red\s*packet|redpacket|lucky\s*money|hongbao|红包)", re.I)
_LUCKY_WORDS = re.compile(r"([şs]ans|lucky\s*box|luckybox)", re.I)
_PORTAL_WORDS = re.compile(r"\bportal\b", re.I)


def parse_count(value: Any) -> int | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)) and value == value:
        return max(0, int(value))
    text = str(value).strip().replace(" ", "").replace(",", "")
    if not text:
        return None
    match = re.match(r"^([\d.]+)\s*([kKmMbB])?$", text)
    if not match:
        try:
            return max(0, int(float(text)))
        except (TypeError, ValueError):
            return None
    n = float(match.group(1))
    unit = (match.group(2) or "").lower()
    if unit == "k":
        n *= 1000
    elif unit == "m":
        n *= 1_000_000
    elif unit == "b":
        n *= 1_000_000_000
    return max(0, int(n))


def classify_box_kind(node: dict[str, Any]) -> tuple[str, str, int, list[str]]:
    score = {"chest": 0, "gift_bag": 0, "envelope": 0, "portal": 0, "lucky": 0}
    signals: list[str] = []
    keys = {str(k).lower() for k in node.keys()}
    lower = {str(k).lower(): v for k, v in node.items()}
    texts = [str(lower.get(k, "")) for k in ("name", "title", "type", "gift_name", "box_name", "desc", "display_text")]
    blob = " ".join(texts + list(keys))

    business = str(lower.get("business_type") or lower.get("businesstype") or lower.get("biz_type") or "").strip().lower()
    if business in {"1", "user_diamond", "userdiamond", "treasure"}:
        score["chest"] += 48
        signals.append("business_type=1 (sandıq)")
    elif business in {"2", "platform_diamond", "platformdiamond", "gift_bag"}:
        score["gift_bag"] += 48
        signals.append("business_type=2 (hədiyyə çantası)")

    env_type = str(lower.get("envelope_type") or lower.get("envelopetype") or lower.get("box_type") or "").strip().lower()
    if env_type in {"2", "portal"}:
        score["portal"] += 40
        signals.append("envelope_type=portal")

    if any("portal_box" in k or "portalbox" in k for k in keys):
        score["portal"] += 28
        signals.append("portal_box sahəsi")
    if any(tok in k for k in keys for tok in ("treasure_box", "treasurebox", "chest_info", "anchor_gift_box")):
        score["chest"] += 22
        signals.append("treasure/chest sahəsi")
    if any(tok in k for k in keys for tok in ("gift_bag", "giftbag", "bag_info", "gift_box", "giftbox")):
        score["gift_bag"] += 22
        signals.append("gift bag sahəsi")
    if any("lucky_box" in k or "luckybox" in k for k in keys):
        score["lucky"] += 24
        signals.append("lucky_box sahəsi")
    if any(tok in k for k in keys for tok in ("red_packet", "redpacket", "lucky_money")):
        score["envelope"] += 24
        signals.append("red packet sahəsi")

    if _CHEST_WORDS.search(blob):
        score["chest"] += 26
        signals.append("ad: sandıq")
    if _BAG_WORDS.search(blob):
        score["gift_bag"] += 26
        signals.append("ad: hədiyyə çantası")
    if _ENVELOPE_WORDS.search(blob) and "envelope_id" not in blob:
        score["envelope"] += 20
        signals.append("ad: zərf")
    if _LUCKY_WORDS.search(blob) and not _BAG_WORDS.search(blob):
        score["lucky"] += 18
        signals.append("ad: şans")
    if _PORTAL_WORDS.search(blob):
        score["portal"] += 18
        signals.append("ad: portal")

    ranked = sorted(score.items(), key=lambda kv: kv[1], reverse=True)
    best, best_score = ranked[0]
    second = ranked[1][1] if len(ranked) > 1 else 0
    if best_score <= 0:
        if any(k in keys for k in ("envelope_id", "envelop_id", "box_id", "treasure_id")):
            return "chest", BOX_KIND_LABEL["chest"], 58, ["standart bölünən zərf → Sandıq"]
        return "unknown", BOX_KIND_LABEL["unknown"], 30, ["zəif siqnal"]
    conf = min(99, 52 + best_score + min(18, best_score - second))
    return best, BOX_KIND_LABEL[best], conf, signals


def parse_live_room(username: str, data: Any) -> LiveRoom | None:
    if not isinstance(data, dict):
        return None
    nested = data.get("data") if isinstance(data.get("data"), dict) else data
    live_room = _pick_live_room_node(nested if isinstance(nested, dict) else data)
    if live_room is None:
        live_room = nested if isinstance(nested, dict) else {}

    status = _first_int(data, ("status", "liveRoomStatus", "room_status", "live_status"))
    if status is None:
        status = _first_int(live_room, ("status", "live_status", "room_status", "liveRoomStatus"))
    is_live_flag = bool(live_room.get("isLive") or live_room.get("is_live")) if isinstance(live_room, dict) else False

    room_id = _stringify(
        _first(live_room, ("roomID", "room_id", "id_str", "id"))
        or _first(nested if isinstance(nested, dict) else {}, ("roomId", "room_id", "roomID"))
        or _first(data, ("roomId", "room_id"))
    )
    if room_id in {"0", "None", "null"}:
        room_id = ""

    live_by_status = status in LIVE_STATUS
    if (not live_by_status and not is_live_flag) or not room_id:
        return None
    if status in {1, 4}:
        return None

    unique_ids = extract_unique_ids(data)
    unique_id = next((u for u in unique_ids if usernames_match(username, u)), "")
    if unique_ids and not unique_id:
        return None
    if not unique_id:
        unique_id = username

    viewers = _extract_viewers(live_room if isinstance(live_room, dict) else {}, nested if isinstance(nested, dict) else {})
    title = str(_first(live_room, ("title", "room_title", "live_room_title")) or "")
    started = _first_int(live_room, ("start_time", "startTime", "create_time", "createTime")) or 0
    if started > 10_000_000_000:
        started = started // 1000
    return LiveRoom(
        username=username,
        unique_id=unique_id,
        room_id=room_id,
        viewers=max(0, viewers),
        title=title,
        live_url=f"https://www.tiktok.com/@{unique_id or username}/live",
        exact_match=usernames_match(username, unique_id),
        started_at=started,
        peak_viewers=max(0, viewers),
    )


def extract_hydration(html: str) -> Any | None:
    if not html:
        return None
    for pat in _HYDRATION:
        match = re.search(pat, html, re.DOTALL)
        if not match:
            continue
        raw = match.group(1).strip()
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            continue
    return None


def extract_treasure_box(payload: Any, room: LiveRoom) -> TreasureBox | None:
    boxes = extract_treasure_boxes(payload, room)
    if not boxes:
        return None
    return _best_box(boxes)


def extract_treasure_boxes(payload: Any, room: LiveRoom) -> list[TreasureBox]:
    found: list[TreasureBox] = []
    seen: set[str] = set()

    def consider(node: dict[str, Any]) -> None:
        if not is_active_split_box(node):
            return
        box = box_from_node(node, room)
        if box is None:
            return
        key = box.box_id or f"{box.kind}:{box.total_coins}:{box.total_slots}:{box.remain_sec}"
        if key in seen:
            return
        seen.add(key)
        found.append(box)

    def walk(node: Any, depth: int = 0) -> None:
        if node is None or depth > 10:
            return
        if isinstance(node, dict):
            keys = {str(k).lower() for k in node.keys()}
            if keys & _BOX_HINTS:
                for key, val in node.items():
                    if str(key).lower() in _BOX_HINTS:
                        if isinstance(val, dict):
                            consider(val)
                            walk(val, depth + 1)
                        elif isinstance(val, list):
                            for item in val:
                                if isinstance(item, dict):
                                    consider(item)
                                walk(item, depth + 1)
                consider(node)
            elif is_active_split_box(node):
                consider(node)
            for val in node.values():
                walk(val, depth + 1)
        elif isinstance(node, list):
            for item in node[:80]:
                walk(item, depth + 1)

    walk(payload)
    return found


def box_from_node(node: dict[str, Any], room: LiveRoom) -> TreasureBox | None:
    coins = _first_int(node, _COIN_KEYS) or 0
    slots = _first_int(node, _SLOT_KEYS) or 0
    if coins <= 0 or slots <= 0:
        return None
    parts = _first_int(node, _PART_KEYS) or 0
    box_id = str(_first(node, _ID_KEYS) or "")
    kind, label, conf, signals = classify_box_kind(node)
    remain = _remain_sec(node)
    sender = _sender(node)
    return TreasureBox(
        username=room.username,
        room_id=room.room_id,
        gift_type=label,
        kind=kind,
        confidence=conf,
        total_coins=coins,
        total_slots=slots,
        participants_count=min(parts, slots) if parts else parts,
        viewers_count=room.viewers,
        box_id=box_id,
        live_url=room.live_url,
        remain_sec=remain,
        unique_id=room.unique_id,
        sender=sender,
        title=room.title,
        peak_viewers=room.peak_viewers,
        signals=tuple(signals),
    )


def is_active_split_box(node: dict[str, Any]) -> bool:
    if not isinstance(node, dict):
        return False
    if _looks_gift_catalog(node):
        return False
    coins = _first_int(node, _COIN_KEYS)
    slots = _first_int(node, _SLOT_KEYS)
    if not coins or not slots or coins <= 0 or slots <= 0:
        return False
    keys = {str(k).lower() for k in node.keys()}
    has_id = any(k in keys for k in ("envelope_id", "envelop_id", "box_id", "treasure_id", "activity_id"))
    has_join = _first_int(node, _PART_KEYS) is not None
    has_time = any(k in keys for k in _REMAIN_KEYS)
    has_hint = bool(keys & _BOX_HINTS) or any(
        token in " ".join(keys) for token in ("envelope", "envelop", "treasure", "lucky", "chest", "box", "bag", "packet")
    )
    return bool(has_id or has_join or has_time or has_hint)


def _looks_gift_catalog(node: dict[str, Any]) -> bool:
    keys = {str(k).lower() for k in node.keys()}
    giftish = "gift_id" in keys or ("id" in keys and "image" in keys and "name" in keys)
    splitish = any(
        k in keys
        for k in (
            "people_count",
            "total_slots",
            "envelope_id",
            "box_id",
            "join_count",
            "joined_count",
        )
    )
    return giftish and not splitish


def _remain_sec(node: dict[str, Any]) -> int:
    val = _first(node, _REMAIN_KEYS)
    if val is None:
        return 0
    try:
        n = int(val)
    except (TypeError, ValueError):
        return 0
    now = int(time.time())
    if n > now + 5:
        return max(0, n - now)
    if n > 10_000_000_000:
        return max(0, n // 1000 - now)
    return max(0, n)


def _sender(node: dict[str, Any]) -> str:
    val = _first(node, _SENDER_KEYS)
    if isinstance(val, str) and val.strip() and not val.strip().isdigit():
        return val.strip()
    for key in ("send_user", "user", "sender"):
        user = node.get(key)
        if isinstance(user, dict):
            name = _first(user, ("unique_id", "uniqueId", "nickname", "display_id"))
            if isinstance(name, str) and name.strip():
                return name.strip()
    return ""


def _extract_viewers(live_room: dict[str, Any], nested: dict[str, Any]) -> int:
    n = _first_int(live_room, _VIEWER_KEYS)
    if n is not None:
        return n
    stats = live_room.get("liveRoomStats") if isinstance(live_room.get("liveRoomStats"), dict) else None
    if stats is None:
        stats = live_room.get("stats") if isinstance(live_room.get("stats"), dict) else None
    if isinstance(stats, dict):
        n = _first_int(stats, _VIEWER_KEYS)
        if n is not None:
            return n
        # enter_count / enterCount — ümumi giriş, cari nəfər DEYİL
    n = _first_int(nested, _VIEWER_KEYS)
    return n or 0


def _best_box(boxes: list[TreasureBox]) -> TreasureBox:
    def key(b: TreasureBox) -> tuple[int, float, int]:
        return (1 if b.remain_sec > 0 else 0, b.rate, b.total_coins)

    return max(boxes, key=key)


def _pick_live_room_node(nested: Any) -> dict[str, Any] | None:
    if not isinstance(nested, dict):
        return None
    for key in ("liveRoom", "live_room", "room", "liveRoomInfo", "roomInfo", "room_info"):
        val = nested.get(key)
        if isinstance(val, dict):
            return val
    return nested


def _first(node: dict[str, Any], keys: Iterable[str]) -> Any:
    lower = {str(k).lower(): v for k, v in node.items()}
    for key in keys:
        if key.lower() in lower:
            return lower[key.lower()]
    return None


def _first_int(node: Any, keys: Iterable[str]) -> int | None:
    if not isinstance(node, dict):
        return None
    return parse_count(_first(node, keys))


def _stringify(val: Any) -> str:
    if val is None:
        return ""
    return str(val).strip()
