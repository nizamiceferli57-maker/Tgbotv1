"""
Dəqiq istifadəçi kimliyi.

TikTok unique_id böyük/kiçik hərfə həssas deyil, amma durğu (nöqtə, alt xətt)
eyni olmalıdır. Oxşar adlar (ramiz_real1) qəbul edilmir.
"""

from __future__ import annotations

import re
from typing import Any

_AT = re.compile(r"^@+")
_WS = re.compile(r"\s+")


def normalize_username(value: Any) -> str:
    if value is None:
        return ""
    text = _WS.sub("", str(value).strip())
    text = _AT.sub("", text)
    return text.lower()


def usernames_match(requested: str, found: Any) -> bool:
    a = normalize_username(requested)
    b = normalize_username(found)
    return bool(a) and a == b


def extract_unique_ids(payload: Any) -> list[str]:
    """Cavab JSON-undan bütün mümkün unique_id / display_id dəyərlərini çıxarır."""
    found: list[str] = []
    seen: set[str] = set()

    def add(val: Any) -> None:
        name = str(val).strip() if val is not None else ""
        if not name:
            return
        key = normalize_username(name)
        if not key or key in seen:
            return
        seen.add(key)
        found.append(name)

    def walk(node: Any, depth: int = 0) -> None:
        if depth > 8 or node is None:
            return
        if isinstance(node, dict):
            for key, val in node.items():
                lk = str(key).lower()
                if lk in {
                    "uniqueid",
                    "unique_id",
                    "display_id",
                    "displayid",
                    "uniqueidstr",
                }:
                    add(val)
                elif lk in {"user", "owner", "anchor", "ownerinfo", "userinfo"}:
                    walk(val, depth + 1)
                elif isinstance(val, (dict, list)) and depth < 5:
                    walk(val, depth + 1)
        elif isinstance(node, list):
            for item in node[:40]:
                walk(item, depth + 1)

    walk(payload)
    return found


def identity_matches(requested: str, payload: Any) -> bool:
    """
    Cavabda heç unique_id yoxdursa, endpoint username query-si ilə işləyir —
    o zaman uyğunluq qəbul edilir. Əgər unique_id varsa, dəqiq uyğunluq şərtdir.
    """
    ids = extract_unique_ids(payload)
    if not ids:
        return True
    return any(usernames_match(requested, item) for item in ids)
