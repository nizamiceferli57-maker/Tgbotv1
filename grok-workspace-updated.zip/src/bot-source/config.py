"""SandıqRadar konfiqurasiyası."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")


def _int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    return int(raw)


def _float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    return float(raw)


def _bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True, slots=True)
class Config:
    telegram_bot_token: str
    telegram_chat_id: str
    usernames_file: Path
    proxies_file: Path
    check_interval: float
    chest_poll_interval: float
    max_concurrent: int
    max_ws_listeners: int
    request_timeout: float
    min_rate: float
    min_viewers: int
    min_coins: int
    jitter_sec: float
    user_agent_rotate: bool
    dry_run: bool
    strict_identity: bool
    reload_every: int
    warmup_cookies: bool
    stealth: bool

    @classmethod
    def load(cls) -> "Config":
        token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
        chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
        if not token or not chat_id:
            raise RuntimeError("TELEGRAM_BOT_TOKEN və TELEGRAM_CHAT_ID .env faylında mütləqdir.")
        stealth = _bool("STEALTH", True)
        default_conc = 8 if stealth else 24
        return cls(
            telegram_bot_token=token,
            telegram_chat_id=chat_id,
            usernames_file=Path(os.getenv("USERNAMES_FILE", str(ROOT / "usernames.txt"))),
            proxies_file=Path(os.getenv("PROXIES_FILE", str(ROOT / "proxies.txt"))),
            check_interval=_float("CHECK_INTERVAL", 8.0 if stealth else 6.0),
            chest_poll_interval=_float("CHEST_POLL_INTERVAL", 2.5),
            max_concurrent=_int("MAX_CONCURRENT", default_conc),
            max_ws_listeners=_int("MAX_WS_LISTENERS", 16),
            request_timeout=_float("REQUEST_TIMEOUT", 10.0),
            min_rate=_float("MIN_RATE", 1.0),
            min_viewers=_int("MIN_VIEWERS", 0),
            min_coins=_int("MIN_COINS", 0),
            jitter_sec=_float("JITTER_SEC", 1.8 if stealth else 1.2),
            user_agent_rotate=_bool("USER_AGENT_ROTATE", True),
            dry_run=_bool("DRY_RUN", False),
            strict_identity=_bool("STRICT_IDENTITY", True),
            reload_every=_int("RELOAD_EVERY", 8),
            warmup_cookies=_bool("WARMUP_COOKIES", True),
            stealth=stealth,
        )
