"""Brauzer kimliyi, cookie warmup və anti-blok başlıqları."""

from __future__ import annotations

import random
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class BrowserProfile:
    ua: str
    sec_ch_ua: str
    sec_ch_ua_mobile: str
    sec_ch_ua_platform: str
    platform: str
    language: str
    width: str
    height: str


PROFILES: tuple[BrowserProfile, ...] = (
    BrowserProfile(
        ua=(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        ),
        sec_ch_ua='"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        sec_ch_ua_mobile="?0",
        sec_ch_ua_platform='"Windows"',
        platform="Win32",
        language="az-AZ,az;q=0.9,en-US;q=0.8,en;q=0.7",
        width="1920",
        height="1080",
    ),
    BrowserProfile(
        ua=(
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7) AppleWebKit/605.1.15 "
            "(KHTML, like Gecko) Version/18.1 Safari/605.1.15"
        ),
        sec_ch_ua='"Not A(Brand";v="99", "Safari";v="18", "Chromium";v="130"',
        sec_ch_ua_mobile="?0",
        sec_ch_ua_platform='"macOS"',
        platform="MacIntel",
        language="az-AZ,az;q=0.9,en;q=0.7",
        width="1680",
        height="1050",
    ),
    BrowserProfile(
        ua=(
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
        ),
        sec_ch_ua='"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
        sec_ch_ua_mobile="?0",
        sec_ch_ua_platform='"Linux"',
        platform="Linux x86_64",
        language="en-US,en;q=0.9,az;q=0.6",
        width="1920",
        height="1200",
    ),
    BrowserProfile(
        ua=(
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        ),
        sec_ch_ua='"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        sec_ch_ua_mobile="?1",
        sec_ch_ua_platform='"Android"',
        platform="Linux armv8l",
        language="az-AZ,az;q=0.9,en-US;q=0.8",
        width="412",
        height="915",
    ),
    BrowserProfile(
        ua="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0",
        sec_ch_ua='"Not.A/Brand";v="8", "Chromium";v="131"',
        sec_ch_ua_mobile="?0",
        sec_ch_ua_platform='"Windows"',
        platform="Win32",
        language="az,en-US;q=0.8,en;q=0.6",
        width="1536",
        height="864",
    ),
)


def pick_profile() -> BrowserProfile:
    return random.choice(PROFILES)


def random_device_id() -> str:
    digits = [str(random.randint(1, 9))] + [str(random.randint(0, 9)) for _ in range(18)]
    return "".join(digits)


def request_headers(username: str, profile: BrowserProfile, html: bool = False) -> dict[str, str]:
    if html:
        accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
        dest, mode = "document", "navigate"
    else:
        accept = "application/json, text/html;q=0.9, */*;q=0.8"
        dest, mode = "empty", "cors"
    return {
        "User-Agent": profile.ua,
        "Accept": accept,
        "Accept-Language": profile.language,
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Referer": f"https://www.tiktok.com/@{username}/live" if username != "tiktok" else "https://www.tiktok.com/",
        "sec-ch-ua": profile.sec_ch_ua,
        "sec-ch-ua-mobile": profile.sec_ch_ua_mobile,
        "sec-ch-ua-platform": profile.sec_ch_ua_platform,
        "sec-fetch-dest": dest,
        "sec-fetch-mode": mode,
        "sec-fetch-site": "same-origin",
    }


def web_params(profile: BrowserProfile, extra: dict[str, str]) -> dict[str, str]:
    params = {
        "aid": "1988",
        "app_name": "tiktok_web",
        "device_platform": "web",
        "cookie_enabled": "true",
        "screen_width": profile.width,
        "screen_height": profile.height,
        "browser_language": profile.language.split(",")[0],
        "browser_platform": profile.platform,
        "browser_name": "Mozilla",
        "browser_online": "true",
        "timezone_name": "Asia/Baku",
        "webcast_language": "az",
        "app_language": "az",
    }
    params.update(extra)
    return params
