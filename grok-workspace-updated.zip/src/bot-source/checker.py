"""Yüksək dəqiqlikli asinxron tarama mühərriki + stealth."""

from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from collections.abc import Iterable
from typing import Any
from urllib.parse import urlencode

import aiohttp

from config import Config
from models import EngineStats, LiveRoom, TreasureBox
from parser import extract_hydration, extract_treasure_box, parse_live_room
from stealth import pick_profile, random_device_id, request_headers, web_params
from telegram import TelegramDispatcher

logger = logging.getLogger("sandiqradar.checker")


class ProxyRotator:
    def __init__(self, lines: Iterable[str]) -> None:
        self._proxies = [ln.strip() for ln in lines if ln.strip() and not ln.strip().startswith("#")]
        self._i = 0

    def next(self) -> str | None:
        if not self._proxies:
            return None
        proxy = self._proxies[self._i % len(self._proxies)]
        self._i += 1
        return proxy

    @property
    def count(self) -> int:
        return len(self._proxies)


class DuplicateGuard:
    def __init__(self, ttl_sec: float = 900.0) -> None:
        self._ttl = ttl_sec
        self._seen: dict[str, float] = {}

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        self._purge(now)
        if key in self._seen:
            return False
        self._seen[key] = now
        return True

    def forget_prefix(self, prefix: str) -> None:
        drop = [k for k in self._seen if k.startswith(prefix)]
        for k in drop:
            del self._seen[k]

    def _purge(self, now: float) -> None:
        expired = [k for k, ts in self._seen.items() if now - ts > self._ttl]
        for k in expired:
            del self._seen[k]


class MonitorEngine:
    def __init__(
        self,
        config: Config,
        usernames: list[str],
        telegram: TelegramDispatcher,
        proxies: ProxyRotator,
        session: aiohttp.ClientSession,
        reload_usernames=None,
    ) -> None:
        self.config = config
        self.usernames = usernames
        self.telegram = telegram
        self.proxies = proxies
        self.session = session
        self.reload_usernames = reload_usernames
        self.queue: asyncio.Queue[str] = asyncio.Queue()
        workers = config.max_concurrent
        if config.stealth and self.proxies.count == 0:
            workers = min(workers, 8)
        self.sem = asyncio.Semaphore(workers)
        self.dup = DuplicateGuard()
        self.running = False
        self.stats = EngineStats()
        self._live: dict[str, LiveRoom] = {}
        self._watchers: dict[str, asyncio.Task[None]] = {}
        self._profile = pick_profile()
        self._device_id = random_device_id()
        self._backoff_until = 0.0
        self._block_hits = 0

    def _headers(self, username: str, html: bool = False) -> dict[str, str]:
        if self.config.user_agent_rotate:
            self._profile = pick_profile()
        return request_headers(username, self._profile, html=html)

    async def warmup(self) -> None:
        if not self.config.warmup_cookies:
            return
        try:
            timeout = aiohttp.ClientTimeout(total=self.config.request_timeout)
            async with self.session.get(
                "https://www.tiktok.com/",
                headers=self._headers("tiktok", html=True),
                proxy=self.proxies.next(),
                timeout=timeout,
            ) as resp:
                await resp.read()
                logger.info("Cookie warmup: HTTP %s profile=%s", resp.status, self._profile.platform)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Cookie warmup uğursuz: %s", exc)

    async def run(self) -> None:
        self.running = True
        await self.warmup()
        logger.info(
            "Mühərrik start: %s istifadəçi, %s paralel, %s proxy, stealth=%s, strict=%s",
            len(self.usernames),
            self.config.max_concurrent,
            self.proxies.count,
            self.config.stealth,
            self.config.strict_identity,
        )
        n_workers = self.sem._value  # noqa: SLF001
        workers = [asyncio.create_task(self._worker(f"w{i}")) for i in range(max(1, n_workers))]
        feeder = asyncio.create_task(self._feeder())
        reaper = asyncio.create_task(self._reap_watchers())
        reporter = asyncio.create_task(self._reporter())
        warmer = asyncio.create_task(self._rewarm())
        try:
            await asyncio.gather(feeder, reaper, reporter, warmer, *workers)
        finally:
            self.running = False
            for task in workers + [feeder, reaper, reporter, warmer]:
                task.cancel()
            for task in list(self._watchers.values()):
                task.cancel()

    async def stop(self) -> None:
        self.running = False

    async def _rewarm(self) -> None:
        while self.running:
            await asyncio.sleep(240)
            self._profile = pick_profile()
            self._device_id = random_device_id()
            await self.warmup()

    async def _feeder(self) -> None:
        while self.running:
            if self.stats.cycle > 0 and self.stats.cycle % max(1, self.config.reload_every) == 0:
                if self.reload_usernames:
                    fresh = self.reload_usernames()
                    if fresh:
                        self.usernames = fresh
                        logger.info("Siyahı yeniləndi: %s istifadəçi", len(fresh))
            self.stats.cycle += 1
            for name in list(self.usernames):
                if not self.running:
                    break
                await self.queue.put(name)
            jitter = random.uniform(0.0, self.config.jitter_sec)
            sleep_for = self.config.check_interval + jitter
            if time.monotonic() < self._backoff_until:
                sleep_for = max(sleep_for, self._backoff_until - time.monotonic())
            await asyncio.sleep(sleep_for)

    async def _reporter(self) -> None:
        while self.running:
            await asyncio.sleep(20)
            logger.info(
                "stat: yoxlama=%s canlı=%s qutu=%s xəbərdarlıq=%s uyğunsuz=%s http=%s blok=%s",
                self.stats.checks,
                len(self._live),
                self.stats.boxes,
                self.stats.alerts,
                self.stats.mismatches,
                self.stats.http_errors,
                self.stats.blocked,
            )

    async def _worker(self, label: str) -> None:
        while self.running:
            username = await self.queue.get()
            try:
                async with self.sem:
                    if self.config.stealth:
                        await asyncio.sleep(random.uniform(0.05, 0.35))
                    await self._process(username)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.stats.http_errors += 1
                self.stats.last_error = str(exc)
                logger.debug("[%s] @%s xəta: %s", label, username, exc)
            finally:
                self.queue.task_done()

    async def _process(self, username: str) -> None:
        self.stats.checks += 1
        room = await self._fetch_live(username)
        if room is None:
            self._live.pop(username, None)
            task = self._watchers.pop(username, None)
            if task:
                task.cancel()
            return
        if self.config.strict_identity and not room.exact_match:
            self.stats.mismatches += 1
            logger.info("Dəqiq uyğunluq yoxdur, atılır: istənilən=@%s tapılan=@%s", username, room.unique_id)
            return
        prev = self._live.get(username)
        if prev:
            room.peak_viewers = max(prev.peak_viewers, room.viewers)
        self._live[username] = room
        self.stats.live = len(self._live)
        if username not in self._watchers:
            if len(self._watchers) >= self.config.max_ws_listeners:
                box = await self._inspect_chest(room)
                await self._maybe_alert(box)
                return
            self._watchers[username] = asyncio.create_task(self._watch_room(room))

    async def _watch_room(self, room: LiveRoom) -> None:
        username = room.username
        logger.info(
            "Canlı izləmə: @%s room=%s nəfər=%s başlıq=%s",
            room.unique_id or username,
            room.room_id,
            room.viewers,
            room.title or "-",
        )
        try:
            used_ws = await self._watch_tiktoklive(room)
            if used_ws:
                return
            while self.running and username in self._live:
                current = self._live.get(username, room)
                box = await self._inspect_chest(current)
                await self._maybe_alert(box)
                await asyncio.sleep(self.config.chest_poll_interval)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            logger.debug("@%s izləmə xətası: %s", username, exc)
        finally:
            self._watchers.pop(username, None)
            logger.info("Canlı izləmə bitdi: @%s", username)

    async def _reap_watchers(self) -> None:
        while self.running:
            await asyncio.sleep(5)
            live_names = set(self._live)
            for name, task in list(self._watchers.items()):
                if name not in live_names or task.done():
                    if not task.done():
                        task.cancel()
                    self._watchers.pop(name, None)

    async def _maybe_alert(self, box: TreasureBox | None) -> None:
        if box is None:
            return
        if box.rate < self.config.min_rate:
            return
        if box.viewers_count < self.config.min_viewers:
            return
        if box.total_coins < self.config.min_coins:
            return
        if not self.dup.allow(box.dedup_key):
            return
        self.stats.boxes += 1
        self.stats.alerts += 1
        logger.info(
            "QUTU: @%s növ=%s rate=%.2f nəfər=%s qoşulan=%s/%s id=%s etibar=%s",
            box.unique_id or box.username,
            box.gift_type,
            box.rate,
            box.viewers_count,
            box.participants_count,
            box.total_slots,
            box.box_id or "-",
            box.confidence,
        )
        ok = await self.telegram.send_box(box)
        if not ok:
            logger.warning("Telegram göndərilmədi: @%s", box.username)

    async def _fetch_live(self, username: str) -> LiveRoom | None:
        factories = [self._live_api_room, self._live_webcast_by_user, self._live_mobile]
        random.shuffle(factories)
        factories.append(self._live_html)
        for factory in factories:
            try:
                room = await factory(username)
                if room is not None:
                    return room
            except BlockedError:
                self._note_block()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                logger.debug("@%s %s uğursuz: %s", username, factory.__name__, exc)
        return None

    def _note_block(self) -> None:
        self._block_hits += 1
        self.stats.blocked += 1
        delay = min(90.0, 2.0 * (2 ** min(self._block_hits, 5)))
        self._backoff_until = max(self._backoff_until, time.monotonic() + delay)
        self._profile = pick_profile()
        self._device_id = random_device_id()
        if self._block_hits in {1, 5, 15, 40}:
            logger.warning("TikTok blok/429 — %.0fs yavaşlama (hit=%s)", delay, self._block_hits)

    async def _get_json(self, url: str, username: str) -> Any:
        proxy = self.proxies.next()
        timeout = aiohttp.ClientTimeout(total=self.config.request_timeout)
        async with self.session.get(
            url,
            headers=self._headers(username),
            proxy=proxy,
            timeout=timeout,
            allow_redirects=True,
        ) as resp:
            if resp.status in {403, 429, 503}:
                raise BlockedError(f"HTTP {resp.status}")
            if resp.status >= 400:
                raise RuntimeError(f"HTTP {resp.status}")
            ctype = resp.headers.get("Content-Type", "")
            if "json" in ctype:
                return await resp.json(content_type=None)
            text = await resp.text()
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return {"_html": text}

    async def _live_api_room(self, username: str) -> LiveRoom | None:
        params = web_params(self._profile, {"uniqueId": username, "sourceType": "54"})
        url = "https://www.tiktok.com/api-live/user/room/?" + urlencode(params)
        data = await self._get_json(url, username)
        return parse_live_room(username, data)

    async def _live_webcast_by_user(self, username: str) -> LiveRoom | None:
        url = (
            "https://webcast.tiktok.com/webcast/room/info_by_user/"
            f"?aid=1988&unique_id={username}&device_id={self._device_id}"
        )
        data = await self._get_json(url, username)
        return parse_live_room(username, data)

    async def _live_mobile(self, username: str) -> LiveRoom | None:
        url = f"https://m.tiktok.com/api-live/user/room/?aid=1988&sourceType=54&uniqueId={username}"
        data = await self._get_json(url, username)
        return parse_live_room(username, data)

    async def _live_html(self, username: str) -> LiveRoom | None:
        url = f"https://www.tiktok.com/@{username}/live"
        proxy = self.proxies.next()
        timeout = aiohttp.ClientTimeout(total=self.config.request_timeout)
        async with self.session.get(
            url, headers=self._headers(username, html=True), proxy=proxy, timeout=timeout
        ) as resp:
            if resp.status in {403, 429, 503}:
                raise BlockedError(f"HTTP {resp.status}")
            html = await resp.text()
        blob = extract_hydration(html)
        if blob is None:
            return None
        return parse_live_room(username, blob)

    async def _inspect_chest(self, room: LiveRoom) -> TreasureBox | None:
        urls = [
            f"https://webcast.tiktok.com/webcast/room/info/?aid=1988&room_id={room.room_id}&device_id={self._device_id}",
            f"https://webcast.tiktok.com/webcast/room/enter/?aid=1988&room_id={room.room_id}",
            f"https://webcast.tiktok.com/webcast/envelope/list/?aid=1988&room_id={room.room_id}",
        ]
        for url in urls:
            try:
                data = await self._get_json(url, room.username)
            except BlockedError:
                self._note_block()
                continue
            except Exception as exc:  # noqa: BLE001
                logger.debug("otaq info @%s: %s", room.username, exc)
                continue
            box = extract_treasure_box(data, room)
            if box:
                return box
        return None

    async def _watch_tiktoklive(self, room: LiveRoom) -> bool:
        try:
            from TikTokLive import TikTokLiveClient  # type: ignore
            from TikTokLive.events import DisconnectEvent, GiftEvent, LiveEndEvent  # type: ignore
        except Exception:
            return False

        envelope_cls = None
        try:
            from TikTokLive.events import EnvelopeEvent  # type: ignore

            envelope_cls = EnvelopeEvent
        except Exception:
            envelope_cls = None

        client = TikTokLiveClient(unique_id=room.unique_id or room.username)
        done = asyncio.Event()

        @client.on(GiftEvent)
        async def _on_gift(event: Any) -> None:  # noqa: ANN401
            gift = getattr(event, "gift", None)
            name = str(getattr(gift, "name", "") or "")
            lowered = name.lower()
            if not any(
                k in lowered
                for k in ("box", "chest", "treasure", "bag", "sandıq", "sandiq", "çanta", "envelope", "lucky")
            ):
                return
            http_box = await self._inspect_chest(self._live.get(room.username, room))
            if http_box:
                await self._maybe_alert(http_box)

        if envelope_cls is not None:

            @client.on(envelope_cls)
            async def _on_env(event: Any) -> None:  # noqa: ANN401
                info = (
                    getattr(event, "envelope_info", None)
                    or getattr(event, "info", None)
                    or getattr(event, "envelop_info", None)
                    or {}
                )
                node = info if isinstance(info, dict) else _obj_to_dict(info)
                http_box = await self._inspect_chest(self._live.get(room.username, room))
                if http_box:
                    await self._maybe_alert(http_box)
                    return
                if not isinstance(node, dict):
                    return
                box = extract_treasure_box({"envelope_info": node}, self._live.get(room.username, room))
                await self._maybe_alert(box)

        @client.on(DisconnectEvent)
        async def _on_disc(_: Any) -> None:  # noqa: ANN401
            done.set()

        @client.on(LiveEndEvent)
        async def _on_end(_: Any) -> None:  # noqa: ANN401
            done.set()

        try:
            await client.start()
            while self.running and room.username in self._live and not done.is_set():
                http_box = await self._inspect_chest(self._live.get(room.username, room))
                await self._maybe_alert(http_box)
                try:
                    await asyncio.wait_for(done.wait(), timeout=self.config.chest_poll_interval)
                except asyncio.TimeoutError:
                    pass
        finally:
            try:
                await client.disconnect()
            except Exception:
                pass
        return True


class BlockedError(RuntimeError):
    pass


def _obj_to_dict(obj: Any) -> dict[str, Any]:
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    data: dict[str, Any] = {}
    for key in dir(obj):
        if key.startswith("_"):
            continue
        try:
            val = getattr(obj, key)
        except Exception:
            continue
        if callable(val):
            continue
        data[key] = val
    return data
