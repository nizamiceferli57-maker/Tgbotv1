"""SandıqRadar məlumat modelləri."""

from __future__ import annotations

from dataclasses import dataclass, field


BoxKind = str  # chest | gift_bag | envelope | portal | lucky | unknown


BOX_KIND_LABEL = {
    "chest": "Sandıq",
    "gift_bag": "Hədiyyə çantası",
    "envelope": "Zərf",
    "portal": "Portal sandıq",
    "lucky": "Şans qutusu",
    "unknown": "Bölünən qutu",
}


@dataclass(slots=True)
class LiveRoom:
    username: str
    unique_id: str
    room_id: str
    viewers: int
    title: str = ""
    live_url: str = ""
    exact_match: bool = True
    started_at: int = 0
    peak_viewers: int = 0

    def touch_viewers(self, n: int) -> None:
        self.viewers = max(0, n)
        if n > self.peak_viewers:
            self.peak_viewers = n


@dataclass(slots=True)
class TreasureBox:
    username: str
    room_id: str
    gift_type: str
    kind: str
    confidence: int
    total_coins: int
    total_slots: int
    participants_count: int
    viewers_count: int
    box_id: str = ""
    live_url: str = ""
    remain_sec: int = 0
    unique_id: str = ""
    sender: str = ""
    title: str = ""
    peak_viewers: int = 0
    signals: tuple[str, ...] = ()

    @property
    def rate(self) -> float:
        if self.total_slots <= 0:
            return 0.0
        return self.total_coins / float(self.total_slots)

    @property
    def split_label(self) -> str:
        return f"{self.total_coins}/{self.total_slots}"

    @property
    def dedup_key(self) -> str:
        if self.box_id:
            return f"{self.username}:{self.box_id}"
        return f"{self.username}:{self.kind}:{self.total_coins}:{self.total_slots}:{self.gift_type}"


@dataclass(slots=True)
class EngineStats:
    checks: int = 0
    live: int = 0
    boxes: int = 0
    alerts: int = 0
    mismatches: int = 0
    http_errors: int = 0
    blocked: int = 0
    cycle: int = 0
    last_error: str = ""
    extra: dict[str, int] = field(default_factory=dict)
