"""Asinxron Telegram xəbərdarlıq göndəricisi."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import aiohttp

from config import Config
from models import TreasureBox

logger = logging.getLogger("sandiqradar.telegram")

TELEGRAM_API = "https://api.telegram.org"


def _md(text: str) -> str:
    return (
        str(text)
        .replace("\\", "\\\\")
        .replace("_", "\\_")
        .replace("*", "\\*")
        .replace("`", "\\`")
        .replace("[", "\\[")
    )


def _fmt_num(n: int) -> str:
    return f"{int(n):,}".replace(",", " ")


def format_alert(box: TreasureBox) -> str:
    rate = box.rate
    rate_label = str(int(rate)) if rate == int(rate) else f"{rate:.2f}"
    handle = box.unique_id or box.username
    url = box.live_url or f"https://www.tiktok.com/@{handle}/live"
    remain = f"\n⏱ **Qalan vaxt:** {box.remain_sec} san" if box.remain_sec > 0 else ""
    title = f"\n📺 **Yayım:** {_md(box.title)}" if box.title else ""
    sender = f"\n✍️ **Göndərən:** @{_md(box.sender)}" if box.sender else ""
    conf = f"\n🎯 **Növ etibarı:** {box.confidence}%" if box.confidence else ""
    peak = ""
    if box.peak_viewers and box.peak_viewers > box.viewers_count:
        peak = f" (peak {_fmt_num(box.peak_viewers)})"
    return (
        "🚨 **CANLI VƏ QUTU TAPILDI!** 🚨\n"
        "\n"
        f"👤 **İstifadəçi:** @{_md(handle)}\n"
        f"🎁 **Növ:** {_md(box.gift_type)}\n"
        f"👀 **Canlıda nəfər:** {_fmt_num(box.viewers_count)}{peak}\n"
        f"📊 **Bölgü:** {box.total_coins}/{box.total_slots} jeton/yer\n"
        f"💎 **Rate:** {rate_label} jeton/nəfər\n"
        f"👥 **Qutuya qoşulan:** {_fmt_num(box.participants_count)} / {_fmt_num(box.total_slots)} nəfər"
        f"{title}{sender}{remain}{conf}\n"
        f"🔗 **Canlı yayım:** [Yayıma Keç]({url})"
    )


class TelegramDispatcher:
    def __init__(self, config: Config, session: aiohttp.ClientSession) -> None:
        self._config = config
        self._session = session
        self._lock = asyncio.Lock()

    async def test_connection(self) -> bool:
        url = f"{TELEGRAM_API}/bot{self._config.telegram_bot_token}/getMe"
        try:
            async with self._session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                payload: dict[str, Any] = await resp.json(content_type=None)
                if payload.get("ok"):
                    username = payload.get("result", {}).get("username", "?")
                    logger.info("Telegram botu hazırdır: @%s", username)
                    return True
                logger.error("Telegram getMe uğursuz: %s", payload)
                return False
        except Exception as exc:  # noqa: BLE001
            logger.error("Telegram bağlantı xətası: %s", exc)
            return False

    async def send_box(self, box: TreasureBox) -> bool:
        if self._config.dry_run:
            logger.info("[DRY-RUN] Qutu: @%s növ=%s rate=%.2f", box.username, box.gift_type, box.rate)
            return True
        return await self.send_text(format_alert(box))

    async def send_text(self, text: str) -> bool:
        url = f"{TELEGRAM_API}/bot{self._config.telegram_bot_token}/sendMessage"
        body = {
            "chat_id": self._config.telegram_chat_id,
            "text": text,
            "parse_mode": "Markdown",
            "disable_web_page_preview": False,
        }
        async with self._lock:
            delay = 0.05
            for attempt in range(1, 4):
                try:
                    async with self._session.post(
                        url,
                        json=body,
                        timeout=aiohttp.ClientTimeout(total=12),
                    ) as resp:
                        payload: dict[str, Any] = await resp.json(content_type=None)
                        if payload.get("ok"):
                            return True
                        if resp.status == 429:
                            retry_after = float(payload.get("parameters", {}).get("retry_after", 2))
                            logger.warning("Telegram 429 — %.1fs gözlənilir", retry_after)
                            await asyncio.sleep(retry_after)
                            continue
                        logger.error("Telegram xətası: %s", payload.get("description"))
                        return False
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Telegram cəhd %s uğursuz: %s", attempt, exc)
                    await asyncio.sleep(delay)
                    delay *= 2
        return False
