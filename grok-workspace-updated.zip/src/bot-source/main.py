"""SandıqRadar — giriş nöqtəsi."""

from __future__ import annotations

import asyncio
import logging
import signal
import sys
from pathlib import Path

import aiohttp

from checker import MonitorEngine, ProxyRotator
from config import Config
from identity import normalize_username
from telegram import TelegramDispatcher

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("sandiqradar")


def load_lines(path: Path) -> list[str]:
    if not path.exists():
        return []
    names: list[str] = []
    seen: set[str] = set()
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        item = line.lstrip("@").split()[0].strip()
        key = normalize_username(item)
        if key and key not in seen:
            seen.add(key)
            names.append(item)
    return names


async def amain() -> int:
    try:
        config = Config.load()
    except RuntimeError as exc:
        logger.error("%s", exc)
        return 2

    def reload_names() -> list[str]:
        return load_lines(config.usernames_file)

    usernames = reload_names()
    if len(usernames) < 1:
        logger.error(
            "İstifadəçi siyahısı boşdur. %s faylına hər sətirdə bir dəqiq username yazın.",
            config.usernames_file,
        )
        return 2

    proxies = ProxyRotator(load_lines(config.proxies_file) if config.proxies_file.exists() else [])
    timeout = aiohttp.ClientTimeout(total=config.request_timeout)
    jar = aiohttp.CookieJar(unsafe=True)
    connector = aiohttp.TCPConnector(
        limit=max(32, config.max_concurrent * 2),
        ttl_dns_cache=300,
        enable_cleanup_closed=True,
        ssl=True,
    )

    logger.info(
        "Hazırlıq: %s dəqiq kanal, interval=%.1fs, paralel=%s, stealth=%s, min_rate=%.2f",
        len(usernames),
        config.check_interval,
        config.max_concurrent,
        config.stealth,
        config.min_rate,
    )

    async with aiohttp.ClientSession(timeout=timeout, connector=connector, cookie_jar=jar) as session:
        telegram = TelegramDispatcher(config, session)
        if not await telegram.test_connection():
            logger.error("Telegram botu cavab vermir — token/chat_id yoxlanılsın.")
            return 3
        engine = MonitorEngine(
            config,
            usernames,
            telegram,
            proxies,
            session,
            reload_usernames=reload_names,
        )

        loop = asyncio.get_running_loop()
        stop_event = asyncio.Event()

        def _ask_stop() -> None:
            logger.info("Dayandırma siqnalı alındı…")
            engine.running = False
            stop_event.set()

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, _ask_stop)
            except NotImplementedError:
                pass

        runner = asyncio.create_task(engine.run())
        waiter = asyncio.create_task(stop_event.wait())
        done, pending = await asyncio.wait({runner, waiter}, return_when=asyncio.FIRST_COMPLETED)
        engine.running = False
        for task in pending:
            task.cancel()
        if runner in done:
            exc = runner.exception()
            if exc:
                logger.exception("Mühərrik xətası: %s", exc)
                return 1
    logger.info("SandıqRadar dayandı.")
    return 0


def main() -> None:
    try:
        code = asyncio.run(amain())
    except KeyboardInterrupt:
        code = 0
    sys.exit(code)


if __name__ == "__main__":
    main()
