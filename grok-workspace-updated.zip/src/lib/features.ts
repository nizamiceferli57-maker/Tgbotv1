export type Feature = {
  id: string;
  title: string;
  detail: string;
};

export const PRODUCT_FEATURES: Feature[] = [
  { id: "kind", title: "Dəqiq növ", detail: "Sandıq, hədiyyə çantası, zərf, portal və şans qutusu business_type + ad siqnalları ilə ayrılır." },
  { id: "viewers", title: "Canlıda nəfər", detail: "Cari otaq sayı (user_count). Enter_count ümumi girişdir, baxış kimi götürülmür." },
  { id: "joined", title: "Sandığa qoşulan", detail: "Qoşulan / yer sayı (joined/slots) progress bar ilə." },
  { id: "rate", title: "Rate", detail: "Jeton ÷ yer. Minimum rate filtrinə düşməyənlər Telegram-a getmir." },
  { id: "remain", title: "Qalan vaxt", detail: "unpack_at və remain_time-dan gerisayım." },
  { id: "dup", title: "Duplicate qoruma", detail: "Eyni box_id bir dəfə xəbərdarlıq edir, bitəndə açar silinir." },
  { id: "id", title: "Dəqiq unique_id", detail: "ramiz_real1 ramiz_real sayılmır. Durğu işarəsi dəqiq eyni olmalıdır." },
  { id: "status", title: "Yalnız status=2", detail: "status=4 offline-dur, səhvən canlı göstərilmir." },
  { id: "stealth", title: "Stealth rejim", detail: "Aşağı paralel, jitter, insan tempi — TikTok WAF-ı az oyadır." },
  { id: "cookie", title: "Cookie warmup", detail: "ttwid/msToken sessiyası tiktok.com-dan götürülür və sorğulara yapışdırılır." },
  { id: "ua", title: "UA rotasiyası", detail: "Chrome/Safari/Firefox + uyğun sec-ch-ua Client Hints." },
  { id: "device", title: "Cihaz izi", detail: "Hər sessiyada təsadüfi device_id, ekran və dil parametrləri." },
  { id: "backoff", title: "Backoff", detail: "403/429/503-də eksponensial yavaşlama və circuit breaker." },
  { id: "multi", title: "Multi-endpoint", detail: "api-live, webcast, m.tiktok, HTML hydration ehtiyatı." },
  { id: "boxapi", title: "Sandıq API-ləri", detail: "room/info, envelope/list, room/enter eyni otaqda növü dəqiqləşdirir." },
  { id: "priority", title: "Prioritet kanallar", detail: "Seçilmiş adlar hər dövrdə birinci yoxlanır." },
  { id: "filters", title: "Filtrlər", detail: "Min baxış, min jeton, min rate, canlı/sandıq/offline." },
  { id: "sound", title: "Səs siqnalı", detail: "Sandıq tapılanda qısa ton." },
  { id: "notify", title: "Brauzer bildirişi", detail: "Növ + nəfər sayı bildiriş mətnində." },
  { id: "export", title: "İxrac", detail: "Xəbərdarlıqları JSON və CSV kimi endir." },
  { id: "sort", title: "Sıralama", detail: "Baxış, rate və vaxta görə." },
  { id: "stats", title: "Statistika", detail: "Uğur, blok faizi, yoxlama/saniyə, peak baxış." },
  { id: "tg", title: "Telegram", detail: "Növ, canlıdakı nəfər, qoşulan, rate, qalan vaxt — dublikatsız." },
  { id: "probe", title: "Dərin yoxlama", detail: "Tək ad üçün növ + nəfər + etibar faizi." },
  { id: "peak", title: "Peak baxış", detail: "Yayım ərzində ən yüksək nəfər sayı saxlanır." },
  { id: "title", title: "Yayım başlığı", detail: "Otaq title-ı kartda və Telegram-da." },
  { id: "sender", title: "Göndərən", detail: "Sandığı atan unique_id (varsa)." },
  { id: "conf", title: "Etibar faizi", detail: "Növ təsnifatının nə qədər əmin olduğu." },
  { id: "autopause", title: "Avto-pauza", detail: "Blok dalğasında tarama özü yavaşlayır, sonra davam edir." },
  { id: "proxy", title: "Proxy (Python)", detail: "VPS-də residential proxy + per-proxy cookie. Datacenter IP bloklanır." },
  { id: "watch", title: "Canlı izləmə", detail: "Tapılan otaq sandıq üçün sıx poll edilir, offline olanda dayanır." },
  { id: "list", title: "Siyahı idxal", detail: "500+ dəqiq unique_id, oxşar ad yoxdur." },
];
