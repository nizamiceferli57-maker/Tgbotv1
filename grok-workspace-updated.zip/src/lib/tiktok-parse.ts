import { classifyBoxKind, type BoxKind } from "./box-kind.ts";
import { parseCount } from "./format.ts";
import { usernamesMatch } from "./usernames.ts";

export type ParsedRoom = {
  username: string;
  uniqueId: string;
  roomId: string;
  viewers: number;
  title: string;
  liveUrl: string;
  exactMatch: boolean;
  startedAt: number;
  coverUrl: string;
};

export type ParsedBox = {
  giftType: string;
  kind: BoxKind;
  confidence: number;
  totalCoins: number;
  totalSlots: number;
  participants: number;
  boxId: string;
  remainSec: number;
  rate: number;
  sender: string;
  signals: string[];
};

const LIVE_STATUS = new Set([2]);

const BOX_HINTS = new Set([
  "treasure_box",
  "treasurebox",
  "gift_box",
  "giftbox",
  "gift_bag",
  "giftbag",
  "lucky_box",
  "luckybox",
  "box_info",
  "boxinfo",
  "chest",
  "chest_info",
  "sandiq",
  "activity_box",
  "portal_box",
  "envelope_info",
  "envelop_info",
  "envelope",
  "envelop",
  "lucky_money",
  "red_packet",
  "redpacket",
  "box_list",
  "envelope_list",
  "portal",
  "anchor_gift_box",
  "anchorgiftbox",
  "bag_info",
  "lottery_box",
  "split_box",
  "coin_box",
]);

const COIN_KEYS = [
  "diamond_count",
  "diamondcount",
  "total_coins",
  "totalcoins",
  "reward_coins",
  "coins",
  "coin_count",
  "coins_count",
  "diamond",
  "total_diamond",
  "diamond_count_value",
  "reward_diamond",
];
const SLOT_KEYS = [
  "people_count",
  "peoplecount",
  "total_slots",
  "totalslots",
  "max_user",
  "max_users",
  "user_limit",
  "join_limit",
  "unpack_user_count",
  "capacity",
  "slots",
  "max_count",
  "target_user_count",
  "max_people",
  "people_num",
  "total_people",
];
const PART_KEYS = [
  "joined_count",
  "join_count",
  "current_user",
  "participants",
  "joined",
  "unpack_count",
  "participate_count",
  "open_count",
  "current_people",
  "joined_user_count",
  "now_count",
];
const ID_KEYS = ["envelope_id", "envelop_id", "box_id", "activity_id", "treasure_id", "id_str", "id"];
const TYPE_KEYS = ["name", "title", "type", "gift_name", "box_name", "desc", "business_type", "display_text"];
const REMAIN_KEYS = ["remain_time", "left_time", "remain_seconds", "countdown", "unpack_at", "end_time", "expire_at"];
const SENDER_KEYS = ["send_user_name", "send_username", "sender_name", "from_user", "unique_id", "uniqueid"];
const VIEWER_KEYS = [
  "userCount",
  "user_count",
  "viewer_count",
  "viewerCount",
  "audienceCount",
  "audience_count",
  "current_user_count",
  "online_user_count",
  "watching_count",
  "display_long",
  "display_value",
];

function asRecord(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function first(node: Record<string, unknown>, keys: string[]): unknown {
  const lower = new Map(Object.keys(node).map((k) => [k.toLowerCase(), node[k]]));
  for (const key of keys) {
    if (lower.has(key.toLowerCase())) return lower.get(key.toLowerCase());
  }
  return undefined;
}

function firstInt(node: unknown, keys: string[]): number | null {
  const rec = asRecord(node);
  if (!rec) return null;
  return parseCount(first(rec, keys));
}

function collectUniqueIds(payload: unknown, depth = 0, out: string[] = [], seen = new Set<string>()): string[] {
  if (depth > 8 || payload == null) return out;
  const rec = asRecord(payload);
  if (rec) {
    for (const [key, val] of Object.entries(rec)) {
      const lk = key.toLowerCase();
      if (["uniqueid", "unique_id", "display_id", "displayid", "uniqueidstr"].includes(lk) && typeof val === "string") {
        const k = val.trim().toLowerCase();
        if (k && !seen.has(k)) {
          seen.add(k);
          out.push(val.trim());
        }
      } else if (val && typeof val === "object") {
        collectUniqueIds(val, depth + 1, out, seen);
      }
    }
  } else if (Array.isArray(payload)) {
    for (const item of payload.slice(0, 40)) collectUniqueIds(item, depth + 1, out, seen);
  }
  return out;
}

function pickLiveRoom(nested: Record<string, unknown>): Record<string, unknown> {
  for (const key of ["liveRoom", "live_room", "room", "liveRoomInfo", "roomInfo", "room_info"]) {
    const val = asRecord(nested[key]);
    if (val) return val;
  }
  return nested;
}

function extractViewersFromRoom(liveRoom: Record<string, unknown>, nested: Record<string, unknown>): number {
  const candidates: number[] = [];
  const push = (n: number | null) => {
    if (n !== null && n >= 0) candidates.push(n);
  };
  push(firstInt(liveRoom, VIEWER_KEYS));
  const stats = asRecord(liveRoom.liveRoomStats) ?? asRecord(liveRoom.stats) ?? asRecord(liveRoom.room_stats);
  if (stats) {
    push(firstInt(stats, VIEWER_KEYS));
    // enter_count is cumulative unique joins — NEVER treat as current viewers
  }
  push(firstInt(nested, VIEWER_KEYS));
  const ownerStats = asRecord(asRecord(liveRoom.owner)?.follow_info);
  if (ownerStats) {
    /* ignore follower counts */
  }
  if (candidates.length === 0) return 0;
  return Math.max(0, candidates[0]!);
}

export function parseLiveRoom(username: string, data: unknown): ParsedRoom | null {
  const root = asRecord(data);
  if (!root) return null;
  const nested = asRecord(root.data) ?? root;
  const liveRoom = pickLiveRoom(nested);
  let status = firstInt(root, ["status", "liveRoomStatus", "room_status", "live_status"]);
  if (status === null) status = firstInt(liveRoom, ["status", "live_status", "room_status", "liveRoomStatus"]);
  const isLiveFlag = liveRoom.isLive === true || liveRoom.is_live === true || nested.isLive === true;
  let roomId = String(
    first(liveRoom, ["roomID", "room_id", "id_str", "id"]) ??
      first(nested, ["roomId", "room_id", "roomID"]) ??
      "",
  ).trim();
  if (roomId === "0" || roomId === "None" || roomId === "null") roomId = "";
  const liveByStatus = status !== null && LIVE_STATUS.has(status);
  if ((!liveByStatus && !isLiveFlag) || !roomId) return null;
  if (status === 4 || status === 1) return null;

  const ids = collectUniqueIds(data);
  const uniqueId = ids.find((id) => usernamesMatch(username, id)) ?? "";
  if (ids.length > 0 && !uniqueId) return null;

  const viewers = extractViewersFromRoom(liveRoom, nested);
  const title = String(first(liveRoom, ["title", "room_title", "live_room_title"]) ?? "");
  const startedAt = firstInt(liveRoom, ["start_time", "startTime", "create_time", "createTime"]) ?? 0;
  const cover = String(first(liveRoom, ["coverUrl", "cover_url", "origin_cover"]) ?? "");
  const handle = uniqueId || username;
  return {
    username,
    uniqueId: handle,
    roomId,
    viewers,
    title,
    liveUrl: `https://www.tiktok.com/@${handle}/live`,
    exactMatch: usernamesMatch(username, handle),
    startedAt: startedAt > 10_000_000_000 ? Math.trunc(startedAt / 1000) : startedAt,
    coverUrl: cover,
  };
}

function looksGiftCatalog(node: Record<string, unknown>): boolean {
  const keys = new Set(Object.keys(node).map((k) => k.toLowerCase()));
  const giftish = keys.has("gift_id") || (keys.has("id") && keys.has("image") && keys.has("name"));
  const splitish = ["people_count", "total_slots", "envelope_id", "box_id", "join_count", "joined_count"].some((k) =>
    keys.has(k),
  );
  return giftish && !splitish;
}

export function isActiveSplitBox(node: unknown): boolean {
  const rec = asRecord(node);
  if (!rec || looksGiftCatalog(rec)) return false;
  const coins = firstInt(rec, COIN_KEYS);
  const slots = firstInt(rec, SLOT_KEYS);
  if (!coins || !slots || coins <= 0 || slots <= 0) return false;
  const keys = new Set(Object.keys(rec).map((k) => k.toLowerCase()));
  const hasId = ["envelope_id", "envelop_id", "box_id", "treasure_id", "activity_id"].some((k) => keys.has(k));
  const hasJoin = firstInt(rec, PART_KEYS) !== null;
  const hasTime = REMAIN_KEYS.some((k) => keys.has(k));
  const hasHint =
    [...keys].some((k) => BOX_HINTS.has(k)) ||
    [...keys].some((k) => /envelope|envelop|treasure|lucky|chest|box|bag|packet/.test(k));
  return hasId || hasJoin || hasTime || hasHint;
}

function remainSec(node: Record<string, unknown>): number {
  const val = first(node, REMAIN_KEYS);
  if (val === undefined || val === null) return 0;
  const n = Number(val);
  if (!Number.isFinite(n)) return 0;
  const now = Math.floor(Date.now() / 1000);
  if (n > now + 5) return Math.max(0, Math.trunc(n - now));
  if (n > 10_000_000_000) return Math.max(0, Math.trunc(n / 1000 - now));
  return Math.max(0, Math.trunc(n));
}

function senderOf(node: Record<string, unknown>): string {
  const direct = first(node, SENDER_KEYS);
  if (typeof direct === "string" && direct.trim() && !/^\d+$/.test(direct.trim())) return direct.trim();
  const user = asRecord(node.send_user) ?? asRecord(node.user) ?? asRecord(node.sender);
  if (user) {
    const name = first(user, ["unique_id", "uniqueId", "nickname", "display_id"]);
    if (typeof name === "string" && name.trim()) return name.trim();
  }
  return "";
}

function boxFromNode(node: Record<string, unknown>): ParsedBox | null {
  const coins = firstInt(node, COIN_KEYS) ?? 0;
  const slots = firstInt(node, SLOT_KEYS) ?? 0;
  if (coins <= 0 || slots <= 0) return null;
  const parts = firstInt(node, PART_KEYS) ?? 0;
  const classified = classifyBoxKind(node);
  const rawName = first(node, TYPE_KEYS);
  const giftType =
    classified.kind === "unknown" && typeof rawName === "string" && rawName.trim()
      ? rawName.trim()
      : classified.label;
  return {
    giftType,
    kind: classified.kind,
    confidence: classified.confidence,
    totalCoins: coins,
    totalSlots: slots,
    participants: parts && parts > slots ? slots : Math.max(0, parts),
    boxId: String(first(node, ID_KEYS) ?? ""),
    remainSec: remainSec(node),
    rate: coins / slots,
    sender: senderOf(node),
    signals: classified.signals,
  };
}

function betterBox(a: ParsedBox, b: ParsedBox): ParsedBox {
  if (a.remainSec > 0 && b.remainSec === 0) return a;
  if (b.remainSec > 0 && a.remainSec === 0) return b;
  if (a.rate !== b.rate) return a.rate >= b.rate ? a : b;
  return a.totalCoins >= b.totalCoins ? a : b;
}

export function extractTreasureBoxes(payload: unknown): ParsedBox[] {
  const found: ParsedBox[] = [];
  const seen = new Set<string>();

  const consider = (node: Record<string, unknown>) => {
    if (!isActiveSplitBox(node)) return;
    const box = boxFromNode(node);
    if (!box) return;
    const key = box.boxId || `${box.kind}:${box.totalCoins}:${box.totalSlots}:${box.remainSec}`;
    if (seen.has(key)) return;
    seen.add(key);
    found.push(box);
  };

  const walk = (node: unknown, depth = 0) => {
    if (node == null || depth > 10) return;
    const rec = asRecord(node);
    if (rec) {
      const keys = Object.keys(rec).map((k) => k.toLowerCase());
      if (keys.some((k) => BOX_HINTS.has(k))) {
        for (const [key, val] of Object.entries(rec)) {
          if (!BOX_HINTS.has(key.toLowerCase())) continue;
          const inner = asRecord(val);
          if (inner) {
            consider(inner);
            walk(inner, depth + 1);
          } else if (Array.isArray(val)) {
            for (const item of val) {
              const r = asRecord(item);
              if (r) consider(r);
              walk(item, depth + 1);
            }
          }
        }
        consider(rec);
      } else if (isActiveSplitBox(rec)) {
        consider(rec);
      }
      for (const val of Object.values(rec)) walk(val, depth + 1);
    } else if (Array.isArray(node)) {
      for (const item of node.slice(0, 80)) walk(item, depth + 1);
    }
  };

  walk(payload);
  return found;
}

export function extractTreasureBox(payload: unknown): ParsedBox | null {
  const boxes = extractTreasureBoxes(payload);
  if (boxes.length === 0) return null;
  return boxes.reduce(betterBox);
}

const HYDRATION = [
  /<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.+?)<\/script>/s,
  /window\['SIGI_STATE'\]\s*=\s*(\{.+?\});/s,
  /window\["SIGI_STATE"\]\s*=\s*(\{.+?\});/s,
  /<script id="SIGI_STATE"[^>]*>(.+?)<\/script>/s,
  /<script id="__NEXT_DATA__"[^>]*>(.+?)<\/script>/s,
];

export function extractHydration(html: string): unknown | null {
  for (const pat of HYDRATION) {
    const match = html.match(pat);
    if (!match?.[1]) continue;
    try {
      return JSON.parse(match[1]);
    } catch {
      continue;
    }
  }
  return null;
}

export { classifyBoxKind };
