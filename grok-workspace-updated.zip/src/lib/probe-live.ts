import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import {
  cookieHeader,
  htmlHeaders,
  jitter,
  mergeCookies,
  parseSetCookie,
  pickProfile,
  randomDeviceId,
  sleep,
  stealthHeaders,
  webQuery,
  type BrowserProfile,
} from "@/lib/stealth";
import { extractHydration, extractTreasureBox, parseLiveRoom, type ParsedBox, type ParsedRoom } from "@/lib/tiktok-parse";
import { normalizeUsername } from "@/lib/usernames";

export type ScanHit = {
  username: string;
  uniqueId: string;
  exactMatch: boolean;
  live: boolean;
  roomId: string;
  viewers: number;
  title: string;
  liveUrl: string;
  httpStatus: number;
  blocked: boolean;
  error: string;
  box: ParsedBox | null;
  endpoint: string;
  stealth: boolean;
};

type Session = {
  jar: Record<string, string>;
  profile: BrowserProfile;
  deviceId: string;
  lastWarmup: number;
  blockUntil: number;
  consecutiveBlocks: number;
  inflightWarmup: Promise<void> | null;
};

const session: Session = {
  jar: {},
  profile: pickProfile(),
  deviceId: randomDeviceId(),
  lastWarmup: 0,
  blockUntil: 0,
  consecutiveBlocks: 0,
  inflightWarmup: null,
};

function rotateIdentity() {
  session.profile = pickProfile(Date.now() + Math.floor(Math.random() * 99));
  session.deviceId = randomDeviceId();
}

function noteBlock() {
  session.consecutiveBlocks += 1;
  const delay = Math.min(90_000, 2500 * 2 ** Math.min(session.consecutiveBlocks, 5));
  session.blockUntil = Math.max(session.blockUntil, Date.now() + delay);
  if (session.consecutiveBlocks >= 2) rotateIdentity();
}

function noteOk() {
  session.consecutiveBlocks = 0;
}

async function warmup(): Promise<void> {
  if (session.inflightWarmup) {
    await session.inflightWarmup;
    return;
  }
  if (Date.now() - session.lastWarmup < 4 * 60_000 && Object.keys(session.jar).length > 0) return;
  const run = (async () => {
    try {
      const res = await fetch("https://www.tiktok.com/", {
        headers: htmlHeaders("tiktok", session.profile, cookieHeader(session.jar)),
        redirect: "follow",
        signal: AbortSignal.timeout(8000),
      });
      session.jar = mergeCookies(session.jar, parseSetCookie(res.headers));
      session.lastWarmup = Date.now();
      await res.arrayBuffer();
    } catch {
      session.lastWarmup = Date.now();
    }
  })();
  session.inflightWarmup = run;
  try {
    await run;
  } finally {
    session.inflightWarmup = null;
  }
}

async function fetchText(
  url: string,
  username: string,
  timeoutMs: number,
  html = false,
): Promise<{ status: number; text: string; blocked: boolean }> {
  if (Date.now() < session.blockUntil) {
    await sleep(Math.min(4000, session.blockUntil - Date.now()));
  }
  await warmup();
  const cookie = cookieHeader(session.jar);
  const headers = html
    ? htmlHeaders(username, session.profile, cookie)
    : stealthHeaders(username, session.profile, cookie);
  try {
    const res = await fetch(url, {
      headers,
      redirect: "follow",
      signal: AbortSignal.timeout(timeoutMs),
    });
    session.jar = mergeCookies(session.jar, parseSetCookie(res.headers));
    const text = await res.text();
    const blocked = res.status === 403 || res.status === 429 || res.status === 503;
    if (blocked) noteBlock();
    else if (res.status < 400) noteOk();
    return { status: res.status, text, blocked };
  } catch (err) {
    const name = err instanceof Error ? err.name : "";
    if (name === "AbortError" || name === "TimeoutError") {
      throw new Error("timeout");
    }
    throw err;
  }
}

function parseJsonLoose(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function roomUrls(username: string): string[] {
  const encoded = encodeURIComponent(username);
  const q = webQuery(session.profile, { uniqueId: username, unique_id: username, sourceType: "54" });
  const list = [
    `https://www.tiktok.com/api-live/user/room/?${q}`,
    `https://webcast.tiktok.com/webcast/room/info_by_user/?aid=1988&unique_id=${encoded}&device_id=${session.deviceId}`,
    `https://m.tiktok.com/api-live/user/room/?aid=1988&sourceType=54&uniqueId=${encoded}`,
  ];
  for (let i = list.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = list[i]!;
    list[i] = list[j]!;
    list[j] = tmp;
  }
  return list;
}

async function fetchRoom(
  username: string,
  deep: boolean,
): Promise<{ room: ParsedRoom | null; status: number; blocked: boolean; error: string; endpoint: string }> {
  let lastStatus = 0;
  let blocked = false;
  let lastError = "";
  let endpoint = "";
  for (const url of roomUrls(username)) {
    try {
      await sleep(jitter(80, 60));
      const got = await fetchText(url, username, 5500);
      lastStatus = got.status;
      endpoint = url.split("?")[0] ?? url;
      if (got.blocked) {
        blocked = true;
        lastError = `HTTP ${got.status}`;
        continue;
      }
      if (got.status >= 400) {
        lastError = `HTTP ${got.status}`;
        continue;
      }
      const data = parseJsonLoose(got.text);
      const room = data ? parseLiveRoom(username, data) : null;
      if (room) return { room, status: got.status, blocked: false, error: "", endpoint };
    } catch (err) {
      lastError = err instanceof Error ? err.message : "şəbəkə";
    }
  }
  if (!deep) {
    return { room: null, status: lastStatus, blocked, error: lastError, endpoint };
  }
  try {
    const encoded = encodeURIComponent(username);
    const got = await fetchText(`https://www.tiktok.com/@${encoded}/live`, username, 9000, true);
    lastStatus = got.status;
    endpoint = "html:/live";
    if (got.blocked) {
      return { room: null, status: got.status, blocked: true, error: `HTTP ${got.status}`, endpoint };
    }
    const blob = extractHydration(got.text);
    const room = blob ? parseLiveRoom(username, blob) : null;
    return { room, status: got.status, blocked: false, error: room ? "" : lastError, endpoint };
  } catch (err) {
    return {
      room: null,
      status: lastStatus,
      blocked,
      error: err instanceof Error ? err.message : lastError || "şəbəkə",
      endpoint,
    };
  }
}

async function fetchBox(username: string, roomId: string): Promise<ParsedBox | null> {
  const encoded = encodeURIComponent(roomId);
  const urls = [
    `https://webcast.tiktok.com/webcast/room/info/?aid=1988&room_id=${encoded}&device_id=${session.deviceId}`,
    `https://webcast.tiktok.com/webcast/envelope/list/?aid=1988&room_id=${encoded}`,
    `https://webcast.tiktok.com/webcast/room/enter/?aid=1988&room_id=${encoded}`,
  ];
  for (const url of urls) {
    try {
      await sleep(jitter(60, 40));
      const got = await fetchText(url, username, 8000);
      if (got.status >= 400) continue;
      const data = parseJsonLoose(got.text);
      const box = data ? extractTreasureBox(data) : null;
      if (box) return box;
    } catch {
      continue;
    }
  }
  return null;
}

async function scanOne(username: string, deep = false): Promise<ScanHit> {
  const name = normalizeUsername(username) ? username.replace(/^@+/, "").trim() : username;
  const base: ScanHit = {
    username: name,
    uniqueId: name,
    exactMatch: true,
    live: false,
    roomId: "",
    viewers: 0,
    title: "",
    liveUrl: `https://www.tiktok.com/@${name}/live`,
    httpStatus: 0,
    blocked: false,
    error: "",
    box: null,
    endpoint: "",
    stealth: true,
  };
  const fetched = await fetchRoom(name, deep);
  base.httpStatus = fetched.status;
  base.blocked = fetched.blocked;
  base.error = fetched.error;
  base.endpoint = fetched.endpoint;
  if (!fetched.room) return base;
  const room = fetched.room;
  base.uniqueId = room.uniqueId;
  base.exactMatch = room.exactMatch;
  base.live = room.exactMatch;
  base.roomId = room.roomId;
  base.viewers = room.viewers;
  base.title = room.title;
  base.liveUrl = room.liveUrl;
  if (room.exactMatch && room.roomId) {
    base.box = await fetchBox(name, room.roomId);
  }
  return base;
}

export const scanLiveBatch = createServerFn({ method: "POST" })
  .validator(
    z.object({
      usernames: z.array(z.string().min(1).max(64)).min(1).max(6),
    }),
  )
  .handler(async ({ data }) => {
    const hits: ScanHit[] = [];
    for (const name of data.usernames) {
      hits.push(await scanOne(name, false));
      await sleep(jitter(120, 80));
    }
    return { hits, cooling: Date.now() < session.blockUntil, blockHits: session.consecutiveBlocks };
  });

export const probeUserLive = createServerFn({ method: "POST" })
  .validator(z.object({ username: z.string().min(1).max(64) }))
  .handler(async ({ data }) => {
    const hit = await scanOne(data.username, true);
    return hit;
  });
