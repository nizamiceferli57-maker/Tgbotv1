export type BoxKind = "chest" | "gift_bag" | "envelope" | "portal" | "lucky" | "unknown";

export const BOX_KIND_LABEL: Record<BoxKind, string> = {
  chest: "Sandıq",
  gift_bag: "Hədiyyə çantası",
  envelope: "Zərf",
  portal: "Portal sandıq",
  lucky: "Şans qutusu",
  unknown: "Bölünən qutu",
};

type Score = Record<BoxKind, number>;

const CHEST_WORDS =
  /\b(sand[ıi]q|sanduq|chest|treasure|mystery\s*box|x[əe]zin[əe]|sunduk|hazine|сундук|宝箱|treasure_box|treasurebox)\b/i;
const BAG_WORDS =
  /\b(çanta|canta|bag|gift\s*bag|giftbag|lucky\s*bag|shopping\s*bag|h[əe]diyy[əe]\s*çantas[ıi]|hediye\s*cantasi|purse|福袋|gift_box|giftbox)\b/i;
const ENVELOPE_WORDS = /\b(z[əe]rf|red\s*packet|redpacket|lucky\s*money|hongbao|hong\s*bao|红包|envelop(?:e)?)\b/i;
const LUCKY_WORDS = /\b([şs]ans|lucky\s*box|luckybox)\b/i;
const PORTAL_WORDS = /\b(portal)\b/i;

function emptyScore(): Score {
  return { chest: 0, gift_bag: 0, envelope: 0, portal: 0, lucky: 0, unknown: 0 };
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function lowerKeys(node: Record<string, unknown>): Map<string, unknown> {
  return new Map(Object.keys(node).map((k) => [k.toLowerCase(), node[k]]));
}

function blobText(node: Record<string, unknown>): string {
  const keys = ["name", "title", "type", "gift_name", "box_name", "desc", "description", "display_text", "label"];
  const map = lowerKeys(node);
  const parts: string[] = [];
  for (const key of keys) {
    const val = map.get(key);
    if (typeof val === "string" && val.trim()) parts.push(val);
  }
  parts.push(...Object.keys(node));
  return parts.join(" ").toLowerCase();
}

function numish(value: unknown): string {
  if (value === undefined || value === null) return "";
  return String(value).trim().toLowerCase();
}

/**
 * TikTok envelope business_type:
 *   1 = user diamond treasure box  → Sandıq
 *   2 = platform diamond gift bag  → Hədiyyə çantası
 * envelope_type 2 = portal box.
 */
export function classifyBoxKind(node: unknown): {
  kind: BoxKind;
  label: string;
  confidence: number;
  signals: string[];
} {
  const rec = asRecord(node);
  if (!rec) {
    return { kind: "unknown", label: BOX_KIND_LABEL.unknown, confidence: 0, signals: [] };
  }
  const score = emptyScore();
  const signals: string[] = [];
  const map = lowerKeys(rec);
  const keys = [...map.keys()];
  const text = blobText(rec);

  const business = numish(map.get("business_type") ?? map.get("businesstype") ?? map.get("biz_type"));
  if (business === "1" || business === "user_diamond" || business === "userdiamond" || business === "treasure") {
    score.chest += 48;
    signals.push("business_type=1 (istifadəçi sandığı)");
  } else if (
    business === "2" ||
    business === "platform_diamond" ||
    business === "platformdiamond" ||
    business === "gift_bag"
  ) {
    score.gift_bag += 48;
    signals.push("business_type=2 (platforma hədiyyə çantası)");
  }

  const envelopeType = numish(map.get("envelope_type") ?? map.get("envelopetype") ?? map.get("box_type"));
  if (envelopeType === "2" || envelopeType === "portal") {
    score.portal += 40;
    signals.push("envelope_type=portal");
  }

  if (keys.some((k) => /portal_box|portalbox/.test(k))) {
    score.portal += 28;
    signals.push("portal_box sahəsi");
  }
  if (keys.some((k) => /treasure_box|treasurebox|chest_info|anchor_gift_box/.test(k))) {
    score.chest += 22;
    signals.push("treasure/chest sahəsi");
  }
  if (keys.some((k) => /gift_bag|giftbag|bag_info|gift_box|giftbox/.test(k))) {
    score.gift_bag += 22;
    signals.push("gift bag sahəsi");
  }
  if (keys.some((k) => /lucky_box|luckybox/.test(k))) {
    score.lucky += 24;
    signals.push("lucky_box sahəsi");
  }
  if (keys.some((k) => /red_packet|redpacket|lucky_money/.test(k))) {
    score.envelope += 24;
    signals.push("red packet sahəsi");
  }

  if (CHEST_WORDS.test(text)) {
    score.chest += 26;
    signals.push("ad: sandıq/chest");
  }
  if (BAG_WORDS.test(text)) {
    score.gift_bag += 26;
    signals.push("ad: hədiyyə çantası/bag");
  }
  if (ENVELOPE_WORDS.test(text) && !/envelope_info|envelop_info|envelope_id|envelop_id/.test(text)) {
    score.envelope += 20;
    signals.push("ad: zərf");
  }
  if (LUCKY_WORDS.test(text) && !BAG_WORDS.test(text)) {
    score.lucky += 18;
    signals.push("ad: şans qutusu");
  }
  if (PORTAL_WORDS.test(text)) {
    score.portal += 18;
    signals.push("ad: portal");
  }

  const ranked = (Object.keys(score) as BoxKind[])
    .filter((k) => k !== "unknown")
    .sort((a, b) => score[b] - score[a]);
  const best = ranked[0] ?? "unknown";
  const bestScore = score[best];
  const second = ranked[1] ? score[ranked[1]] : 0;

  if (bestScore <= 0) {
    if (map.has("envelope_id") || map.has("envelop_id") || map.has("box_id") || map.has("treasure_id")) {
      return {
        kind: "chest",
        label: BOX_KIND_LABEL.chest,
        confidence: 58,
        signals: ["standart bölünən zərf → Sandıq"],
      };
    }
    return { kind: "unknown", label: BOX_KIND_LABEL.unknown, confidence: 30, signals: ["zəif siqnal"] };
  }

  const gap = bestScore - second;
  const confidence = Math.min(99, 52 + bestScore + Math.min(18, gap));
  return { kind: best, label: BOX_KIND_LABEL[best], confidence, signals };
}

export function boxKindFromLabel(label: string): BoxKind {
  const t = label.toLowerCase();
  if (t.includes("çanta") || t.includes("canta") || t.includes("bag")) return "gift_bag";
  if (t.includes("portal")) return "portal";
  if (t.includes("zərf") || t.includes("zerf") || t.includes("packet")) return "envelope";
  if (t.includes("şans") || t.includes("sans") || t.includes("lucky")) return "lucky";
  if (t.includes("sandıq") || t.includes("sandiq") || t.includes("chest")) return "chest";
  return "unknown";
}
