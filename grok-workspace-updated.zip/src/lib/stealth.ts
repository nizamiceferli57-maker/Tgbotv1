export type BrowserProfile = {
  ua: string;
  secChUa: string;
  secChUaMobile: "?0" | "?1";
  secChUaPlatform: string;
  platform: string;
  language: string;
  width: string;
  height: string;
};

export const BROWSER_PROFILES: BrowserProfile[] = [
  {
    ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    secChUa: `"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"`,
    secChUaMobile: "?0",
    secChUaPlatform: `"Windows"`,
    platform: "Win32",
    language: "az-AZ,az;q=0.9,en-US;q=0.8,en;q=0.7",
    width: "1920",
    height: "1080",
  },
  {
    ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15",
    secChUa: `"Not A(Brand";v="99", "Safari";v="18", "Chromium";v="130"`,
    secChUaMobile: "?0",
    secChUaPlatform: `"macOS"`,
    platform: "MacIntel",
    language: "az-AZ,az;q=0.9,en;q=0.7",
    width: "1680",
    height: "1050",
  },
  {
    ua: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
    secChUa: `"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"`,
    secChUaMobile: "?0",
    secChUaPlatform: `"Linux"`,
    platform: "Linux x86_64",
    language: "en-US,en;q=0.9,az;q=0.6",
    width: "1920",
    height: "1200",
  },
  {
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1",
    secChUa: `"Not A(Brand";v="8", "Chromium";v="131", "Mobile Safari";v="131"`,
    secChUaMobile: "?1",
    secChUaPlatform: `"iOS"`,
    platform: "iPhone",
    language: "az-AZ,az;q=0.9,en;q=0.7",
    width: "390",
    height: "844",
  },
  {
    ua: "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
    secChUa: `"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"`,
    secChUaMobile: "?1",
    secChUaPlatform: `"Android"`,
    platform: "Linux armv8l",
    language: "az-AZ,az;q=0.9,en-US;q=0.8",
    width: "412",
    height: "915",
  },
  {
    ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0",
    secChUa: `"Not.A/Brand";v="8", "Chromium";v="131"`,
    secChUaMobile: "?0",
    secChUaPlatform: `"Windows"`,
    platform: "Win32",
    language: "az,en-US;q=0.8,en;q=0.6",
    width: "1536",
    height: "864",
  },
];

export function pickProfile(seed = Date.now()): BrowserProfile {
  return BROWSER_PROFILES[Math.abs(seed) % BROWSER_PROFILES.length]!;
}

export function randomDeviceId(): string {
  let id = "";
  for (let i = 0; i < 19; i += 1) id += String(Math.floor(Math.random() * 10));
  if (id[0] === "0") id = `7${id.slice(1)}`;
  return id;
}

export function stealthHeaders(username: string, profile: BrowserProfile, cookie: string): HeadersInit {
  const headers: Record<string, string> = {
    "User-Agent": profile.ua,
    Accept: "application/json, text/html;q=0.9, */*;q=0.8",
    "Accept-Language": profile.language,
    "Cache-Control": "no-cache",
    Pragma: "no-cache",
    Referer: `https://www.tiktok.com/@${username}/live`,
    "sec-ch-ua": profile.secChUa,
    "sec-ch-ua-mobile": profile.secChUaMobile,
    "sec-ch-ua-platform": profile.secChUaPlatform,
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
  };
  if (cookie) headers.Cookie = cookie;
  return headers;
}

export function htmlHeaders(username: string, profile: BrowserProfile, cookie: string): HeadersInit {
  const headers: Record<string, string> = {
    "User-Agent": profile.ua,
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": profile.language,
    Referer: "https://www.tiktok.com/",
    "sec-ch-ua": profile.secChUa,
    "sec-ch-ua-mobile": profile.secChUaMobile,
    "sec-ch-ua-platform": profile.secChUaPlatform,
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "upgrade-insecure-requests": "1",
  };
  if (cookie) headers.Cookie = cookie;
  return headers;
}

export function webQuery(profile: BrowserProfile, extra: Record<string, string>): string {
  const params = new URLSearchParams({
    aid: "1988",
    app_name: "tiktok_web",
    device_platform: "web",
    cookie_enabled: "true",
    screen_width: profile.width,
    screen_height: profile.height,
    browser_language: profile.language.split(",")[0] ?? "az-AZ",
    browser_platform: profile.platform,
    browser_name: "Mozilla",
    browser_online: "true",
    timezone_name: "Asia/Baku",
    webcast_language: "az",
    app_language: "az",
    ...extra,
  });
  return params.toString();
}

export function parseSetCookie(headers: Headers): Record<string, string> {
  const out: Record<string, string> = {};
  const raw =
    typeof headers.getSetCookie === "function"
      ? headers.getSetCookie()
      : (headers.get("set-cookie") ? [headers.get("set-cookie") as string] : []);
  for (const line of raw) {
    const pair = line.split(";")[0];
    if (!pair) continue;
    const eq = pair.indexOf("=");
    if (eq <= 0) continue;
    const name = pair.slice(0, eq).trim();
    const value = pair.slice(eq + 1).trim();
    if (name && value) out[name] = value;
  }
  return out;
}

export function cookieHeader(jar: Record<string, string>): string {
  return Object.entries(jar)
    .map(([k, v]) => `${k}=${v}`)
    .join("; ");
}

export function mergeCookies(jar: Record<string, string>, incoming: Record<string, string>): Record<string, string> {
  return { ...jar, ...incoming };
}

export function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function jitter(baseMs: number, spreadMs: number): number {
  return Math.max(40, Math.round(baseMs + (Math.random() * 2 - 1) * spreadMs));
}
