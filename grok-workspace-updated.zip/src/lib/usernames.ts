import { REAL_WATCHLIST } from "./watchlist.ts";

const AT = /^@+/;

export function normalizeUsername(value: string): string {
  return value.trim().replace(AT, "").replace(/\s+/g, "").toLowerCase();
}

export function usernamesMatch(a: string, b: string): boolean {
  const left = normalizeUsername(a);
  const right = normalizeUsername(b);
  return Boolean(left) && left === right;
}

export function parseUsernameList(raw: string): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const part of raw.split(/[\n,;]+/)) {
    const name = part.trim().replace(AT, "").split(/\s+/)[0] ?? "";
    if (!name || name.startsWith("#")) continue;
    const key = normalizeUsername(name);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(name);
  }
  return out;
}

export type NameMatch = "exact" | "prefix" | "contains";

export type RankedName = {
  name: string;
  match: NameMatch;
};

export function searchUsernames(list: readonly string[], query: string): RankedName[] {
  const q = normalizeUsername(query);
  if (!q) return list.map((name) => ({ name, match: "contains" as const }));
  const exact: RankedName[] = [];
  const prefix: RankedName[] = [];
  const contains: RankedName[] = [];
  for (const name of list) {
    const key = normalizeUsername(name);
    if (key === q) exact.push({ name, match: "exact" });
    else if (key.startsWith(q)) prefix.push({ name, match: "prefix" });
    else if (key.includes(q)) contains.push({ name, match: "contains" });
  }
  return [...exact, ...prefix, ...contains];
}

export function findExactUsername(list: readonly string[], query: string): string | null {
  const q = normalizeUsername(query);
  if (!q) return null;
  return list.find((name) => normalizeUsername(name) === q) ?? null;
}

export function defaultWatchlist(): string[] {
  return [...REAL_WATCHLIST];
}
