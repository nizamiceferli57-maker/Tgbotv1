import { create } from "zustand";
import { persist } from "zustand/middleware";
import { toast } from "sonner";
import { scanLiveBatch, type ScanHit } from "@/lib/probe-live";
import { sendTelegramAlert } from "@/lib/send-telegram";
import { formatNotifyBody, formatTelegramAlert } from "@/lib/telegram-message";
import { playAlertTone, pushBoxNotification } from "@/lib/notify";
import { defaultWatchlist, parseUsernameList } from "@/lib/usernames";
import type {
  ChestAlert,
  EngineStats,
  GateHealth,
  ListFilter,
  Settings,
  SortKey,
  Streamer,
  ViewId,
} from "@/lib/types";

type RadarStore = {
  view: ViewId;
  setView: (view: ViewId) => void;
  usernames: string[];
  setUsernames: (names: string[]) => void;
  restoreWatchlist: () => void;
  settings: Settings;
  patchSettings: (patch: Partial<Settings>) => void;
  running: boolean;
  start: () => void;
  stop: () => void;
  stats: EngineStats;
  live: Streamer[];
  ticker: string[];
  alerts: ChestAlert[];
  workersBusy: number;
  health: GateHealth;
  healthNote: string;
  listFilter: ListFilter;
  setListFilter: (f: ListFilter) => void;
  sortKey: SortKey;
  setSortKey: (k: SortKey) => void;
  sendAlert: (alert: ChestAlert) => Promise<void>;
  injectSample: (kind?: "chest" | "gift_bag") => void;
  clearAlerts: () => void;
};

const defaultSettings: Settings = {
  telegramToken: "",
  telegramChatId: "",
  autoTelegram: false,
  concurrency: 12,
  intervalMs: 8000,
  minRate: 1,
  minViewers: 0,
  minCoins: 0,
  proxiesText: "",
  stealthMode: true,
  soundAlerts: true,
  browserNotify: false,
  autoPauseOnBlock: true,
  priorityText: "",
};

const emptyStats: EngineStats = {
  checks: 0,
  checksPerSec: 0,
  live: 0,
  boxes: 0,
  alerts: 0,
  telegramOk: 0,
  startedAt: null,
  scanned: 0,
  cycle: 0,
  blocked: 0,
  mismatches: 0,
  okHits: 0,
  peakLiveViewers: 0,
};

const streamers = new Map<string, Streamer>();
const activeKeys = new Set<string>();
let cursor = 0;
let runId = 0;
let checkWindow = 0;
let checkWindowAt = 0;

function seedStreamers(names: string[]) {
  const keep = new Map(streamers);
  streamers.clear();
  for (const u of names) {
    const prev = keep.get(u);
    streamers.set(u, prev ?? {
      username: u,
      status: "offline",
      viewers: 0,
      lastChecked: 0,
      exactMatch: true,
    });
  }
}

function priorityNames(text: string, all: string[]): string[] {
  const wanted = parseUsernameList(text);
  const set = new Set(all.map((n) => n.toLowerCase()));
  return wanted.filter((n) => set.has(n.toLowerCase()));
}

export const useRadar = create<RadarStore>()(
  persist(
    (set, get) => ({
      view: "radar",
      setView: (view) => set({ view }),
      usernames: defaultWatchlist(),
      setUsernames: (names) => {
        const unique = names.length > 0 ? names : defaultWatchlist();
        seedStreamers(unique);
        cursor = 0;
        set({ usernames: unique, live: [] });
      },
      restoreWatchlist: () => {
        const unique = defaultWatchlist();
        seedStreamers(unique);
        cursor = 0;
        set({ usernames: unique, live: [] });
      },
      settings: defaultSettings,
      patchSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),
      running: false,
      stats: emptyStats,
      live: [],
      ticker: [],
      alerts: [],
      workersBusy: 0,
      health: "unknown",
      healthNote: "",
      listFilter: "all",
      setListFilter: (listFilter) => set({ listFilter }),
      sortKey: "viewers",
      setSortKey: (sortKey) => set({ sortKey }),
      start: () => {
        if (get().running) return;
        const names = get().usernames;
        seedStreamers(names);
        runId += 1;
        const my = runId;
        checkWindow = 0;
        checkWindowAt = performance.now();
        set({
          running: true,
          health: "unknown",
          healthNote: "",
          stats: { ...emptyStats, startedAt: Date.now() },
        });
        void runLoop(my, get, set);
      },
      stop: () => {
        runId += 1;
        set({ running: false, workersBusy: 0, stats: { ...get().stats, checksPerSec: 0 } });
      },
      sendAlert: async (alert) => {
        const { settings } = get();
        if (!settings.telegramToken || !settings.telegramChatId) {
          set((s) => ({
            alerts: s.alerts.map((a) =>
              a.id === alert.id ? { ...a, telegramError: "Token və ya chat ID yoxdur" } : a,
            ),
          }));
          return;
        }
        try {
          const res = await sendTelegramAlert({
            data: {
              token: settings.telegramToken,
              chatId: settings.telegramChatId,
              text: formatTelegramAlert(alert),
            },
          });
          set((s) => ({
            alerts: s.alerts.map((a) =>
              a.id === alert.id
                ? { ...a, telegramSent: res.ok, telegramError: res.ok ? undefined : res.error }
                : a,
            ),
            stats: res.ok ? { ...s.stats, telegramOk: s.stats.telegramOk + 1 } : s.stats,
          }));
        } catch (err) {
          set((s) => ({
            alerts: s.alerts.map((a) =>
              a.id === alert.id
                ? { ...a, telegramError: err instanceof Error ? err.message : "Göndərmə xətası" }
                : a,
            ),
          }));
        }
      },
      injectSample: (kind = "chest") => {
        const giftBag = kind === "gift_bag";
        const sample: ChestAlert = {
          id: `sample-${kind}-${Date.now()}`,
          username: giftBag ? "zevs_show" : "ramiz_real",
          viewers: giftBag ? 840 : 1250,
          peakViewers: giftBag ? 910 : 1400,
          giftType: giftBag ? "Hədiyyə çantası" : "Sandıq",
          kind: giftBag ? "gift_bag" : "chest",
          confidence: giftBag ? 92 : 96,
          totalCoins: giftBag ? 30 : 50,
          totalSlots: giftBag ? 10 : 10,
          rate: giftBag ? 3 : 5,
          participants: giftBag ? 6 : 8,
          liveUrl: giftBag
            ? "https://www.tiktok.com/@zevs_show/live"
            : "https://www.tiktok.com/@ramiz_real/live",
          ts: Date.now(),
          telegramSent: false,
          exactMatch: true,
          remainSec: 40,
          title: giftBag ? "gecə yayımı" : "live",
          sender: giftBag ? "fan_01" : "boz_qurt37",
          signals: giftBag ? ["business_type=2"] : ["business_type=1"],
        };
        emitAlert(sample, get, set);
      },
      clearAlerts: () => {
        activeKeys.clear();
        set({ alerts: [], stats: { ...get().stats, alerts: 0, boxes: 0 } });
      },
    }),
    {
      name: "sandiqradar-v3",
      partialize: (s) => ({
        usernames: s.usernames,
        settings: s.settings,
      }),
      onRehydrateStorage: () => (state) => {
        if (!state) return;
        const first = state.usernames[0];
        if (state.usernames.length < 80 || first === "leyla_live" || first === "leyla_tv") {
          state.usernames = defaultWatchlist();
        }
        state.settings = { ...defaultSettings, ...state.settings };
        seedStreamers(state.usernames);
      },
    },
  ),
);

type Get = () => RadarStore;
type Set = (partial: Partial<RadarStore> | ((s: RadarStore) => Partial<RadarStore>)) => void;

function sleep(ms: number) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

async function runLoop(id: number, get: Get, set: Set) {
  while (runId === id) {
    const { usernames, settings, health } = get();
    if (usernames.length === 0) {
      await sleep(800);
      continue;
    }
    if (health === "cooling" || (health === "blocked" && settings.autoPauseOnBlock)) {
      await sleep(settings.stealthMode ? 12_000 : 9000);
    }
    const stealth = settings.stealthMode;
    const batchSize =
      health === "blocked" || health === "cooling"
        ? 1
        : stealth
          ? Math.min(3, Math.max(1, Math.round(settings.concurrency / 8)))
          : Math.min(5, Math.max(2, Math.round(settings.concurrency / 10)));
    const batch: string[] = [];
    const prio = priorityNames(settings.priorityText, usernames);
    for (const name of prio) {
      if (batch.length >= Math.min(1, batchSize)) break;
      batch.push(name);
    }
    for (let i = 0; i < batchSize; i += 1) {
      const name = usernames[cursor % usernames.length];
      cursor += 1;
      if (name && !batch.includes(name)) batch.push(name);
    }
    for (const name of batch) {
      const prev = streamers.get(name);
      streamers.set(name, {
        username: name,
        status: "checking",
        viewers: prev?.viewers ?? 0,
        peakViewers: prev?.peakViewers,
        lastChecked: Date.now(),
        uniqueId: prev?.uniqueId,
        exactMatch: prev?.exactMatch,
        roomId: prev?.roomId,
        title: prev?.title,
        liveSince: prev?.liveSince,
      });
    }
    set({ ticker: batch, workersBusy: batch.length });
    try {
      const res = await scanLiveBatch({ data: { usernames: batch } });
      applyHits(res.hits, get, set, Boolean(res.cooling));
    } catch (err) {
      applyNetworkFail(batch, err, get, set);
    }
    const delay = stealth
      ? get().health === "blocked" || get().health === "cooling"
        ? 11_000
        : Math.max(1400, Math.round(settings.intervalMs / Math.max(2, batchSize)))
      : get().health === "blocked"
        ? 9000
        : Math.max(400, Math.round(settings.intervalMs / Math.max(6, batchSize)));
    await sleep(delay);
  }
}

function applyNetworkFail(batch: string[], err: unknown, get: Get, set: Set) {
  const msg = err instanceof Error ? err.message : "şəbəkə xətası";
  for (const name of batch) {
    streamers.set(name, {
      username: name,
      status: "error",
      viewers: 0,
      lastChecked: Date.now(),
      error: msg,
    });
  }
  publishLive(get, set, {
    checks: batch.length,
    blockedDelta: 0,
    mismatchDelta: 0,
    okDelta: 0,
    health: "blocked",
    note: "Tarama sorğusu uğursuz oldu. Python botunu öz VPS + proxy ilə işə salın — stealth rejim açıq saxlayın.",
  });
}

function applyHits(hits: ScanHit[], get: Get, set: Set, cooling: boolean) {
  let blocked = 0;
  let mismatches = 0;
  let ok = 0;
  const { settings } = get();
  for (const hit of hits) {
    if (hit.blocked) blocked += 1;
    else ok += 1;
    if (!hit.exactMatch) mismatches += 1;
    const prev = streamers.get(hit.username);
    const peak = Math.max(prev?.peakViewers ?? 0, hit.viewers);
    const liveSince = hit.live ? prev?.liveSince ?? Date.now() : undefined;
    const status: Streamer["status"] =
      hit.box && hit.live ? "box" : hit.live ? "live" : hit.blocked ? "error" : "offline";
    streamers.set(hit.username, {
      username: hit.username,
      uniqueId: hit.uniqueId,
      exactMatch: hit.exactMatch,
      status,
      viewers: hit.viewers,
      peakViewers: peak,
      lastChecked: Date.now(),
      liveSince,
      title: hit.title,
      roomId: hit.roomId,
      error: hit.error || undefined,
      boxKind: hit.box?.kind,
      boxLabel: hit.box?.giftType,
      boxRate: hit.box?.rate,
      boxCoins: hit.box?.totalCoins,
      boxSlots: hit.box?.totalSlots,
      boxJoined: hit.box?.participants,
      remainSec: hit.box?.remainSec,
      boxConfidence: hit.box?.confidence,
      sender: hit.box?.sender,
    });
    if (hit.live && hit.exactMatch && hit.box) {
      if (hit.viewers < settings.minViewers) continue;
      if (hit.box.totalCoins < settings.minCoins) continue;
      const alert: ChestAlert = {
        id: `${hit.uniqueId}-${hit.box.boxId || `${hit.box.kind}-${hit.box.totalCoins}-${hit.box.totalSlots}`}-${Math.floor(Date.now() / 12_000)}`,
        username: hit.uniqueId || hit.username,
        viewers: hit.viewers,
        peakViewers: peak,
        giftType: hit.box.giftType,
        kind: hit.box.kind,
        confidence: hit.box.confidence,
        totalCoins: hit.box.totalCoins,
        totalSlots: hit.box.totalSlots,
        rate: hit.box.rate,
        participants: hit.box.participants,
        liveUrl: hit.liveUrl,
        ts: Date.now(),
        telegramSent: false,
        exactMatch: true,
        remainSec: hit.box.remainSec,
        title: hit.title,
        sender: hit.box.sender,
        signals: hit.box.signals,
      };
      const key = `${alert.username}:${hit.box.boxId || `${alert.totalCoins}:${alert.totalSlots}:${alert.kind}`}`;
      if (!activeKeys.has(key)) emitAlert(alert, get, set);
    } else if (!hit.box) {
      for (const key of [...activeKeys]) {
        if (key.startsWith(`${hit.uniqueId || hit.username}:`)) activeKeys.delete(key);
      }
    }
  }
  const ratio = hits.length > 0 ? blocked / hits.length : 0;
  const health: GateHealth = cooling ? "cooling" : ratio >= 0.6 ? "blocked" : "ok";
  const note =
    health === "blocked"
      ? "TikTok bu IP-dən sorğuları kəsir. Stealth açıq saxlayın və ya Python paketini residential proxy ilə VPS-də işə salın."
      : health === "cooling"
        ? "Mühərrik yavaşladı — blok siqnalından sonra backoff."
        : "";
  publishLive(get, set, {
    checks: hits.length,
    blockedDelta: blocked,
    mismatchDelta: mismatches,
    okDelta: ok,
    health,
    note,
  });
}

function publishLive(
  get: Get,
  set: Set,
  meta: {
    checks: number;
    blockedDelta: number;
    mismatchDelta: number;
    okDelta: number;
    health: GateHealth;
    note: string;
  },
) {
  checkWindow += meta.checks;
  const elapsed = performance.now() - checkWindowAt;
  let cps = get().stats.checksPerSec;
  if (elapsed >= 800) {
    cps = Math.round((checkWindow / elapsed) * 1000);
    checkWindow = 0;
    checkWindowAt = performance.now();
  }
  const live: Streamer[] = [];
  let viewerSum = 0;
  for (const s of streamers.values()) {
    if (s.status === "live" || s.status === "box") {
      live.push(s);
      viewerSum += s.viewers;
    }
  }
  const { sortKey } = get();
  live.sort((a, b) => {
    if (sortKey === "name") return a.username.localeCompare(b.username);
    if (sortKey === "rate") return (b.boxRate ?? 0) - (a.boxRate ?? 0);
    if (sortKey === "time") return (b.liveSince ?? 0) - (a.liveSince ?? 0);
    if (a.status !== b.status) return a.status === "box" ? -1 : 1;
    return b.viewers - a.viewers;
  });
  const scanned = [...streamers.values()].filter((s) => s.lastChecked > 0).length;
  const cycle = get().usernames.length > 0 ? Math.floor(get().stats.checks / get().usernames.length) : 0;
  set((s) => ({
    live: live.slice(0, 80),
    workersBusy: meta.checks,
    health: meta.health,
    healthNote: meta.note || (meta.health === "ok" ? "" : s.healthNote),
    stats: {
      ...s.stats,
      checks: s.stats.checks + meta.checks,
      checksPerSec: cps,
      live: live.length,
      boxes: live.filter((x) => x.status === "box").length,
      scanned,
      cycle,
      blocked: s.stats.blocked + meta.blockedDelta,
      mismatches: s.stats.mismatches + meta.mismatchDelta,
      okHits: s.stats.okHits + meta.okDelta,
      peakLiveViewers: Math.max(s.stats.peakLiveViewers, viewerSum),
    },
  }));
}

function emitAlert(alert: ChestAlert, get: Get, set: Set) {
  const { settings, alerts } = get();
  if (alert.rate < settings.minRate) return;
  if (alert.viewers < settings.minViewers) return;
  if (alert.totalCoins < settings.minCoins) return;
  if (alerts.some((a) => a.id === alert.id)) return;
  activeKeys.add(`${alert.username}:${alert.totalCoins}:${alert.totalSlots}:${alert.kind}`);
  set((s) => ({
    alerts: [alert, ...s.alerts].slice(0, 120),
    stats: { ...s.stats, alerts: s.stats.alerts + 1, boxes: s.stats.boxes + 1 },
  }));
  toast.success(`@${alert.username} · ${alert.giftType} · ${alert.viewers} nəfər`);
  if (settings.soundAlerts) playAlertTone();
  if (settings.browserNotify) pushBoxNotification(formatNotifyBody(alert));
  if (settings.autoTelegram && settings.telegramToken && settings.telegramChatId) {
    void get().sendAlert(alert);
  }
}
