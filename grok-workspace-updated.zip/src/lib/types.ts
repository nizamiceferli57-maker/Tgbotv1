import type { BoxKind } from "./box-kind";

export type ViewId = "radar" | "list" | "feed" | "bot" | "code";

export type StreamStatus = "offline" | "checking" | "live" | "box" | "error";

export type Streamer = {
  username: string;
  uniqueId?: string;
  exactMatch?: boolean;
  status: StreamStatus;
  viewers: number;
  peakViewers?: number;
  lastChecked: number;
  liveSince?: number;
  title?: string;
  roomId?: string;
  error?: string;
  boxKind?: BoxKind;
  boxLabel?: string;
  boxRate?: number;
  boxCoins?: number;
  boxSlots?: number;
  boxJoined?: number;
  remainSec?: number;
  boxConfidence?: number;
  sender?: string;
};

export type ChestAlert = {
  id: string;
  username: string;
  viewers: number;
  peakViewers?: number;
  giftType: string;
  kind: BoxKind;
  confidence: number;
  totalCoins: number;
  totalSlots: number;
  rate: number;
  participants: number;
  liveUrl: string;
  ts: number;
  telegramSent: boolean;
  telegramError?: string;
  exactMatch?: boolean;
  remainSec?: number;
  title?: string;
  sender?: string;
  signals?: string[];
};

export type EngineStats = {
  checks: number;
  checksPerSec: number;
  live: number;
  boxes: number;
  alerts: number;
  telegramOk: number;
  startedAt: number | null;
  scanned: number;
  cycle: number;
  blocked: number;
  mismatches: number;
  okHits: number;
  peakLiveViewers: number;
};

export type Settings = {
  telegramToken: string;
  telegramChatId: string;
  autoTelegram: boolean;
  concurrency: number;
  intervalMs: number;
  minRate: number;
  minViewers: number;
  minCoins: number;
  proxiesText: string;
  stealthMode: boolean;
  soundAlerts: boolean;
  browserNotify: boolean;
  autoPauseOnBlock: boolean;
  priorityText: string;
};

export type GateHealth = "unknown" | "ok" | "blocked" | "cooling";

export type ListFilter = "all" | "live" | "box" | "offline";

export type SortKey = "viewers" | "rate" | "time" | "name";
