import assert from "node:assert/strict";
import test from "node:test";
import { classifyBoxKind } from "./box-kind.ts";
import { parseCount } from "./format.ts";
import { extractTreasureBox, isActiveSplitBox, parseLiveRoom } from "./tiktok-parse.ts";

test("live only when status is 2 and uniqueId matches", () => {
  const live = {
    data: {
      user: { uniqueId: "ramiz_real" },
      liveRoom: { status: 2, roomID: "712345", userCount: 88, title: "live" },
    },
  };
  const room = parseLiveRoom("ramiz_real", live);
  assert.ok(room);
  assert.equal(room?.roomId, "712345");
  assert.equal(room?.viewers, 88);
  assert.equal(room?.exactMatch, true);
  assert.equal(room?.title, "live");

  const offline = {
    data: {
      user: { uniqueId: "ramiz_real" },
      liveRoom: { status: 4, roomID: "712345", userCount: 0 },
    },
  };
  assert.equal(parseLiveRoom("ramiz_real", offline), null);

  const mismatch = {
    data: {
      user: { uniqueId: "ramiz_real1" },
      liveRoom: { status: 2, roomID: "99", userCount: 10 },
    },
  };
  assert.equal(parseLiveRoom("ramiz_real", mismatch), null);
});

test("viewers use current user_count, never enter_count", () => {
  const payload = {
    data: {
      user: { uniqueId: "zevs_show" },
      liveRoom: {
        status: 2,
        roomID: "99",
        userCount: 42,
        liveRoomStats: { userCount: 42, enterCount: 9999 },
      },
    },
  };
  const room = parseLiveRoom("zevs_show", payload);
  assert.equal(room?.viewers, 42);
});

test("viewers parse 1.2K display strings from stats.user_count", () => {
  const payload = {
    data: {
      user: { unique_id: "boz_qurt37" },
      room: {
        status: 2,
        room_id: "55",
        stats: { user_count: "1.2K" },
      },
    },
  };
  const room = parseLiveRoom("boz_qurt37", payload);
  assert.equal(room?.viewers, 1200);
});

test("parseCount units", () => {
  assert.equal(parseCount(88), 88);
  assert.equal(parseCount("1.2K"), 1200);
  assert.equal(parseCount("2.5M"), 2_500_000);
  assert.equal(parseCount("1,234"), 1234);
});

test("active envelope is a box; gift catalog is not", () => {
  assert.equal(isActiveSplitBox({ id: 1, name: "Rose", diamond_count: 1, image: { url_list: [] } }), false);
  const box = extractTreasureBox({
    envelope_info: {
      envelope_id: "env-1",
      diamond_count: 50,
      people_count: 10,
      joined_count: 8,
      remain_time: 40,
      name: "Sandıq",
      business_type: 1,
    },
  });
  assert.ok(box);
  assert.equal(box?.totalCoins, 50);
  assert.equal(box?.totalSlots, 10);
  assert.equal(box?.rate, 5);
  assert.equal(box?.participants, 8);
  assert.equal(box?.kind, "chest");
  assert.equal(box?.giftType, "Sandıq");
  assert.ok((box?.confidence ?? 0) >= 70);
});

test("business_type 2 is hədiyyə çantası", () => {
  const box = extractTreasureBox({
    envelope_info: {
      envelope_id: "bag-9",
      diamond_count: 30,
      people_count: 10,
      joined_count: 6,
      remain_time: 20,
      business_type: 2,
      name: "Gift Bag",
    },
  });
  assert.ok(box);
  assert.equal(box?.kind, "gift_bag");
  assert.equal(box?.giftType, "Hədiyyə çantası");
  assert.equal(box?.participants, 6);
});

test("portal envelope_type 2", () => {
  const box = extractTreasureBox({
    portal_box: {
      box_id: "p1",
      diamond_count: 80,
      people_count: 16,
      joined_count: 4,
      envelope_type: 2,
      name: "Portal",
    },
  });
  assert.ok(box);
  assert.equal(box?.kind, "portal");
  assert.equal(box?.giftType, "Portal sandıq");
});

test("classifyBoxKind defaults envelope_id to sandıq", () => {
  const c = classifyBoxKind({ envelope_id: "x", diamond_count: 10, people_count: 5 });
  assert.equal(c.kind, "chest");
});

test("participants never exceed slots", () => {
  const box = extractTreasureBox({
    envelope_info: {
      envelope_id: "e",
      diamond_count: 20,
      people_count: 5,
      joined_count: 99,
    },
  });
  assert.equal(box?.participants, 5);
});
