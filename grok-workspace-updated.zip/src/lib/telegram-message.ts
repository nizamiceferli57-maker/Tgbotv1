import type { ChestAlert } from "./types.ts";
import { fmtNum, fmtRate } from "./format.ts";

function md(text: string): string {
  return text.replace(/\\/g, "\\\\").replace(/_/g, "\\_").replace(/\*/g, "\\*").replace(/`/g, "\\`").replace(/\[/g, "\\[");
}

export function formatTelegramAlert(alert: ChestAlert): string {
  const remain =
    alert.remainSec && alert.remainSec > 0 ? `\n⏱ **Qalan vaxt:** ${alert.remainSec} san` : "";
  const title = alert.title ? `\n📺 **Yayım:** ${md(alert.title)}` : "";
  const sender = alert.sender ? `\n✍️ **Göndərən:** @${md(alert.sender)}` : "";
  const conf = alert.confidence ? `\n🎯 **Növ etibarı:** ${Math.round(alert.confidence)}%` : "";
  const peak =
    alert.peakViewers && alert.peakViewers > alert.viewers
      ? ` (peak ${fmtNum(alert.peakViewers)})`
      : "";
  return [
    "🚨 **CANLI VƏ QUTU TAPILDI!** 🚨",
    "",
    `👤 **İstifadəçi:** @${md(alert.username)}`,
    `🎁 **Növ:** ${md(alert.giftType)}`,
    `👀 **Canlıda nəfər:** ${fmtNum(alert.viewers)}${peak}`,
    `📊 **Bölgü:** ${alert.totalCoins}/${alert.totalSlots} jeton/yer`,
    `💎 **Rate:** ${fmtRate(alert.rate)} jeton/nəfər`,
    `👥 **Qutuya qoşulan:** ${fmtNum(alert.participants)} / ${fmtNum(alert.totalSlots)} nəfər${title}${sender}${remain}${conf}`,
    `🔗 **Canlı yayım:** [Yayıma Keç](${alert.liveUrl})`,
  ].join("\n");
}

export function formatNotifyBody(alert: ChestAlert): string {
  return `@${alert.username} · ${alert.giftType} · canlıda ${fmtNum(alert.viewers)} nəfər · ${alert.totalCoins}/${alert.totalSlots} · rate ${fmtRate(alert.rate)}`;
}
