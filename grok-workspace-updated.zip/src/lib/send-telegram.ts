import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const sendTelegramAlert = createServerFn({ method: "POST" })
  .validator(
    z.object({
      token: z.string().min(10).max(200),
      chatId: z.string().min(1).max(64),
      text: z.string().min(1).max(4000),
    }),
  )
  .handler(async ({ data }) => {
    const res = await fetch(`https://api.telegram.org/bot${data.token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: data.chatId,
        text: data.text,
        parse_mode: "Markdown",
        disable_web_page_preview: false,
      }),
    });
    const payload = (await res.json()) as {
      ok?: boolean;
      description?: string;
    };
    if (!payload.ok) {
      return { ok: false as const, error: payload.description ?? "Telegram xətası" };
    }
    return { ok: true as const, error: "" };
  });
