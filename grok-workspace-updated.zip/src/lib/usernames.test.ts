import assert from "node:assert/strict";
import test from "node:test";
import { findExactUsername, normalizeUsername, parseUsernameList, searchUsernames, usernamesMatch } from "./usernames.ts";

test("normalize and exact match", () => {
  assert.equal(normalizeUsername(" @Ramiz_Real "), "ramiz_real");
  assert.equal(usernamesMatch("Ramiz_Real", "ramiz_real"), true);
  assert.equal(usernamesMatch("ramiz_real", "ramiz_real1"), false);
  assert.equal(usernamesMatch("sion..0502", "sion.0502"), false);
  assert.equal(usernamesMatch(".qara_010", ".qara_010"), true);
});

test("parse list keeps punctuation and drops duplicates", () => {
  const names = parseUsernameList("w777789\n@w777789\n.qara_010\nsion..0502\n#comment");
  assert.deepEqual(names, ["w777789", ".qara_010", "sion..0502"]);
});

test("search ranks exact first", () => {
  const list = ["ramiz_real1", "ramiz_real", "boz_qurt37"];
  const ranked = searchUsernames(list, "ramiz_real");
  assert.equal(ranked[0]?.name, "ramiz_real");
  assert.equal(ranked[0]?.match, "exact");
  assert.equal(findExactUsername(list, "@RAMIZ_REAL"), "ramiz_real");
});
