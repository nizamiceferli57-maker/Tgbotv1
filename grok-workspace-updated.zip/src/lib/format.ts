export function fmtNum(n: number): string {
  return Math.round(n).toLocaleString("az-AZ");
}

export function fmtRate(n: number): string {
  if (!Number.isFinite(n)) return "0";
  return n === Math.trunc(n) ? String(n) : n.toFixed(2);
}

export function fmtDuration(sec: number): string {
  const s = Math.max(0, Math.trunc(sec));
  if (s < 60) return `${s} san`;
  const m = Math.floor(s / 60);
  const r = s % 60;
  if (m < 60) return r ? `${m} dəq ${r} san` : `${m} dəq`;
  const h = Math.floor(m / 60);
  return `${h} saat ${m % 60} dəq`;
}

export function parseCount(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) {
    return Math.max(0, Math.trunc(value));
  }
  if (typeof value === "boolean") return null;
  if (typeof value !== "string") return null;
  const text = value.trim().replace(/\s+/g, "").replace(/,/g, "");
  if (!text) return null;
  const match = text.match(/^([\d.]+)\s*([kKmMbB])?$/);
  if (!match) {
    const n = Number(text);
    return Number.isFinite(n) ? Math.max(0, Math.trunc(n)) : null;
  }
  let n = Number(match[1]);
  if (!Number.isFinite(n)) return null;
  const unit = (match[2] ?? "").toLowerCase();
  if (unit === "k") n *= 1_000;
  else if (unit === "m") n *= 1_000_000;
  else if (unit === "b") n *= 1_000_000_000;
  return Math.max(0, Math.trunc(n));
}
