import configPy from "../bot-source/config.py?raw";
import modelsPy from "../bot-source/models.py?raw";
import identityPy from "../bot-source/identity.py?raw";
import stealthPy from "../bot-source/stealth.py?raw";
import parserPy from "../bot-source/parser.py?raw";
import checkerPy from "../bot-source/checker.py?raw";
import telegramPy from "../bot-source/telegram.py?raw";
import mainPy from "../bot-source/main.py?raw";
import requirementsTxt from "../bot-source/requirements.txt?raw";
import envExample from "../bot-source/env.example?raw";
import proxiesTxt from "../bot-source/proxies.txt?raw";
import usernamesTxt from "../bot-source/usernames.txt?raw";
import readmeMd from "../bot-source/README.md?raw";

export type BotFile = {
  name: string;
  zipPath: string;
  content: string;
  language: "python" | "text" | "markdown";
};

export const BOT_FILES: BotFile[] = [
  { name: "config.py", zipPath: "sandiqradar-bot/config.py", content: configPy, language: "python" },
  { name: "stealth.py", zipPath: "sandiqradar-bot/stealth.py", content: stealthPy, language: "python" },
  { name: "identity.py", zipPath: "sandiqradar-bot/identity.py", content: identityPy, language: "python" },
  { name: "parser.py", zipPath: "sandiqradar-bot/parser.py", content: parserPy, language: "python" },
  { name: "models.py", zipPath: "sandiqradar-bot/models.py", content: modelsPy, language: "python" },
  { name: "checker.py", zipPath: "sandiqradar-bot/checker.py", content: checkerPy, language: "python" },
  { name: "telegram.py", zipPath: "sandiqradar-bot/telegram.py", content: telegramPy, language: "python" },
  { name: "main.py", zipPath: "sandiqradar-bot/main.py", content: mainPy, language: "python" },
  {
    name: "requirements.txt",
    zipPath: "sandiqradar-bot/requirements.txt",
    content: requirementsTxt,
    language: "text",
  },
  {
    name: ".env.example",
    zipPath: "sandiqradar-bot/.env.example",
    content: envExample,
    language: "text",
  },
  {
    name: "usernames.txt",
    zipPath: "sandiqradar-bot/usernames.txt",
    content: usernamesTxt,
    language: "text",
  },
  {
    name: "proxies.txt",
    zipPath: "sandiqradar-bot/proxies.txt",
    content: proxiesTxt,
    language: "text",
  },
  { name: "README.md", zipPath: "sandiqradar-bot/README.md", content: readmeMd, language: "markdown" },
];
