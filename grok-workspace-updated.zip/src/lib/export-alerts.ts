import type { ChestAlert } from "./types";

export function alertsToCsv(alerts: ChestAlert[]): string {
  const header = [
    "vaxt",
    "istifadeci",
    "nov",
    "etibar",
    "canlida_nefer",
    "jeton",
    "yer",
    "rate",
    "qosulan",
    "qalan_san",
    "basliq",
    "gonderen",
    "url",
  ];
  const rows = alerts.map((a) =>
    [
      new Date(a.ts).toISOString(),
      a.username,
      a.giftType,
      a.confidence,
      a.viewers,
      a.totalCoins,
      a.totalSlots,
      a.rate,
      a.participants,
      a.remainSec ?? 0,
      csvEscape(a.title ?? ""),
      a.sender ?? "",
      a.liveUrl,
    ].join(","),
  );
  return [header.join(","), ...rows].join("\n");
}

function csvEscape(value: string): string {
  if (/[",\n]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}

export function downloadText(filename: string, text: string, mime: string) {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
