import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { sendTelegramAlert } from "@/lib/send-telegram";
import { requestNotifyPermission } from "@/lib/notify";
import { PRODUCT_FEATURES } from "@/lib/features";
import { useRadar } from "@/lib/store";
import { fmtNum } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";

type Tab = "stealth" | "telegram" | "filter" | "features";

const TABS: { id: Tab; label: string }[] = [
  { id: "stealth", label: "Stealth" },
  { id: "telegram", label: "Telegram" },
  { id: "filter", label: "Filtr" },
  { id: "features", label: "32 xüsusiyyət" },
];

export function BotView() {
  const settings = useRadar((s) => s.settings);
  const patch = useRadar((s) => s.patchSettings);
  const stats = useRadar((s) => s.stats);
  const health = useRadar((s) => s.health);
  const [tab, setTab] = useState<Tab>("stealth");
  const okRate = stats.checks > 0 ? Math.round((stats.okHits / stats.checks) * 100) : 0;

  async function testTelegram() {
    if (!settings.telegramToken || !settings.telegramChatId) {
      toast.error("Token və chat ID doldurun");
      return;
    }
    try {
      const res = await sendTelegramAlert({
        data: {
          token: settings.telegramToken,
          chatId: settings.telegramChatId,
          text: "SandıqRadar test. Növ + nəfər sayı işləkdir.",
        },
      });
      if (res.ok) toast.success("Test mesajı göndərildi");
      else toast.error(res.error);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Göndərmə xətası");
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-5">
      <header>
        <p className="text-xs font-medium tracking-wide text-muted uppercase">Mühərrik və xəbərdarlıq</p>
        <h2 className="mt-1 text-xl font-semibold">Ayarlar</h2>
        <p className="mt-2 text-sm text-muted">
          Stealth rejim cookie warmup, UA rotasiyası və backoff ilə TikTok-un blokunu azaldır. Datacenter
          IP yenə kəsilə bilər — Python paketini residential proxy ilə VPS-də işə salın.
        </p>
      </header>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Mini label="Uğur" value={`${okRate}%`} />
        <Mini label="Blok" value={fmtNum(stats.blocked)} />
        <Mini label="Peak nəfər" value={fmtNum(stats.peakLiveViewers)} />
        <Mini label="Sağlamlıq" value={health === "ok" ? "OK" : health === "cooling" ? "Backoff" : health === "blocked" ? "Blok" : "—"} />
      </div>

      <div className="flex flex-wrap gap-1.5">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`h-10 rounded-md px-3 text-sm font-medium transition-colors duration-150 ${
              tab === t.id ? "bg-raised text-fg" : "text-muted hover:text-fg"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "stealth" ? (
        <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
          <h3 className="text-sm font-medium">Anti-blok</h3>
          <div className="mt-4 flex flex-col gap-3">
            <Toggle
              label="Stealth rejim"
              hint="Kiçik batch, jitter, cookie sessiyası, UA + Client Hints rotasiyası"
              checked={settings.stealthMode}
              onChange={(v) => patch({ stealthMode: v })}
            />
            <Toggle
              label="Blokda avto-yavaşla"
              hint="403/429 dalğasında mühərrik özü backoff edir"
              checked={settings.autoPauseOnBlock}
              onChange={(v) => patch({ autoPauseOnBlock: v })}
            />
            <Toggle
              label="Səs siqnalı"
              hint="Qutu tapılanda qısa ton"
              checked={settings.soundAlerts}
              onChange={(v) => patch({ soundAlerts: v })}
            />
            <Toggle
              label="Brauzer bildirişi"
              hint="Növ və nəfər sayı bildiriş mətnində"
              checked={settings.browserNotify}
              onChange={(v) => {
                patch({ browserNotify: v });
                if (v) void requestNotifyPermission().then((ok) => {
                  if (!ok) toast.error("Bildiriş icazəsi verilmədi");
                });
              }}
            />
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <Field id="conc" label="Paralel worker (Python)">
              <Input
                id="conc"
                type="number"
                min={4}
                max={80}
                value={settings.concurrency}
                onChange={(e) => patch({ concurrency: clamp(Number(e.target.value) || 12, 4, 80) })}
              />
            </Field>
            <Field id="intv" label="Dövrə (ms)">
              <Input
                id="intv"
                type="number"
                min={2000}
                max={30000}
                value={settings.intervalMs}
                onChange={(e) => patch({ intervalMs: clamp(Number(e.target.value) || 8000, 2000, 30000) })}
              />
            </Field>
          </div>
          <div className="mt-4 flex flex-col gap-1.5">
            <Label htmlFor="proxies">Proxy siyahısı (Python)</Label>
            <Textarea
              id="proxies"
              value={settings.proxiesText}
              onChange={(e) => patch({ proxiesText: e.target.value })}
              placeholder={"http://user:pass@host:port\nsocks5://host:1080"}
              className="min-h-24"
            />
            <p className="text-xs text-muted">
              Web tarayıcı sizin brauzer IP-sindən gedir; proxy yalnız Python paketində işləyir.
            </p>
          </div>
        </section>
      ) : null}

      {tab === "telegram" ? (
        <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
          <h3 className="text-sm font-medium">Telegram</h3>
          <div className="mt-4 flex flex-col gap-4">
            <Field id="token" label="Bot tokeni">
              <Input
                id="token"
                type="password"
                autoComplete="off"
                value={settings.telegramToken}
                onChange={(e) => patch({ telegramToken: e.target.value.trim() })}
                placeholder="123456:AA…"
              />
            </Field>
            <Field id="chat" label="Chat ID">
              <Input
                id="chat"
                value={settings.telegramChatId}
                onChange={(e) => patch({ telegramChatId: e.target.value.trim() })}
                placeholder="-100…"
              />
            </Field>
            <Toggle
              label="Avtomatik göndər"
              hint="Sandıq və ya hədiyyə çantası tapılanda dərhal"
              checked={settings.autoTelegram}
              onChange={(v) => patch({ autoTelegram: v })}
            />
            <Button variant="secondary" onClick={() => void testTelegram()}>
              Test mesajı göndər
            </Button>
            <p className="text-xs text-muted">Uğurlu göndəriş: {stats.telegramOk}</p>
          </div>
        </section>
      ) : null}

      {tab === "filter" ? (
        <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
          <h3 className="text-sm font-medium">Xəbərdarlıq filtri</h3>
          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            <Field id="rate" label="Min rate">
              <Input
                id="rate"
                type="number"
                min={0}
                step={0.5}
                value={settings.minRate}
                onChange={(e) => patch({ minRate: Math.max(0, Number(e.target.value) || 0) })}
              />
            </Field>
            <Field id="view" label="Min nəfər">
              <Input
                id="view"
                type="number"
                min={0}
                value={settings.minViewers}
                onChange={(e) => patch({ minViewers: Math.max(0, Number(e.target.value) || 0) })}
              />
            </Field>
            <Field id="coins" label="Min jeton">
              <Input
                id="coins"
                type="number"
                min={0}
                value={settings.minCoins}
                onChange={(e) => patch({ minCoins: Math.max(0, Number(e.target.value) || 0) })}
              />
            </Field>
          </div>
          <div className="mt-4 flex flex-col gap-1.5">
            <Label htmlFor="prio">Prioritet unique_id</Label>
            <Textarea
              id="prio"
              value={settings.priorityText}
              onChange={(e) => patch({ priorityText: e.target.value })}
              placeholder={"ramiz_real\nzevs_show"}
              className="min-h-24"
            />
            <p className="text-xs text-muted">Bu adlar hər dövrdə birinci yoxlanır.</p>
          </div>
        </section>
      ) : null}

      {tab === "features" ? (
        <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
          <h3 className="text-sm font-medium">{PRODUCT_FEATURES.length} xüsusiyyət</h3>
          <ul className="mt-4 grid gap-2 sm:grid-cols-2">
            {PRODUCT_FEATURES.map((f, i) => (
              <li key={f.id} className="rounded-lg bg-raised px-3 py-3">
                <p className="text-xs text-faint tabular-nums">{String(i + 1).padStart(2, "0")}</p>
                <p className="mt-1 text-sm font-medium">{f.title}</p>
                <p className="mt-1 text-xs leading-relaxed text-muted">{f.detail}</p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 font-mono text-lg tabular-nums">{value}</p>
    </div>
  );
}

function Field({ id, label, children }: { id: string; label: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={id}>{label}</Label>
      {children}
    </div>
  );
}

function Toggle({
  label,
  hint,
  checked,
  onChange,
}: {
  label: string;
  hint: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg bg-raised px-3 py-3">
      <div>
        <p className="text-sm font-medium">{label}</p>
        <p className="text-xs text-muted">{hint}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} aria-label={label} />
    </div>
  );
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}
