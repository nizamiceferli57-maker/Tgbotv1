import { Box, Eye, Radio, Shield, Users, Zap } from "lucide-react";
import { useRadar } from "@/lib/store";
import { cn } from "@/lib/utils";
import { fmtNum, fmtRate } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import type { BoxKind } from "@/lib/box-kind";

function kindVariant(kind?: BoxKind): "box" | "bag" | "live" | "default" {
  if (kind === "gift_bag") return "bag";
  if (kind === "chest" || kind === "portal" || kind === "lucky") return "box";
  if (kind === "envelope") return "live";
  return "default";
}

export function RadarView() {
  const live = useRadar((s) => s.live);
  const stats = useRadar((s) => s.stats);
  const running = useRadar((s) => s.running);
  const ticker = useRadar((s) => s.ticker);
  const alerts = useRadar((s) => s.alerts);
  const usernames = useRadar((s) => s.usernames);
  const health = useRadar((s) => s.health);
  const healthNote = useRadar((s) => s.healthNote);
  const stealth = useRadar((s) => s.settings.stealthMode);
  const dots = live.slice(0, 28);
  const viewerSum = live.reduce((acc, s) => acc + s.viewers, 0);
  const okRate = stats.checks > 0 ? Math.round((stats.okHits / stats.checks) * 100) : 0;

  return (
    <div className="flex flex-col gap-5 lg:grid lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:gap-6">
      <section className="enter-up rounded-xl bg-surface p-3 shadow-[var(--shadow-border)] sm:p-5">
        <div className="mb-3 flex items-end justify-between gap-3">
          <div>
            <p className="text-xs font-medium tracking-wide text-muted uppercase">Canlı radar</p>
            <h2 className="mt-1 text-xl font-semibold tracking-tight">Dəqiq tarama</h2>
          </div>
          <div className="flex items-center gap-2">
            {stealth ? <Badge variant="box">Stealth</Badge> : null}
            <Badge variant={health === "blocked" ? "danger" : health === "cooling" ? "bag" : running ? "live" : "default"}>
              {health === "blocked" ? "Blok" : health === "cooling" ? "Backoff" : running ? "Aktiv" : "Dayanıb"}
            </Badge>
          </div>
        </div>
        {healthNote ? (
          <p className="mb-3 rounded-lg bg-raised px-3 py-2 text-xs leading-relaxed text-muted">{healthNote}</p>
        ) : null}
        <div className="relative mx-auto aspect-square max-h-64 w-full max-w-64 sm:max-h-[360px] sm:max-w-[360px]">
          <svg viewBox="0 0 200 200" className="size-full" aria-hidden="true">
            <defs>
              <radialGradient id="radarGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="var(--color-accent)" stopOpacity="0.18" />
                <stop offset="70%" stopColor="var(--color-accent)" stopOpacity="0.04" />
                <stop offset="100%" stopColor="transparent" stopOpacity="0" />
              </radialGradient>
            </defs>
            <circle cx="100" cy="100" r="96" fill="url(#radarGlow)" />
            {[28, 52, 76].map((r, i) => (
              <circle
                key={r}
                className="radar-ring"
                cx="100"
                cy="100"
                r={r}
                fill="none"
                stroke="var(--color-border)"
                strokeWidth="0.7"
                style={{ animationDelay: `${i * 400}ms` }}
              />
            ))}
            <g className="radar-sweep">
              <path d="M100 100 L100 8 A92 92 0 0 1 148 22 Z" fill="var(--color-accent)" opacity="0.12" />
              <line x1="100" y1="100" x2="100" y2="8" stroke="var(--color-accent)" strokeWidth="0.8" opacity="0.7" />
            </g>
            {dots.map((s, i) => {
              const angle = (hashAngle(s.username) / 180) * Math.PI;
              const radius = 22 + (hashAngle(s.username + "r") % 62);
              const x = 100 + Math.cos(angle) * radius;
              const y = 100 + Math.sin(angle) * radius;
              const box = s.status === "box";
              const bag = s.boxKind === "gift_bag";
              return (
                <circle
                  key={s.username}
                  cx={x}
                  cy={y}
                  r={box ? 3.4 : 2}
                  fill={bag ? "var(--color-warn)" : box ? "var(--color-accent)" : "var(--color-live)"}
                  opacity={0.55 + (i % 5) * 0.08}
                />
              );
            })}
            <circle cx="100" cy="100" r="3.4" fill="var(--color-fg)" />
          </svg>
        </div>
        <p className="mt-3 text-center font-mono text-xs text-muted tabular-nums">
          {fmtNum(stats.scanned)}/{fmtNum(usernames.length)} yoxlanıb · {fmtNum(stats.live)} canlı · {fmtNum(viewerSum)} nəfər
        </p>
        <p className="mt-1 truncate font-mono text-xs text-faint">
          {ticker.length > 0 ? ticker.map((t) => `@${t}`).join("  ·  ") : "Növbə gözləyir"}
        </p>
      </section>

      <div className="flex flex-col gap-5">
        <section className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <Stat icon={Radio} label="Canlı" value={fmtNum(stats.live)} tone="live" />
          <Stat icon={Box} label="Aktiv qutu" value={fmtNum(stats.boxes)} tone="accent" />
          <Stat icon={Users} label="Nəfər (indi)" value={fmtNum(viewerSum)} />
          <Stat icon={Eye} label="Yoxlama" value={fmtNum(stats.checks)} />
          <Stat icon={Zap} label="Xəbərdarlıq" value={fmtNum(stats.alerts)} />
          <Stat icon={Shield} label="Uğur" value={`${okRate}%`} />
        </section>
        <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-medium">Canlı otaqlar</h3>
            <span className="text-xs text-muted">{live.length} dəqiq uyğunluq</span>
          </div>
          <ul className="flex flex-col gap-2">
            {live.slice(0, 6).length === 0 ? (
              <li className="rounded-lg bg-raised px-3 py-6 text-center text-sm text-muted">
                Hələ dəqiq unique_id canlı tapılmayıb. Stealth rejim yavaş, amma daha az bloklanır.
              </li>
            ) : (
              live.slice(0, 6).map((s) => (
                <li key={s.username} className="flex items-center justify-between gap-3 rounded-lg bg-raised px-3 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate font-medium">@{s.uniqueId || s.username}</p>
                    <p className="text-xs text-muted">
                      {s.boxLabel ?? s.title ?? "Canlı"}
                      {s.boxSlots ? ` · ${s.boxJoined ?? 0}/${s.boxSlots}` : ""}
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <p className="font-mono text-sm tabular-nums">{fmtNum(s.viewers)} nəfər</p>
                    {s.status === "box" ? (
                      <Badge variant={kindVariant(s.boxKind)}>
                        {s.boxLabel ?? "Qutu"} · {fmtRate(s.boxRate ?? 0)}
                      </Badge>
                    ) : (
                      <Badge variant="live">Canlı</Badge>
                    )}
                  </div>
                </li>
              ))
            )}
          </ul>
        </section>
        <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-medium">Son qutular</h3>
            <span className="text-xs text-muted">{alerts.length} qeyd</span>
          </div>
          <ul className="flex flex-col gap-2">
            {alerts.slice(0, 4).length === 0 ? (
              <li className="rounded-lg bg-raised px-3 py-5 text-center text-sm text-muted">
                Sandıq və ya hədiyyə çantası tapılanda növ + nəfər sayı burada görünür.
              </li>
            ) : (
              alerts.slice(0, 4).map((a) => (
                <li key={a.id} className="flex items-center justify-between gap-3 rounded-lg bg-raised px-3 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate font-medium">@{a.username}</p>
                    <p className="text-xs text-muted">
                      {a.giftType} · {fmtNum(a.viewers)} nəfər · {a.participants}/{a.totalSlots}
                    </p>
                  </div>
                  <p className="font-mono text-sm tabular-nums text-accent">{fmtRate(a.rate)}</p>
                </li>
              ))
            )}
          </ul>
        </section>
      </div>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
  tone,
}: {
  icon: typeof Radio;
  label: string;
  value: string;
  tone?: "live" | "accent";
}) {
  return (
    <div className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <div className="flex items-center gap-2 text-muted">
        <Icon className="size-3.5" />
        <span className="text-xs">{label}</span>
      </div>
      <p
        className={cn(
          "mt-2 font-mono text-2xl font-medium tracking-tight tabular-nums",
          tone === "live" && "text-live",
          tone === "accent" && "text-accent",
        )}
      >
        {value}
      </p>
    </div>
  );
}

function hashAngle(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i += 1) h = (h * 33 + s.charCodeAt(i)) >>> 0;
  return h % 360;
}
