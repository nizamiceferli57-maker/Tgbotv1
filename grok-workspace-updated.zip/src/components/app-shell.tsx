import { useEffect } from "react";
import { Bell, Code2, Pause, Play, Radio, Settings, Users } from "lucide-react";
import { Toaster } from "sonner";
import { BotView } from "@/components/bot-view";
import { CodeView } from "@/components/code-view";
import { FeedView } from "@/components/feed-view";
import { ListView } from "@/components/list-view";
import { RadarView } from "@/components/radar-view";
import { useRadar } from "@/lib/store";
import type { ViewId } from "@/lib/types";
import { cn } from "@/lib/utils";
import { fmtNum } from "@/lib/format";
import { Button } from "@/components/ui/button";

const NAV: { id: ViewId; label: string; icon: typeof Radio }[] = [
  { id: "radar", label: "Radar", icon: Radio },
  { id: "list", label: "Siyahı", icon: Users },
  { id: "feed", label: "Lenta", icon: Bell },
  { id: "bot", label: "Ayarlar", icon: Settings },
  { id: "code", label: "Kod", icon: Code2 },
];

export function AppShell() {
  const view = useRadar((s) => s.view);
  const setView = useRadar((s) => s.setView);
  const running = useRadar((s) => s.running);
  const start = useRadar((s) => s.start);
  const stop = useRadar((s) => s.stop);
  const stats = useRadar((s) => s.stats);
  const health = useRadar((s) => s.health);
  const live = useRadar((s) => s.live);
  const total = useRadar((s) => s.usernames.length);
  const viewerSum = live.reduce((acc, s) => acc + s.viewers, 0);

  useEffect(() => {
    start();
    return () => stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="flex min-h-dvh bg-bg text-fg">
      <Toaster theme="dark" position="top-right" />
      <aside className="sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border bg-surface/60 p-4 md:flex">
        <Brand />
        <nav className="mt-8 flex flex-1 flex-col gap-1">
          {NAV.map((item) => (
            <NavBtn key={item.id} {...item} active={view === item.id} onSelect={setView} />
          ))}
        </nav>
        <p className="text-xs text-faint">Sandıq / hədiyyə çantası · dəqiq nəfər</p>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col pb-20 md:pb-0">
        <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 py-3 backdrop-blur-sm sm:px-6">
          <div className="min-w-0 md:hidden">
            <Brand compact />
          </div>
          <p className="hidden truncate text-sm text-muted md:block">
            {fmtNum(stats.live)} canlı · {fmtNum(viewerSum)} nəfər · {fmtNum(stats.alerts)} xəbərdarlıq ·{" "}
            {fmtNum(stats.scanned)}/{fmtNum(total)}
            {health === "blocked" ? " · blok" : health === "cooling" ? " · backoff" : ""}
          </p>
          <Button
            size="sm"
            variant={running ? "secondary" : "default"}
            onClick={() => (running ? stop() : start())}
            aria-pressed={running}
          >
            {running ? <Pause className="size-4" /> : <Play className="size-4" />}
            {running ? "Dayandır" : "Başlat"}
          </Button>
        </header>

        <main className="flex-1 px-4 py-5 sm:px-6 sm:py-6">
          {view === "radar" && <RadarView />}
          {view === "list" && <ListView />}
          {view === "feed" && <FeedView />}
          {view === "bot" && <BotView />}
          {view === "code" && <CodeView />}
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-surface/95 px-1 pt-1 pb-[max(0.35rem,env(safe-area-inset-bottom))] backdrop-blur-sm md:hidden">
        {NAV.map((item) => (
          <NavBtn key={item.id} {...item} active={view === item.id} onSelect={setView} stacked />
        ))}
      </nav>
    </div>
  );
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <span className="grid size-8 place-items-center rounded-md bg-raised shadow-[var(--shadow-border)]">
        <Radio className="size-4 text-accent" />
      </span>
      <div className="min-w-0">
        <p className="truncate text-sm font-semibold tracking-tight">SandıqRadar</p>
        {compact ? null : <p className="text-xs text-muted">Növ + nəfər sayı</p>}
      </div>
    </div>
  );
}

function NavBtn({
  id,
  label,
  icon: Icon,
  active,
  onSelect,
  stacked,
}: {
  id: ViewId;
  label: string;
  icon: typeof Radio;
  active: boolean;
  onSelect: (id: ViewId) => void;
  stacked?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={() => onSelect(id)}
      className={cn(
        "flex items-center gap-2 rounded-md px-3 text-sm font-medium transition-colors duration-150",
        stacked ? "h-14 flex-col justify-center gap-1 px-1 text-[11px]" : "h-11",
        active ? "bg-raised text-fg" : "text-muted hover:text-fg",
      )}
      aria-current={active ? "page" : undefined}
    >
      <Icon className={cn("size-4", stacked && "size-[18px]")} />
      {label}
    </button>
  );
}
