import { useMemo, useState } from "react";
import { Check, Copy, Download } from "lucide-react";
import { toast } from "sonner";
import { BOT_FILES } from "@/lib/bot-files";
import { downloadBlob, makeZip } from "@/lib/zip";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function CodeView() {
  const [active, setActive] = useState(BOT_FILES[0]?.name ?? "config.py");
  const [copied, setCopied] = useState(false);
  const file = useMemo(() => BOT_FILES.find((f) => f.name === active) ?? BOT_FILES[0], [active]);

  function downloadZip() {
    const blob = makeZip(BOT_FILES.map((f) => ({ name: f.zipPath, content: f.content })));
    downloadBlob(blob, "sandiqradar-bot.zip");
    toast.success("Python paketi yükləndi");
  }

  async function copy() {
    if (!file) return;
    await navigator.clipboard.writeText(file.content);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1400);
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-wide text-muted uppercase">Python mühərriki</p>
          <h2 className="mt-1 text-xl font-semibold">Tam mənbə kodu</h2>
          <p className="mt-2 max-w-2xl text-sm text-muted">
            Stealth cookie, UA rotasiyası, dəqiq unique_id, status=2, sandıq vs hədiyyə çantası təsnifatı,
            cari nəfər sayı və Telegram. Öz VPS-də `python main.py`.
          </p>
        </div>
        <Button onClick={downloadZip}>
          <Download className="size-4" />
          ZIP yüklə
        </Button>
      </div>

      <div className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
        <div className="flex gap-1 overflow-x-auto border-b border-border p-2">
          {BOT_FILES.map((f) => (
            <button
              key={f.name}
              type="button"
              onClick={() => setActive(f.name)}
              className={cn(
                "h-10 shrink-0 rounded-md px-3 text-xs font-medium transition-colors duration-150",
                f.name === active ? "bg-raised text-fg" : "text-muted hover:text-fg",
              )}
            >
              {f.name}
            </button>
          ))}
        </div>
        <div className="flex items-center justify-between border-b border-border px-3 py-2">
          <span className="font-mono text-xs text-muted">{file?.name}</span>
          <Button size="sm" variant="ghost" onClick={() => void copy()}>
            {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
            {copied ? "Kopyalandı" : "Kopyala"}
          </Button>
        </div>
        <pre className="max-h-[560px] overflow-auto p-4 font-mono text-xs leading-relaxed text-fg/90">
          {file?.content}
        </pre>
      </div>
    </div>
  );
}
