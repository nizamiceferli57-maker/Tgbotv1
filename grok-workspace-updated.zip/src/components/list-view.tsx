import { useMemo, useState } from "react";
import { Search, Upload } from "lucide-react";
import { toast } from "sonner";
import { probeUserLive } from "@/lib/probe-live";
import { useRadar } from "@/lib/store";
import { parseUsernameList, searchUsernames } from "@/lib/usernames";
import { fmtNum, fmtRate } from "@/lib/format";
import type { ListFilter } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { ScanHit } from "@/lib/probe-live";

const FILTERS: { id: ListFilter; label: string }[] = [
  { id: "all", label: "Hamısı" },
  { id: "live", label: "Canlı" },
  { id: "box", label: "Qutu" },
  { id: "offline", label: "Offline" },
];

export function ListView() {
  const usernames = useRadar((s) => s.usernames);
  const setUsernames = useRadar((s) => s.setUsernames);
  const restoreWatchlist = useRadar((s) => s.restoreWatchlist);
  const live = useRadar((s) => s.live);
  const listFilter = useRadar((s) => s.listFilter);
  const setListFilter = useRadar((s) => s.setListFilter);
  const [q, setQ] = useState("");
  const [bulk, setBulk] = useState("");
  const [probeName, setProbeName] = useState("");
  const [probing, setProbing] = useState(false);
  const [probe, setProbe] = useState<ScanHit | null>(null);
  const [probeNote, setProbeNote] = useState("");
  const liveMap = useMemo(() => new Map(live.map((s) => [s.username, s])), [live]);

  const ranked = useMemo(() => {
    const base = searchUsernames(usernames, q);
    if (listFilter === "all") return base;
    return base.filter((row) => {
      const st = liveMap.get(row.name)?.status ?? "offline";
      if (listFilter === "box") return st === "box";
      if (listFilter === "live") return st === "live" || st === "box";
      return st === "offline" || st === "error" || st === "checking";
    });
  }, [q, usernames, listFilter, liveMap]);
  const needle = q.trim();
  const visible = needle ? ranked.slice(0, 140) : ranked.slice(0, 90);
  const exact = ranked.find((r) => r.match === "exact") ?? null;

  function applyBulk() {
    const parsed = parseUsernameList(bulk);
    if (parsed.length === 0) {
      toast.error("Siyahı boşdur");
      return;
    }
    setUsernames(parsed);
    toast.success(`${parsed.length} dəqiq istifadəçi yükləndi`);
    setBulk("");
  }

  async function runProbe() {
    const name = probeName.trim().replace(/^@/, "");
    if (!name) return;
    setProbing(true);
    setProbe(null);
    setProbeNote("");
    try {
      const res = await probeUserLive({ data: { username: name } });
      setProbe(res);
      if (res.blocked) {
        setProbeNote(`Blok: HTTP ${res.httpStatus || "şəbəkə"}`);
        toast.error("TikTok sorğunu blokladı");
        return;
      }
      if (!res.exactMatch) {
        setProbeNote(`Uyğunsuzluq: istənilən @${name}, tapılan @${res.uniqueId || "—"}`);
        toast.error("Dəqiq ad uyğun gəlmədi");
        return;
      }
      if (res.live) {
        toast.success(`@${res.uniqueId} canlıdır · ${fmtNum(res.viewers)} nəfər`);
      } else {
        toast.message(`@${res.uniqueId || name} offline`);
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Yoxlama alınmadı");
    } finally {
      setProbing(false);
    }
  }

  return (
    <div className="flex flex-col gap-5 lg:grid lg:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]">
      <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs font-medium tracking-wide text-muted uppercase">İzləmə siyahısı</p>
            <h2 className="mt-1 text-xl font-semibold">{fmtNum(usernames.length)} dəqiq ad</h2>
          </div>
          <div className="relative min-w-48 flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-faint" />
            <Input
              className="pl-9"
              placeholder="Dəqiq ad axtar…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              aria-label="İstifadəçi axtar"
            />
          </div>
        </div>
        <div className="mb-3 flex flex-wrap gap-1.5">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setListFilter(f.id)}
              className={`h-9 rounded-md px-3 text-xs font-medium transition-colors duration-150 ${
                listFilter === f.id ? "bg-raised text-fg" : "text-muted hover:text-fg"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
        {exact ? (
          <div className="mb-3 rounded-lg bg-live-dim px-3 py-3">
            <p className="text-xs font-medium text-live">Dəqiq uyğunluq tapıldı</p>
            <p className="mt-1 truncate text-lg font-semibold tracking-tight">@{exact.name}</p>
          </div>
        ) : needle ? (
          <p className="mb-3 text-sm text-muted">
            {ranked.length === 0 ? "Bu ad siyahıda yoxdur — oxşar ad qəbul edilmir." : `${ranked.length} yaxın nəticə`}
          </p>
        ) : null}
        <ul className="divide-y divide-border">
          {visible.map((row) => {
            const liveRow = liveMap.get(row.name);
            const status = liveRow?.status ?? "offline";
            return (
              <li key={row.name} className="flex items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="truncate font-medium">@{row.name}</p>
                  {liveRow?.boxLabel ? (
                    <p className="text-xs text-muted">
                      {liveRow.boxLabel}
                      {liveRow.boxSlots ? ` · ${liveRow.boxJoined ?? 0}/${liveRow.boxSlots}` : ""}
                    </p>
                  ) : liveRow?.title ? (
                    <p className="truncate text-xs text-muted">{liveRow.title}</p>
                  ) : null}
                </div>
                <div className="flex items-center gap-2">
                  {liveRow && liveRow.viewers > 0 ? (
                    <span className="font-mono text-xs text-muted tabular-nums">{fmtNum(liveRow.viewers)} nəfər</span>
                  ) : null}
                  <Badge
                    variant={
                      status === "box"
                        ? liveRow?.boxKind === "gift_bag"
                          ? "bag"
                          : "box"
                        : status === "live"
                          ? "live"
                          : status === "error"
                            ? "danger"
                            : "default"
                    }
                  >
                    {status === "box"
                      ? liveRow?.boxLabel ?? "Qutu"
                      : status === "live"
                        ? "Canlı"
                        : status === "checking"
                          ? "Yoxlanır"
                          : status === "error"
                            ? "Xəta"
                            : "Offline"}
                  </Badge>
                </div>
              </li>
            );
          })}
        </ul>
        {ranked.length > visible.length ? (
          <p className="mt-3 text-xs text-muted">Daha {ranked.length - visible.length} ad var — axtarışı daraldın.</p>
        ) : null}
      </section>

      <div className="flex flex-col gap-5">
        <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
          <h3 className="text-sm font-medium">Dəqiq canlı yoxlama</h3>
          <p className="mt-1 mb-3 text-sm text-muted">
            uniqueId eyni olmalıdır. Nəticədə növ (sandıq/çanta) və canlıdakı nəfər sayı göstərilir.
          </p>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Input
              value={probeName}
              onChange={(e) => setProbeName(e.target.value)}
              placeholder="ramiz_real"
              aria-label="Yoxlanacaq istifadəçi"
            />
            <Button onClick={() => void runProbe()} disabled={probing || !probeName.trim()}>
              {probing ? "Yoxlanır…" : "Yoxla"}
            </Button>
          </div>
          {probeNote ? <p className="mt-3 text-sm text-muted">{probeNote}</p> : null}
          {probe && probe.exactMatch ? (
            <dl className="mt-4 grid grid-cols-2 gap-2">
              <ProbeMeta label="Status" value={probe.live ? "Canlı" : "Offline"} />
              <ProbeMeta label="Canlıda" value={`${fmtNum(probe.viewers)} nəfər`} />
              <ProbeMeta label="Növ" value={probe.box ? probe.box.giftType : "Qutu yoxdur"} />
              <ProbeMeta
                label="Qoşulan"
                value={probe.box ? `${probe.box.participants}/${probe.box.totalSlots}` : "—"}
              />
              <ProbeMeta label="Rate" value={probe.box ? fmtRate(probe.box.rate) : "—"} />
              <ProbeMeta label="Etibar" value={probe.box ? `${Math.round(probe.box.confidence)}%` : "—"} />
              {probe.title ? <ProbeMeta label="Başlıq" value={probe.title} /> : null}
              {probe.box?.sender ? <ProbeMeta label="Göndərən" value={`@${probe.box.sender}`} /> : null}
            </dl>
          ) : null}
        </section>
        <section className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
          <h3 className="text-sm font-medium">Toplu idxal</h3>
          <p className="mt-1 mb-3 text-sm text-muted">Hər sətirdə bir dəqiq unique_id.</p>
          <Textarea
            value={bulk}
            onChange={(e) => setBulk(e.target.value)}
            placeholder={"ramiz_real\nboz_qurt37\n.qara_010"}
          />
          <div className="mt-3 flex flex-col gap-2">
            <Button className="w-full" variant="secondary" onClick={applyBulk}>
              <Upload className="size-4" />
              Siyahını əvəz et
            </Button>
            <Button
              className="w-full"
              variant="ghost"
              onClick={() => {
                restoreWatchlist();
                toast.success("Həqiqi siyahı bərpa olundu");
              }}
            >
              Həqiqi siyahını bərpa et
            </Button>
          </div>
        </section>
      </div>
    </div>
  );
}

function ProbeMeta({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-raised px-3 py-2">
      <p className="text-xs text-faint">{label}</p>
      <p className="mt-0.5 truncate text-sm font-medium tabular-nums">{value}</p>
    </div>
  );
}
