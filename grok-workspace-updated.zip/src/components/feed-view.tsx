import { Box, Download, Eye, Send, Users } from "lucide-react";
import { toast } from "sonner";
import { useRadar } from "@/lib/store";
import { formatTelegramAlert } from "@/lib/telegram-message";
import { alertsToCsv, downloadText } from "@/lib/export-alerts";
import { fmtNum, fmtRate } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function FeedView() {
  const alerts = useRadar((s) => s.alerts);
  const sendAlert = useRadar((s) => s.sendAlert);
  const injectSample = useRadar((s) => s.injectSample);
  const clearAlerts = useRadar((s) => s.clearAlerts);

  function exportCsv() {
    if (alerts.length === 0) {
      toast.error("Lenta boşdur");
      return;
    }
    downloadText("sandiqradar.csv", alertsToCsv(alerts), "text/csv;charset=utf-8");
    toast.success("CSV endirildi");
  }

  function exportJson() {
    if (alerts.length === 0) {
      toast.error("Lenta boşdur");
      return;
    }
    downloadText("sandiqradar.json", JSON.stringify(alerts, null, 2), "application/json");
    toast.success("JSON endirildi");
  }

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-wide text-muted uppercase">Xəbərdarlıq lenti</p>
          <h2 className="mt-1 text-xl font-semibold">Sandıq və hədiyyə çantası</h2>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" size="sm" onClick={() => injectSample("chest")}>
            Nümunə sandıq
          </Button>
          <Button variant="secondary" size="sm" onClick={() => injectSample("gift_bag")}>
            Nümunə çanta
          </Button>
          <Button variant="ghost" size="sm" onClick={exportCsv}>
            <Download className="size-4" />
            CSV
          </Button>
          <Button variant="ghost" size="sm" onClick={exportJson}>
            JSON
          </Button>
          <Button variant="ghost" size="sm" onClick={clearAlerts}>
            Təmizlə
          </Button>
        </div>
      </div>
      {alerts.length === 0 ? (
        <div className="rounded-xl bg-surface px-4 py-16 text-center shadow-[var(--shadow-border)]">
          <p className="text-sm text-muted">
            Lenta boşdur. Dəqiq unique_id canlı olanda növ (sandıq və ya hədiyyə çantası) və nəfər sayı
            burada görünəcək.
          </p>
        </div>
      ) : (
        <ul className="flex flex-col gap-4">
          {alerts.map((a) => {
            const fill = a.totalSlots > 0 ? Math.min(100, Math.round((a.participants / a.totalSlots) * 100)) : 0;
            return (
              <li key={a.id} className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-xs text-muted">
                      {new Date(a.ts).toLocaleTimeString("az-AZ", {
                        hour: "2-digit",
                        minute: "2-digit",
                        second: "2-digit",
                      })}
                    </p>
                    <h3 className="mt-1 text-lg font-semibold tracking-tight">@{a.username}</h3>
                    <div className="mt-1 flex flex-wrap items-center gap-2">
                      <Badge variant={a.kind === "gift_bag" ? "bag" : "box"}>{a.giftType}</Badge>
                      {a.confidence ? (
                        <span className="text-xs text-muted">etibar {Math.round(a.confidence)}%</span>
                      ) : null}
                    </div>
                    {a.title ? <p className="mt-1 text-sm text-muted">{a.title}</p> : null}
                  </div>
                  <div className="text-right">
                    <p className="font-mono text-3xl font-medium tracking-tight text-accent tabular-nums">
                      {fmtRate(a.rate)}
                    </p>
                    <p className="text-xs text-muted">jeton / nəfər</p>
                  </div>
                </div>
                <dl className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <Meta icon={Eye} label="Canlıda" value={`${fmtNum(a.viewers)} nəfər`} />
                  <Meta icon={Box} label="Bölgü" value={`${a.totalCoins}/${a.totalSlots}`} />
                  <Meta icon={Users} label="Qoşulan" value={`${fmtNum(a.participants)} / ${fmtNum(a.totalSlots)}`} />
                  <Meta icon={Send} label="Telegram" value={a.telegramSent ? "Göndərildi" : a.telegramError ?? "Gözləyir"} />
                </dl>
                <div className="mt-3">
                  <div className="mb-1 flex justify-between text-xs text-muted">
                    <span>Qoşulma</span>
                    <span className="tabular-nums">{fill}%</span>
                  </div>
                  <div className="progress-bar">
                    <span style={{ width: `${fill}%` }} />
                  </div>
                </div>
                <pre className="mt-4 overflow-x-auto rounded-lg bg-raised p-3 font-mono text-xs leading-relaxed text-muted whitespace-pre-wrap">
                  {formatTelegramAlert(a)}
                </pre>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => {
                      void sendAlert(a).then(() => toast.message("Telegram sorğusu göndərildi"));
                    }}
                  >
                    Telegram-a at
                  </Button>
                  <Button size="sm" variant="ghost" asChild>
                    <a href={a.liveUrl} target="_blank" rel="noreferrer">
                      Yayıma keç
                    </a>
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function Meta({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Eye;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg bg-raised px-3 py-2">
      <div className="flex items-center gap-1.5 text-faint">
        <Icon className="size-3.5" />
        <span className="text-xs">{label}</span>
      </div>
      <p className="mt-1 text-sm font-medium tabular-nums">{value}</p>
    </div>
  );
}
